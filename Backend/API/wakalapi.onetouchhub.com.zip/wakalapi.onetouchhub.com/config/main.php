<?php

$params = array_merge(
    require(__DIR__ . '/params.php'),
    require(__DIR__ . '/params-local.php')
);

return [
    'id' => 'app-mobile-api',
    'name' => 'Mobile Api',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log',
        [
            'class' => 'yii\filters\ContentNegotiator',
            'formats' => [
                'application/json' => \yii\web\Response::FORMAT_JSON,
                'application/xml' => \yii\web\Response::FORMAT_XML,
            ],
            'languages' => [
                'en',
            ],
        ]
    ],
    'defaultRoute' => 'client',
    'controllerNamespace' => 'app\controllers',
    'components' => [
        'request' => [
            'csrfParam' => '_csrf-mobile',
        ],
        'user' => [
            'enableSession' => false,
            'identityClass' => 'app\components\AuthModel',
            'loginUrl' => null
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'formatter' => [
            'class' => 'app\components\Formatter',
            'userClass' => 'app\models\SystemUser',
            'userDisplayColumn' => 'fullName',
            'baseUploadUrl' => '',
            'dateFormat' => 'dd/MM/yyyy',
            'datetimeFormat' => 'dd/MM/yyyy hh:mm:ss',
            'locale' => 'en-TZ',
            'countryDiallingCode' => '255',
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                'image/<path>' => 'api/image'
            ],
        ],
    ],
    'params' => $params,
];
