<?php

$params = require(__DIR__ . '/params.php');
$db = require(__DIR__ . '/db-local.php');

$config = [
    'id' => 'basic-console',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'controllerNamespace' => 'app\commands',
    'components' => [
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'log' => [
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'baseUrl' => '/nova/wakala-api',
            'hostInfo' => 'http://192.168.43.140',
            'rules' => [
                'image/<path>' => 'api/image'
            ],
        ],
        'db' => $db,
    ],
    'params' => $params
];

return $config;
