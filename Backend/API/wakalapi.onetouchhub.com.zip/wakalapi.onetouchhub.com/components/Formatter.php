<?php
/*
 * Copyright (c) 2017 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 12/23/2017
 * Time: 2:37 PM
 */


namespace app\components;

use app\models\Agent;
use app\models\Client;
use app\models\ProviderService;
use app\models\Service;
use app\models\ServiceProvider;

/**
 * Class Formatter
 *
 * Description of Formatter
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\modules\payroll\components
 */
class Formatter extends \modular\Formatter
{

    public function asService($value)
    {
        if ($value == false) {
            return "(not set)";
        }
        $model = Service::findOne($value);
        if ($model) {
            return $model->name;
        }
        return "(not found)";
    }

    public function asProvider($value)
    {
        if ($value == false) {
            return "(not set)";
        }
        $model = ServiceProvider::findOne($value);
        if ($model) {
            return $model->name;
        }
        return "(not found)";
    }

    public function asClient($value)
    {
        if ($value == false) {
            return "(not set)";
        }
        $model = Client::findOne($value);
        if ($model) {
            return $model->first_name . ' ' . $model->last_name . " [" . $model->mobile_no . "]";
        }
        return "(not found)";
    }

    public function asAgent($value)
    {
        if ($value == false) {
            return "(not set)";
        }
        $model = Agent::findOne($value);
        if ($model) {
            return $model->business_name . " [" . $model->user->mobile_no . "]";
        }
        return "(not found)";
    }

    public function asProviderService($value)
    {
        if ($value == false) {
            return "(not set)";
        }
        $model = ProviderService::findOne($value);
        if ($model) {
            return $model->provider->name . " - " . $model->service->name;
        }
        return "(not found)";
    }

}