<?php
/*
 * Copyright (c) 2017 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 10/30/2017
 * Time: 11:37 AM
 */


namespace app\components;

use infobip\models\SMSRequest;
use infobip\SmsClient;
use yii\base\Component;

/**
 * Class Sms
 *
 * Description of Sms
 *
 * @property SmsClient $client;
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\modules\crm\components
 */
class Sms extends Component
{
    public $username;
    public $password;
    public $sender;
    private $_client;

    public function init()
    {
        $this->_client = new SmsClient($this->username, $this->password);
    }

    public function getClient()
    {
        return $this->_client;
    }

    public function send($content, $recipient)
    {
        $smsMessage = new SMSRequest();
        $smsMessage->senderAddress = $this->sender;
        $smsMessage->address = $recipient;
        $smsMessage->message = $content;
        $smsMessageSendResult = $this->client->sendSMS($smsMessage);
        return $smsMessageSendResult;
    }

    public function sendMultiple($content, $recipients = [])
    {
        $result = [];
        foreach ($recipients as $recipient) {
            $response = $this->send($content, $recipient);
            $result[$recipient] = $response;
        }
        return $result;
    }
}