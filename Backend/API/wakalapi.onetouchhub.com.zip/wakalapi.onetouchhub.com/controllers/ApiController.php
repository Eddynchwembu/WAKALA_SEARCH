<?php
/*
 * Copyright (c) 2017 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 9/21/2017
 * Time: 2:00 PM
 */


namespace app\controllers;

use app\components\Cors;
use app\models\Client;
use modular\Yii;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBasicAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\web\UploadedFile;


/**
 * Class DefaultController
 *
 * Description of DefaultController
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package mobile\controllers
 */
class ApiController extends \modular\rest\Controller
{
    public $enableCsrfValidation = false;

    public function beforeAction($action)
    {
        if (parent::beforeAction($action)) {
            if (request()->isPost) {
                $content = file_get_contents('php://input');
                if (!empty($content)) {
                    $_POST = array_merge($_POST, json_decode($content, true));
                }
            }
            return true;
        }
        return false;
    }

    public function actions()
    {
        return [
            'auth' => [
                'class' => 'mobile\components\AuthAction',
                'successCallback' => [$this, 'oAuthSuccess'],
            ],
        ];
    }


    public function actionAuthenticate()
    {
        if (!user()->isGuest) {
            $model = Client::findIdentity(user()->id);
            return [
                'id' => $model->id,
                'name' => $model->fullName,
                'email' => $model->username,
                'status' => $model->status,
                'location' => $model->location,
                'facebook' => $model->fb_url,
                'twitter' => $model->twitter_url,
                'contact' => $model->mobile_no,
                'dob' => $model->birthdate ? date('Y-m-d', $model->birthdate) : '',
                'image' => $model->photo,
                'coverimage' => 'cover.jpg'
            ];
        } else {
            return false;
        }
    }

    public function behaviors()
    {
        return array_merge(parent::behaviors(), [
            'corsFilter' => [
                'class' => Cors::className(),
                'cors' => [
                    'Origin' => ['*'],
                    'Access-Control-Request-Method' => ['POST', 'GET', 'OPTIONS'],
                    'Access-Control-Allow-Credentials' => true,
                    'Access-Control-Max-Age' => 3600,
                    'Access-Control-Allow-Headers' => ['Content-Type']
                ]
            ],
            'authenticator' => [
                'class' => CompositeAuth::className(),
                'except' => ['sign-in', 'reset-password', 'register', 'get-status', 'request-password', 'reset-password', 'tos'],
                'authMethods' => [[
                    'class' => HttpBasicAuth::className(),
                    'auth' => function ($username, $password) {
                        $username = Yii::app()->formatter->asPhone($username, '255');
                        $model = Client::findOne(['mobile_no' => $username, 'status' => 10]);
                        if ($model && $model->validatePassword($password)) {
                            return $model;
                        }
                        return null;
                    }
                ],
                    HttpBearerAuth::className(),
                    QueryParamAuth::className(),
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'login' => ['POST'],
                    'rate' => ['POST']
                ],
            ],
        ]);
    }


    public function actionGetStatus()
    {
        return [
            'config' => [
                [
                    'title' => 'Login',
                    'text' => json_encode([
                        ['value' => true]
                    ])]
            ],
            'menu' => [

            ]
        ];
    }

    public function actionGetHomeCampaigns()
    {

    }

    public function actionCampaigns()
    {
        $searchModel = new ProjectSearch();
        $searchModel->active = 1;
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $models = $dataProvider->getModels();
        $results = [];
        /* @var $models Project[] */
        foreach ($models as $model) {
            $results[] = [
                'id' => $model->id,
                'status' => $model->active,
                'title' => $model->title,
                'startdate' => date('Y-m-d', $model->end_date),
                'image' => $model->image,
                'recipient' => $model->fundRecipient->name,
                'level' => $model->level,
                'amount' => $model->funding_goal,
                'link' => Url::to(['campaign/' . $model->slug], true),
                'days' => $model->days,
                'new' => $model->isNew
            ];
        }
        return [
            'queryresult' => $results
        ];
    }

    public function actionMyCampaigns($id)
    {
        $searchModel = new ProjectSearch();
        $searchModel->active = 1;
        $searchModel->created_by = $id;
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $models = $dataProvider->getModels();
        $results = [];
        /* @var $models Project[] */
        foreach ($models as $model) {
            $results[] = [
                'id' => $model->id,
                'status' => $model->active,
                'title' => $model->title,
                'startdate' => date('Y-m-d', $model->end_date),
                'image' => $model->image,
                'recipient' => $model->fundRecipient->name,
                'level' => $model->level,
                'amount' => $model->funding_goal,
                'link' => Url::to(['campaign/' . $model->slug], true),
                'days' => $model->days,
                'new' => $model->isNew
            ];
        }
        return [
            'queryresult' => $results
        ];
    }

    public function actionCampaign()
    {
        $id = post('id');
        if ($id != false) {
            $model = Project::findModel($id);
            return [
                'id' => $model->id,
                'image' => $model->image,
                'content' => $model->description,
                'title' => $model->title,
                'location' => $model->location,
                'recipient' => $model->fundRecipient->name,
                'timestamp' => date('Y-m-d', $model->end_date),
                'amount' => $model->funding_goal,
                'collected' => $model->funds,
                'level' => $model->level,
                'category' => $model->category,
                'organizer' => $model->client->fullName,
                'days' => $model->days,
                'country' => $model->country,
                'slug' => $model->slug
            ];
        }

    }

    public function actionClient($id)
    {
        $model = Client::findIdentity($id);
        return [
            'id' => $model->id,
            'name' => $model->name,
            'email' => $model->email,
            'status' => $model->status,
            'location' => $model->last_latitude,
            'facebook' => '',
            'twitter' => '',
            'contact' => $model->mobile_no,
            'dob' =>  '',
            'image' => $model->picture,
            'coverimage' => 'cover.jpg'
        ];
    }

    public function actionSignIn()
    {
        if (Yii::$app->request->isPost) {
            $username = format($this->post('username'),'phone');
            $password = $this->post('password');
            if ($model = Client::findOne(['mobile_no' => $username, 'status' => 10])) {

                if ($model->validatePassword($password)) {
                    $model->auth_key = Yii::app()->security->generateRandomString(32);
                    if ($model->save()) {
                        return [
                            'id' => $model->id,
                            'name' => $model->name,
                            'email' => $model->email,
                            'status' => $model->status,
                            'location' => $model->last_latitude,
                            'facebook' => '',
                            'twitter' => '',
                            'contact' => $model->mobile_no,
                            'dob' => $model->mobile_no ? date('Y-m-d') : '',
                            'auth_token' => $model->auth_key,
                        ];
                    }
                }
            }
        }

        return 'false';

    }

    public function actionLogout()
    {
        return 'true';
    }

    public function actionImage($path)
    {
        if (strpos($path, ".") !== false) {
            return Yii::app()->response->sendFile(alias("@backend/web/uploads/$path"));
        } else {
            if (Yii::app()->cache->exists($path)) {
                $content = Yii::app()->cache->get($path);
            } else {
                $content = file_get_contents("https://img.youtube.com/vi/" . $path . "/0.jpg");
                Yii::app()->cache->set($path, $content);
            }
            return Yii::app()->response->sendContentAsFile($content, $path);
        }
    }

    public function actionSearch()
    {
        $term = post("term");
        if ($term != false) {
            $campaigns = Project::find()->filterWhere(['like', 'title', $term])->all();
            /* @var $campaigns Project[] */
            $items = [];
            foreach ($campaigns as $campaign) {
                $items[] = [
                    'id' => $campaign->id,
                    'title' => $campaign->title,
                    'image' => $campaign->image
                ];
            }
            return [
                'campaigns' => $items
            ];
        }
    }

    public function actionProfile()
    {

    }

    /**
     * Uploads clients photo
     * @param integer $id Client Id
     * @return array
     */
    public function actionUploadPhoto($id)
    {
        if ($id != false && $model = Client::findIdentity($id)) {
            $file = UploadedFile::getInstanceByName('file');
            if ($file != false) {
                $name = uniqid(time()) . "." . $file->extension;
                $path = alias("@backend/web/uploads") . "/$name";
                $model->photo = $name;
                if ($file->saveAs($path) && $model->save()) {
                    return [
                        'message' => $name
                    ];
                }
            }
        }

        return [
            'message' => 'false'
        ];

    }

    public function actionChangePassword()
    {
        if (request()->isPost) {
            $confirm = post('confirmpassword');
            $password = post('newpassword');
            $old = post('oldpassword');
            $id = post('id');
            if ($id != false && $confirm != false && $password != false && $old != false) {
                if ($confirm != $password) {
                    return -1;
                }
                $model = Client::findIdentity($id);
                if ($model != false) {
                    if ($model->validatePassword($old)) {
                        $model->setPassword($password);
                        if ($model->save()) {
                            return 1;
                        }
                    }
                }
            }
        }
        return 0;
    }

    /**
     * @param $slug
     * @param $method
     * @param $token
     * @return array|string
     */
    public function actionDonate($slug, $token, $method)
    {
        if (request()->isPost) {
            $amount = post('amount');
            $comment = post('comment');
            $contact = post('contact');
            if ($amount && $contact) {
                $client = Client::findIdentityByAccessToken($token);
                $model = TmpDonation::loadOrNew($token, $slug);
                $campaign = Project::findBySlug($slug);
                $model->client_id = $client->id;
                $model->email = $client->username;
                $model->amount = $amount;
                $model->number = $contact;
                $model->comment = $comment;
                $model->first_name = $client->first_name;
                $model->last_name = $client->last_name;
                $model->project_slug = $slug;
                $model->vendor = $method;
                $model->project = $campaign;
                $model->session_token = $token;
                if ($model->save()) {
                    $method = PaymentFactory::createPesaPal(['model' => $model]);
                    return [
                        'campaign' => [
                            'title' => $campaign->title,
                            'amount' => $campaign->funding_goal
                        ],
                        'content' => $method->pay($model, true)
                    ];
                } else {
                }

            }

        }
        return 'false';

    }

    public function actionTest($q = 'true')
    {
        $q = $q == 'true';
        Yii::app()->response->format = Response::FORMAT_HTML;
        return $this->renderPartial('redirect', ['success' => $q]);

    }

    /**
     * Redirect from pesapal payment page.
     * @todo redirect is opened in new browser in mobile leaving 'you are being redirected link on the app' currently no fix.
     *
     * @param string $slug Project slug
     * @param string $token Session token
     * @param string $pesapal_transaction_tracking_id Tracking id
     * @param string $pesapal_merchant_reference Merchant reference
     * @return string
     */
    public function actionPesapalRedirect($slug, $token, $pesapal_transaction_tracking_id, $pesapal_merchant_reference)
    {
        $model = TmpDonation::loadOrNew($token, $slug);
        $campaign = Project::findBySlug($model->project_slug);
        $success = false;
        Yii::app()->response->format = Response::FORMAT_HTML;
        if (!PaymentTxn::isExist($pesapal_transaction_tracking_id)) {
            $txn_id = PaymentTxn::add($pesapal_transaction_tracking_id, $campaign->id, $model->amount, "pesapal", $model->number, $model->email, 1);
            $model->payment_txn_id = $txn_id;
            $success = $model->save();
//            $donation = new ProjectDonation();
//            $donation->amount = $model->amount;
//            $donation->client_id = $model->client_id;
//            $donation->comment = $model->comment;
//            $donation->payment_txn_id = $txn_id;
//            $donation->project_id = $campaign->id;
//            $donation->currency_id = 1;
//            $donation->created_at = time();
//            $donation->src_type = 'pesapal';
//            $donation->valid = 0;
//            if ($donation->save()) {
//                $success = $model->delete();
//            }

        } else {
            $success = true;
        }

        return $this->renderPartial('redirect', ['success' => $success]);
    }


}