<?php
/*
 * Copyright (c) 2017 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 9/21/2017
 * Time: 2:00 PM
 */


namespace app\controllers;


use app\components\Cors;
use app\components\Firebase;
use app\models\Agent;
use app\models\AgentLog;
use app\models\AgentRating;
use app\models\AgentService;
use app\models\AgentSms;
use app\models\ClientNotification;
use app\models\Login;
use app\models\Password;
use app\models\Profile;
use app\models\ProviderService;
use app\models\Register;
use app\models\Request;
use app\models\RequestNotification;
use app\models\Search;
use app\models\ServiceProvider;
use app\models\ServiceRequest;
use app\models\ServiceRequestSearch;
use app\models\SystemUser;
use coreit\nreport\components\GridPdf;
use coreit\nreport\components\PdfView;
use modular\data\ActiveDataProvider;
use modular\web\Controller;
use modular\Yii;
use yii\data\ArrayDataProvider;
use yii\db\Expression;
use yii\db\Query;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBasicAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\VerbFilter;
use yii\helpers\Url;


/**
 * Class DefaultController
 *
 * Description of DefaultController
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package mobile\controllers
 */
class AgentController extends Controller
{
    public $enableCsrfValidation = false;

    public function init()
    {
        define('API_MODE', 'agent');
        parent::init();
    }

    public function behaviors()
    {
        return array_merge(parent::behaviors(), [
            'corsFilter' => [
                'class' => Cors::className(),
                'cors' => [
                    'Origin' => ['*'],
                    'Access-Control-Request-Method' => ['POST', 'GET', 'OPTIONS'],
                    'Access-Control-Allow-Credentials' => true,
                    'Access-Control-Max-Age' => 3600,
                    'Access-Control-Allow-Headers' => ['Content-Type']
                ]
            ],
            'authenticator' => [
                'class' => CompositeAuth::className(),
                'except' => ['login', 'register', 'reset-password', 'request-password', 'push'],
                'authMethods' => [
                    HttpBasicAuth::className(),
                    HttpBearerAuth::className(),
                    QueryParamAuth::className(),
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'login' => ['POST'],
                ],
            ],
        ]);
    }

    public function beforeAction($action)
    {
        if (parent::beforeAction($action)) {
            if (request()->isPost) {
                $content = file_get_contents('php://input');
                if (!empty($content)) {
                    $content = json_decode($content, true);
                    if (!is_array($content) && $content != false) {
                        $content = [$content];
                    }
                    if (is_array($content)) {
                        $_POST = array_merge($_POST, $content);
                    }
                }
            }
            return true;
        }
        return false;
    }

    public function actionIndex()
    {

    }

    public function actionLogout()
    {
        $token = $this->post('access-token');
        $model = SystemUser::findIdentityByAccessToken($token);
        if ($model) {
            $model->access_token = null;
            if ($model->save()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Logout Success'
                ];
            } else {
                return [
                    'status' => 0,
                    'code' => 500,
                    'message' => 'Logout Failed'
                ];
            }
        } else {
            return [
                'status' => 0,
                'code' => 200,
                'message' => 'Logout Failed'
            ];
        }
    }

    public function actionLogin()
    {
        $model = new Login();
        if ($model->loadPost() && $model->validate()) {
            $user = SystemUser::findOne(['username' => $model->username, 'status' => 1]);
            if ($user && $user->validatePassword($model->password)) {
                $agent = Agent::findOne(['user_id' => $user->id]);
                $user->access_token = Yii::app()->security->generateRandomString(60);
                $image = $agent->picture ? $agent->picture : '/drive/images/default/no_image.png';
                if ($user->save()) {
                    return [
                        'status' => 1,
                        'message' => 'Login Success',
                        'code' => 200,
                        'access_token' => $user->access_token,
                        'fcm_access_token' => $agent->fcm_access_token,
                        'profile' => [
                            'business' => $agent->business_name,
                            'name' => $user->name,
                            'mobile' => $user->mobile_no,
                            'email' => $user->email,
                            'latitude' => $agent->latitude,
                            'longitude' => $agent->longitude,
                            'image' => Url::to([$image], true)
                        ]
                    ];
                } else {
                    return [
                        'status' => 0,
                        'code' => 500,
                        'message' => 'Login Failed'
                    ];
                }
            } else {
                return [
                    'status' => 0,
                    'code' => 200,
                    'message' => 'Login Failed'
                ];
            }
        } else {
            return [
                'status' => 0,
                'code' => 200,
                'message' => 'Login Failed, Invalid Data.'
            ];
        }
    }

    function getLocation($lat, $long)
    {
        $url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$long&sensor=false&key=AIzaSyCizVr1mmDvZtGVUfj77HU4vFXtxnQxUz0";

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_ENCODING, "");
        $curlData = curl_exec($curl);
        curl_close($curl);

        $address = json_decode($curlData, true);
        if (is_array($address) && !empty($address)) {
            $location = $address['results'][0];
            return $location['formatted_address'];
        }
        return null;
    }

    /**
     * Registers agent
     * @return array
     */
    public function actionRegister()
    {
        $model = new Register(['scenario' => 'agent']);
        if ($model->loadPost()) {
            if ($model->location == null) {
                $model->location = $this->getLocation($model->latitude, $model->longitude);
            }
            if ($model->registerAgent()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Registration Successfully.'
                ];
            } else {
                $errors = $model->errorList;
                return [
                    'status' => 0,
                    'code' => 403,
                    'message' => "Registration failed",
                    'errors' => $errors
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400,
            'message' => 'Registration failed. Invalid data.'
        ];
    }

    /**
     * Respond to request.
     * @param int $id AgentNotification Id
     * @return array
     */
    public function actionRespond($id)
    {
        /* @var $agent Agent */
        $agent = Yii::app()->user->identity;
        $model = RequestNotification::findOne(['id' => $id, 'agent_id' => $agent->id, 'status' => 0]);
        if ($model) {
            $request = $model->request;
            if ($request->status == 0) {
                if ($model->status == 1) {
                    $request->status = $request::STATUS_ACTIVE;
                    $request->agent_id = $agent->id;
                    if ($request->save()) {
                        $model->status = 1;
                        $model->save();
                        RequestNotification::updateAll(['status' => 2], ['status' => 0, 'request_id' => $model->request_id]);
                        return [
                            'status' => 1,
                            'code' => 200,
                            'message' => 'Request Responded'
                        ];
                    }
                } else {
                    $model->status = 2;
                    $model->save();
                    return [
                        'status' => 1,
                        'code' => 200,
                        'message' => 'Request rejected.'
                    ];
                }

            } else {
                return [
                    'status' => 0,
                    'code' => 200,
                    'message' => 'Request already responded.'
                ];
            }
        } else {
            return [
                'status' => 0,
                'code' => 200,
                'message' => 'Record not found'
            ];
        }
    }

    public function actionHistory()
    {
        $model = new Search();
        $data = [];
        if ($model->loadPost() && $model->validate()) {
            /* @var  $agent Agent */
            $agent = Yii::app()->user->identity;
//            $query = ServiceRequest::find()->where(['agent_id' => $agent->id]);
//            $query->joinWith(['client', 'service']);

            $log = new Query();
            $log->select([new Expression("'-'"), "client_no", "d.name provider", "s.name service", "amount", "l.created_at"])
                ->from("wakala_agent_log l")
                ->innerJoin("wakala_provider_service q", "q.id = l.service_id")
                ->innerJoin("wakala_service s", "s.id = q.service_id")
                ->innerJoin("wakala_service_provider d", "q.provider_id = d.id")
                ->where(['l.agent_id' => $agent->id]);

            $request = new Query();
            $request->select([new Expression("concat(c.first_name,' ',c.last_name) client"), "c.mobile_no", "d.name provider", "s.name service", "amount", "r.created_at"])
                ->from("wakala_service_request r")
                ->innerJoin("wakala_client c", 'c.id = r.client_id')
                ->innerJoin("wakala_provider_service q", "q.id = r.service_id")
                ->innerJoin("wakala_service s", "s.id = q.service_id")
                ->innerJoin("wakala_service_provider d", "q.provider_id = d.id")
                ->where(['r.agent_id' => $agent->id])
                ->union($log);
            if ($model->phone) {
                $request->andFilterWhere(['like', 'c.mobile_no', $model->phone]);
                $log->andFilterWhere(['like', 'client_no', $model->phone]);
            }
            if ($model->service) {
                $request->andWhere(['q.provider_id' => $model->service]);
                $log->andWhere(['q.provider_id' => $model->service]);
            }
            $dataProvider = new ActiveDataProvider([
                'query' => $request,
            ]);
            /* @var $item ServiceRequest */
            foreach ($dataProvider->models as $item) {
                $data[] = [
                    'client' => $item['client'],
                    'amount' => number_format($item['amount'], 2),
                    'name' => $item['provider'] . " - " . $item['service'],
                    'message' => '',
                    'date' => date('d/m/Y H:i', $item['created_at']),
                    //'status' => $item->status,
                    //'logo' => Url::to([$item->service->provider->logo], true)
                ];
            }
        }
        return [
            'status' => 1,
            'code' => 200,
            'items' => $data
        ];
    }

    public function actionSubmitLog()
    {
        $model = new AgentLog();
        if ($model->loadPost()) {
            /* @var $agent Agent */
            $agent = Yii::app()->user->identity;
            $model->agent_id = $agent->id;
            if ($model->save()) {
                return [
                    'status' => 1,
                    'code' => 200
                ];
            } else {
                return [
                    'status' => 0,
                    'code' => 400,
                    'message' => 'Save failed',
                    'errors' => $model->errorList
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400,
            'message' => 'Invalid request'
        ];
    }

    public function actionProfile()
    {
        /* @var $model Agent */
        $model = Yii::app()->user->identity;
        $user = $model->user;
        if (\request()->isGet) {
            return [
                'status' => 1,
                'code' => 200,
                'profile' => [
                    'business' => $model->business_name,
                    'name' => $user->name,
                    'email' => $user->email,
                    'phone' => $user->mobile_no,
                    'location' => $model->location_name,
                    'latitude' => $model->latitude,
                    'longitude' => $model->longitude
                ]
            ];
        } else {
            $profile = new Profile();
            if ($profile->loadPost()) {
                $client = Yii::app()->user->identity;
//                if ($profile->gender) {
//                    $user->gender = $model->gender;
//                }
                if ($profile->email) {
                    $user->email = $profile->email;
                }
                if ($profile->location) {
                    $model->location_name = $profile->location;
                }
                if ($profile->latitude) {
                    $model->latitude = $profile->latitude;
                    $model->longitude = $profile->longitude;
                    $model->location_name = $this->getLocation($model->latitude, $model->longitude);
                }
                if ($profile->old_password && $profile->new_password) {
                    if (!$user->validatePassword($profile->old_password)) {
                        return [
                            'status' => 0,
                            'code' => 200,
                            'message' => 'Invalid password'
                        ];
                    }
                    $user->setPassword($profile->new_password);
                }

                if ($user->save() && $model->save()) {
                    return [
                        'status' => 1,
                        'code' => 200,
                        'message' => 'Profile successfully updated.'
                    ];
                } else {
                    return [
                        'status' => 0,
                        'code' => 200,
                        'errors' => $model->errorList
                    ];
                }
            }
            return [
                'status' => 0,
                'code' => 200,
                'errors' => 'No data'
            ];
        }

    }

    public function actionServices($id)
    {
        /* @var $model Agent */
        $model = Yii::app()->user->identity;
        $q = "SELECT p.id,s.name,a.agent_no,if(a.id IS NULL ,FALSE ,TRUE )provide
FROM wakala_provider_service p
  JOIN wakala_service s ON p.service_id = s.id
  LEFT JOIN wakala_agent_service a ON a.service_id = p.id AND a.agent_id = :id
WHERE  provider_id = :pid";
        $models = db()->createCommand($q, [':id' => $model->id, "pid" => $id])->queryAll();
        // $provider = ServiceProvider::findOne($id);
        $code = '';
        if (!empty($models)) {
            $code = $models[0]['agent_no'] ? $models[0]['agent_no'] : '';
        }
        return [
            'status' => 1,
            'code' => 200,
            'agent_no' => $code,
            'items' => $models
        ];
    }

    /**
     * Lists available services
     * @return array
     */
    public function actionProviders()
    {
        $providers = ServiceProvider::findAll(['active' => 1]);
        $items = [];
        foreach ($providers as $provider) {
            $models = ProviderService::findAll(['provider_id' => $provider->id, 'active' => 1]);
            if (!empty($models)) {
                $item = [
                    'id' => $provider->id,
                    'name' => $provider->name,
                    'logo' => Url::to([$provider->logo], true)
                ];
                $services = [];
                foreach ($models as $model) {
                    $services[] = [
                        'name' => $model->service->name,
                        'id' => $model->id
                    ];
                }
                $item['services'] = $services;
                $items[] = $item;
            }
        }
        return [
            'status' => 1,
            'code' => 200,
            'items' => $items
        ];
    }

    /**
     * Lists available services
     * @return array
     */
    public function actionProviderServices()
    {
        $providers = ServiceProvider::findAll(['active' => 1]);
        $items = [];
        foreach ($providers as $provider) {
            $models = ProviderService::findAll(['provider_id' => $provider->id, 'active' => 1]);
            foreach ($models as $model) {
                $items[] = [
                    'id' => $model->id,
                    'name' => $provider->name . ' - ' . $model->service->name,
                ];
            }
        }
        return [
            'status' => 1,
            'code' => 200,
            'items' => $items
        ];
    }

    public function actionService()
    {
        $agentCode = $this->post("agentCode");
        $services = $this->post("service");
        /* @var $agent Agent */
        $agent = Yii::app()->user->identity;
        if (is_array($services) && !empty($services)) {
            foreach ($services as $id => $service) {
                $model = AgentService::getOrNew($agent->id, $id);
                $model->active = (boolean)$service;
                $model->agent_no = $agentCode;
                if(!$model->save()){
                    return [
                        'status'=>0,
                        'code'=>200,
                        'message'=>$model->errorLines,
                    ];
                }
            }

            return [
                'status' => 1,
                'code' => 200,
                'message' => 'Services successfully updated.'
            ];
        }
        return [
            'status' => 0,
            'code' => 200,
            'message' => 'Failed to update services.'
        ];
    }

    public function actionNotifications()
    {
        /* @var $agent Agent */
        /* @var $models RequestNotification[] */
        $agent = Yii::app()->user->identity;
        $models = RequestNotification::findAll(['agent_id' => $agent->id, 'status' => 0]);
        $items = [];
        foreach ($models as $model) {
            $items[] = [
                'id' => $model->id,
                'client' => $model->request->client->name,
                'message' => $model->request->service->service->name . " " . $model->request->amount,
                'time' => $model->created_at
            ];
        }

        return [
            'status' => 1,
            'code' => 200,
            'account' => $agent->business_name,
            'items' => $items
        ];
    }

    public function actionFcmToken()
    {
        $token = $this->post('token');
        if ($token) {
            /* @var $agent Agent */
            $agent = Yii::app()->user->identity;
            $agent->fcm_access_token = $token;
            if ($agent->save()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'success'
                ];
            } else {
                return [
                    'status' => 0,
                    'code' => 200,
                    'message' => 'Error',
                    'errors' => $agent->errorList
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 200,
            'message' => 'Invalid data'
        ];
    }

    public function actionRequests()
    {
        /* @var $agent Agent */
        /* @var $models RequestNotification[] */
        $agent = Yii::app()->user->identity;
        $models = RequestNotification::find()->joinWith('request')->where(['wakala_request_notification.agent_id' => $agent->id,
            'wakala_request_notification.status' => 0, 'wakala_service_request.status' => 0])->orderBy(['wakala_request_notification.created_at' => SORT_DESC])->all();
        $items = [];
        foreach ($models as $model) {
            $items[] = [
                'id' => $model->request_id,
                'date' => date('Y-m-d', $model->created_at),
                'client' => $model->request->client->mobile_no,
                'amount' => number_format($model->request->amount, 2),
                'name' => $model->request->service->provider->name . " - " . $model->request->service->service->name,
                'message' => $model->request->comment,
                'created_at' => $model->created_at,
                'status' => $model->status,
                'logo' => Url::to([$model->request->service->provider->logo], true)
            ];
        }
        return [
            'status' => 1,
            'code' => 200,
            'items' => $items
        ];
    }

    /**
     * Views and update Client's request,
     * @param $id
     * @return array
     */
    public function actionRequest($id)
    {
        /* @var $agent Agent */
        $agent = Yii::app()->user->identity;
        $model = ServiceRequest::findModel($id);
        if ($model->status == 0 && $model->loadPost()) {
            if ($model->status == 1) {
                $model->agent_id = $agent->id;
                if ($model->save()) {
                    RequestNotification::updateAll(['status' => RequestNotification::STATUS_REJECTED], ['request_id' => $model->id]);
                    RequestNotification::updateAll(['status' => RequestNotification::STATUS_ACCEPTED], ['request_id' => $model->id, 'agent_id' => $model->agent_id]);
                    $not = new ClientNotification();
                    $not->client_id = $model->client_id;
                    $not->request_id = $model->id;
                    $not->message = $model->service->name . " accepted by " . $agent->business_name;
                    if ($not->save()) {
                        return [
                            'status' => 1,
                            'code' => 200,
                            'message' => 'Request successfully accepted, Client Notified.'
                        ];
                    } else {
                        return [
                            'status' => 1,
                            'code' => 202,
                            'message' => 'Request successfully accepted, Failed to notify client.'
                        ];
                    }
                }
            } else {
                RequestNotification::updateAll(['status' => RequestNotification::STATUS_REJECTED], ['request_id' => $model->id, 'agent_id' => $agent->id]);
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Request successfully rejected.'
                ];
            }
        } elseif ($model->status == 0) {
            return [
                'status' => 1,
                'code' => 200,
                'request' => [
                    'id' => $model->id,
                    'client' => $model->client->mobile_no,
                    'name' => $model->client->name,
                    'provider' => $model->service->provider->name,
                    'service' => $model->service->service->name,
                    'amount' => $model->amount,
                    'comment' => $model->comment,
                    'time' => $model->created_at,
                    'account' => $agent->business_name,
                    'image' => Url::to([$model->service->provider->logo], true)
                ]
            ];
        } else {
            return [
                'status' => 0,
                'code' => 201,
                'message' => 'Request already handled.'
            ];
        }
        return [
            'status' => 0,
            'code' => 200,
            'message' => 'Invalid data'
        ];
    }

    /**
     * Cancels Service request.
     * @param integer $id Request Id
     * @return array
     */
    public function actionCancelRequest($id)
    {
        /* @var $agent Agent */
        $agent = Yii::app()->user->identity;
        $model = ServiceRequest::findOne(['id' => $id, 'agent_id' => $agent->id]);
        if ($model) {
            $model->status = 2;
            if ($model->save()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Request cancelled'
                ];
            } else {
                return [
                    'status' => 0,
                    'code' => 500,
                    'message' => 'Failed to cancel request',
                    'errors' => $model->errorList
                ];
            }
        } else {
            return [
                'status' => 0,
                'code' => 200,
                'message' => 'Record Not found'
            ];
        }
    }


    public function actionClients()
    {
        /* @var $agent Agent */
        $agent = Yii::app()->user->identity;
        $q = "SELECT s.client_id id,concat(c.first_name,' ',c.last_name) name,c.mobile_no,c.last_latitude,c.last_longitude 
FROM wakala_service_request s 
JOIN wakala_client c ON c.id = s.client_id
 WHERE s.status = 1 AND s.agent_id = :id
GROUP BY s.client_id";
        $models = db()->createCommand($q, ["id" => $agent->id])->queryAll();
        $requests = RequestNotification::find()->where(['agent_id' => $agent->id, 'status' => 0])->count();
        $items = [];
        foreach ($models as $model) {
            $items[] = [
                'id' => $model['id'],
                'name' => $model['name'],
                'latitude' => $model['last_latitude'],
                'longitude' => $model['last_longitude'],
                'phone' => $model['mobile_no']
            ];
        }

        return [
            'status' => 1,
            'code' => 200,
            'items' => $items,
            'requests' => $requests
        ];
    }

    public function actionLogbook()
    {
        $model = new Search();
        if ($model->loadPost() && $model->validate()) {
            /* @var  $agent Agent */
            $agent = Yii::app()->user->identity;
//            $query = ServiceRequest::find()->where(['agent_id' => $agent->id]);
//            $query->joinWith(['client', 'service']);
//            if ($model->phone) {
//                $query->andFilterWhere(['like', 'mobile_no', $model->phone]);
//            }
//            if ($model->service) {
//                $query->andWhere(['provider_id' => $model->service]);
//            }

            $sql = <<<SQL
SELECT CONCAT(c.first_name,' ',c.last_name) client,c.mobile_no,d.name provider,s.name service,amount,r.created_at
FROM wakala_service_request r
JOIN wakala_client c ON c.id = r.client_id
JOIN wakala_provider_service q ON q.id = r.service_id
JOIN wakala_service s ON s.id = q.service_id
JOIN wakala_service_provider d ON q.provider_id = d.id
WHERE r.agent_id = :id
UNION
SELECT '-' client,client_no,d.name provider,s.name service,amount,l.created_at
FROM wakala_agent_log l
JOIN wakala_provider_service q ON q.id =l.service_id
JOIN wakala_service s ON s.id = q.service_id
JOIN wakala_service_provider d ON q.provider_id = d.id
WHERE l.agent_id = :id
SQL;
            $models = db()->createCommand($sql, [":id" => $agent->id])->queryAll();
            $dataProvider = new ArrayDataProvider(['models' => $models]);
            return GridPdf::widget([
                'columns' => [
                    ['class' => '\yii\grid\SerialColumn'],
                    'client',
                    'mobile_no',
                    'provider',
                    'service',
                    'amount:number',
                    'created_at:datetime:Time'
                ],
                'fileName' => 'report.pdf',
                'dataProvider' => $dataProvider,
                'creator' => $agent->user->name,
                'company' => $agent->business_name
            ]);
        }
    }

    public function actionRequestPassword()
    {
        $model = new Password();
        $model->loadPost();
        if ($model->loadPost() && $model->validate()) {
            $user = SystemUser::findOne(['mobile_no' => $model->phone]);
            if ($user) {
                $agent = Agent::findOne(['user_id' => $user->id]);
                if ($user->password_reset_token == false) {
                    $user->generatePasswordResetToken();
                    if ($user->save()) {
                        $sms = new AgentSms();
                        $sms->agent_id = $agent->id;
                        $sms->recipient = $user->mobile_no;
                        $sms->content = "Password reset code is: " . $user->password_reset_token;
                        if ($sms->save()) {
                            return [
                                'status' => 1,
                                'code' => 200,
                                'message' => 'Code successfully created and sent'
                            ];
                        }
                    } else {
                        return [
                            'status' => 0,
                            'code' => 400,
                            'message' => $user->errorList
                        ];
                    }
                } else {
                    return [
                        'status' => 0,
                        'code' => 400,
                        'message' => 'Reset token already generated'
                    ];
                }

            } else {
                return [
                    'status' => 0,
                    'code' => 404,
                    'message' => 'Not found'
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400,
            'message' => $model->errorList
        ];
    }

    public function actionResetPassword()
    {
        $model = new Password(['scenario' => 'reset']);
        if ($model->loadPost() && $model->validate()) {
            $client = SystemUser::findOne(['mobile_no' => $model->phone]);
            if ($client && $client->password_reset_token == $model->token) {
                $client->setPassword($model->password);
                $client->password_reset_token = null;
                if ($client->save()) {
                    return [
                        'status' => 1,
                        'code' => 200,
                        'message' => 'Reset success'
                    ];
                }
            } else {
                return [
                    'status' => 0,
                    'code' => 403,
                    'message' => 'Forbidden'
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400,
            'errors' => $model->errorList
        ];
    }

    public function actionServeRequest($id)
    {
        /* @var $agent Agent */
        $agent = Yii::app()->user->identity;
        $model = ServiceRequest::updateAll(['status' => ServiceRequest::STATUS_SERVED], ['client_id' => $id, 'agent_id' => $agent->id, 'status' => ServiceRequest::STATUS_ACTIVE]);
        if ($model > 0) {
            return [
                'status' => 1,
                'code' => 200,
                'message' => 'Success'
            ];
        } else {
            return [
                'status' => 0,
                'code' => 400
            ];
        }
    }

    public function actionAckNotification($id)
    {
        $model = RequestNotification::findOne($id);
        if ($model) {
            $model->pushed = 1;
            if ($model->save()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Success'
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400
        ];
    }
}