<?php
/*
 * Copyright (c) 2017 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 9/21/2017
 * Time: 2:00 PM
 */


namespace app\controllers;


use app\components\Cors;
use app\models\AgentRating;
use app\models\AgentService;
use app\models\Client;
use app\models\ClientNotification;
use app\models\ClientSms;
use app\models\Login;
use app\models\Password;
use app\models\Profile;
use app\models\ProviderService;
use app\models\Rating;
use app\models\Register;
use app\models\Request;
use app\models\RequestNotification;
use app\models\ServiceProvider;
use app\models\ServiceRequest;
use app\models\ToS;
use modular\web\Controller;
use modular\Yii;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBasicAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\auth\QueryParamAuth;
use yii\filters\VerbFilter;
use yii\helpers\Url;


/**
 * Class DefaultController
 *
 * Description of DefaultController
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package mobile\controllers
 */
class ClientController extends Controller
{
    public $enableCsrfValidation = false;

    public function init()
    {
        define('API_MODE', 'client');
        parent::init();
    }

    public function behaviors()
    {
        return array_merge(parent::behaviors(), [
            'corsFilter' => [
                'class' => Cors::className(),
                'cors' => [
                    'Origin' => ['*'],
                    'Access-Control-Request-Method' => ['POST', 'GET', 'OPTIONS'],
                    'Access-Control-Allow-Credentials' => true,
                    'Access-Control-Max-Age' => 3600,
                    'Access-Control-Allow-Headers' => ['Content-Type', 'Authorization']
                ]
            ],
            'authenticator' => [
                'class' => CompositeAuth::className(),
                'except' => ['login', 'reset-password', 'register', 'pulse', 'request-password', 'reset-password', 'tos'],
                'authMethods' => [[
                    'class' => HttpBasicAuth::className(),
                    'auth' => function ($username, $password) {
                        $username = Yii::app()->formatter->asPhone($username, '255');
                        //var_dump($username);
                        // echo ($password);exit;
                        // $password = explode(":",base64_decode($password))[1];
                        $model = Client::findOne(['mobile_no' => $username, 'status' => 10]);
                        if ($model && $model->validatePassword($password)) {
                            return $model;
                        }
                        return null;
                    }
                ],
                    HttpBearerAuth::className(),
                    QueryParamAuth::className(),
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'login' => ['POST'],
                    'rate' => ['POST']
                ],
            ],
        ]);
    }

    /**
     * @param Request $model
     * @return array
     */
    public function getAgents($model)
    {
        $lat = $model->latitude; // latitude of centre of bounding circle in degrees
        $lon = $model->longitude; // longitude of centre of bounding circle in degrees
        $rad = $model->radius; // radius of bounding circle in kilometers

        $R = 6371;  // earth's mean radius, km

        // first-cut bounding box (in degrees)
        $maxLat = $lat + rad2deg($rad / $R);
        $minLat = $lat - rad2deg($rad / $R);
        $maxLon = $lon + rad2deg(asin($rad / $R) / cos(deg2rad($lat)));
        $minLon = $lon - rad2deg(asin($rad / $R) / cos(deg2rad($lat)));

        $sql = "SELECT c.id, business_name, latitude, longitude,
                   acos(sin(:lat)*sin(radians(latitude)) + cos(:lat)*cos(radians(latitude))*cos(radians(longitude)-:lon)) * :R AS distance
            FROM (
                SELECT id, business_name, latitude, longitude
                FROM wakala_agent
                WHERE latitude BETWEEN :minLat AND :maxLat
                  AND longitude BETWEEN :minLon AND :maxLon
            ) AS c
  
   JOIN wakala_agent_service s ON s.agent_id = c.id AND s.service_id = :service
            WHERE acos(sin(:lat)*sin(radians(latitude)) + cos(:lat)*cos(radians(latitude))*cos(radians(longitude)-:lon)) * :R < :rad
            ORDER BY distance";
        $params = [
            'lat' => deg2rad($lat),
            'lon' => deg2rad($lon),
            'minLat' => $minLat,
            'minLon' => $minLon,
            'maxLat' => $maxLat,
            'maxLon' => $maxLon,
            'service' => $model->service,
            'rad' => $rad,
            'R' => $R,
        ];
        $items = db()->createCommand($sql, $params)->queryAll();
        return $items;
    }

    public function beforeAction($action)
    {
        if (parent::beforeAction($action)) {
            if (request()->isPost) {
                $content = file_get_contents('php://input');

                if (!empty($content)) {
                    $content = json_decode($content, true);
                    if (!is_array($content) && $content != false) {
                        $content = [$content];
                    }
                    if (is_array($content)) {
                        $_POST = array_merge($_POST, $content);
                    }
                }
            }
            return true;
        }
        return false;
    }

    public function actionIndex()
    {

    }

    public function actionLogout()
    {
        $token = $this->get('access-token');
        $model = Client::findIdentityByAccessToken($token);
        if ($model) {
            $model->access_token = null;
            if ($model->save()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Logout Success'
                ];
            } else {
                return [
                    'status' => 0,
                    'code' => 500,
                    'message' => 'Logout Failed'
                ];
            }
        } else {
            return [
                'status' => 0,
                'code' => 403,
                'message' => 'Logout Failed'
            ];
        }
    }

    public function actionLogin()
    {
        $model = new Login();
        if (($model->loadPost() || $model->loadJsonPost()) && $model->validate()) {
            $client = Client::findOne(['mobile_no' => $model->username, 'status' => 10]);
            if ($client && $client->validatePassword($model->password)) {
                $client->access_token = Yii::app()->security->generateRandomString(60);
                if ($client->save()) {
                    $image = $client->picture ? $client->picture : '/drive/images/default/no_image.png';
                    return [
                        'status' => 1,
                        'message' => 'Login Success',
                        'code' => 200,
                        'access_token' => $client->access_token,
                        'fcm_access_token' => $client->fcm_access_token,
                        'username' => $client->mobile_no,
                        'auth_data' => base64_encode($client->mobile_no . ':' . $model->password),
                        'profile' => [
                            'id' => $client->id,
                            'name' => $client->name,
                            'mobile' => $client->mobile_no,
                            'image' => Url::to([$image], true)
                        ]
                    ];
                } else {
                    return [
                        'status' => 0,
                        'code' => 500,
                        'message' => 'Login Failed'
                    ];
                }
            } else {
                return [
                    'status' => 0,
                    'code' => 200,
                    'message' => 'Login Failed'
                ];
            }
        } else {
            return [
                'status' => 0,
                'code' => 200,
                'message' => 'Login Failed, Invalid Data.'
            ];
        }
    }

    /**
     * Register client.
     * @return array
     */
    public function actionRegister()
    {
        $model = new Register(['scenario' => 'client']);
        if ($model->loadJsonPost() || $model->loadPost()) {
            if ($model->registerClient()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Registration Successfully. You can now log in.'
                ];
            } else {
                $errors = $model->errorList;
                return [
                    'status' => 0,
                    'code' => 403,
                    'message' => "Registration failed",
                    'errors' => $errors
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400,
            'message' => 'Registration failed. Invalid data.'
        ];
    }

    /**
     * Gets list of Agents
     * @return array
     */
    public function actionAgents()
    {
        $model = new Request();
        if (($model->loadPost() || $model->loadJsonPost()) && $model->validate()) {

            $lat = $model->latitude; // latitude of centre of bounding circle in degrees
            $lon = $model->longitude; // longitude of centre of bounding circle in degrees
            $rad = $model->radius; // radius of bounding circle in kilometers

            $R = 6371;  // earth's mean radius, km

            // first-cut bounding box (in degrees)
            $maxLat = $lat + rad2deg($rad / $R);
            $minLat = $lat - rad2deg($rad / $R);
            $maxLon = $lon + rad2deg(asin($rad / $R) / cos(deg2rad($lat)));
            $minLon = $lon - rad2deg(asin($rad / $R) / cos(deg2rad($lat)));

            $sql = "SELECT
  c.id,
  business_name,
  latitude,
  longitude,
  rating,
  location,
  image,
  s.agent_no,
  acos(sin(:lat) * sin(radians(latitude)) + cos(:lat) * cos(radians(latitude)) * cos(radians(longitude) - :lon)) *
  :R AS distance
FROM (
       SELECT
         id,
         business_name,
         latitude,
         longitude,
         rating,
         location_name location,
         picture image
       FROM wakala_agent
       WHERE latitude BETWEEN :minLat AND :maxLat
             AND longitude BETWEEN :minLon AND :maxLon
     ) AS c
  
   JOIN wakala_agent_service s ON s.agent_id = c.id AND s.service_id = :service
WHERE
  acos(sin(:lat) * sin(radians(latitude)) + cos(:lat) * cos(radians(latitude)) * cos(radians(longitude) - :lon)) * :R < :rad
  
ORDER BY distance";
            $params = [
                'lat' => deg2rad($lat),
                'lon' => deg2rad($lon),
                'minLat' => $minLat,
                'minLon' => $minLon,
                'maxLat' => $maxLat,
                'maxLon' => $maxLon,
                'service' => $model->service,
                'rad' => $rad,
                'R' => $R,
            ];
            $models = db()->createCommand($sql, $params)->queryAll();
            $items = [];
            foreach ($models as $agent) {
                $image = $agent['image'] ? $agent['image'] : '/drive/images/default/no_image.png';
                $items[] = [
                    'name' => $agent['business_name'],
                    'distance' => round($agent['distance'], 2),
                    'image' => Url::to([$image], true),
                    'rating' => $agent['rating'],
                    'latitude' => $agent['latitude'],
                    'longitude' => $agent['longitude'],
                    'location' => $agent['location'],
                    'till' => $agent['agent_no']
                ];
            }
            return [
                'status' => 1,
                'code' => 200,
                'items' => $items
            ];
        } else {
            return [
                'status' => 0,
                'message' => $model->errorLines
            ];
        }
    }

    /**
     * Sends request to agents.
     * @return array
     */
    public function actionRequest()
    {
        $model = new Request();
        if (($model->loadPost() || $model->loadJsonPost()) && $model->validate()) {
            $items = $this->getAgents($model);
            if (!empty($items)) {
                $tran = db()->beginTransaction();
                /* @var $client Client */
                $client = Yii::app()->user->identity;
                $request = new ServiceRequest();
                $request->client_id = $client->id;
                $request->amount = $model->amount;
                $request->service_id = $model->service;
                $count = 0;
                if ($request->save()) {
                    foreach ($items as $item) {
                        $not = new RequestNotification();
                        $not->agent_id = $item['id'];
                        $not->request_id = $request->id;
                        $not->status = 0;
                        if ($not->save()) {
                            $count++;
                        }
                    }
                    if ($count > 0) {
                        $tran->commit();
                        return [
                            'status' => 1,
                            'code' => 200,
                            'message' => 'Notification  sent to ' . $count . ' agents',
                            'agents' => $count
                        ];
                    } else {
                        $tran->rollBack();
                        return [
                            'status' => 0,
                            'code' => 200,
                            'message' => 'Failed to send request.'
                        ];
                    }
                } else {
                    return [
                        'status' => 0,
                        'code' => 200,
                        'message' => 'Failed to send request.',
                        'errors' => $request->errorList
                    ];
                }
            } else {
                return [
                    'status' => 0,
                    'code' => 200,
                    'message' => 'No agents found.'
                ];
            }
        }
    }

    /**
     * Cancels Service request.
     * @param integer $id Request Id
     * @return array
     */
    public function actionCancelRequest($id)
    {
        /* @var $client Client */
        $client = Yii::app()->user->identity;
        $model = ServiceRequest::findOne(['id' => $id, 'client_id' => $client->id]);
        if ($model) {
            $model->status = 2;
            if ($model->save()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Request cancelled'
                ];
            } else {
                return [
                    'status' => 0,
                    'code' => 500,
                    'message' => 'Failed to cancel request',
                    'errors' => $model->errorList
                ];
            }
        } else {
            return [
                'status' => 0,
                'code' => 200,
                'message' => 'Record Not found'
            ];
        }
    }

    public function actionResponses()
    {
        /* @var $client Client */
        /* @var $models ServiceRequest[] */
        $client = Yii::app()->user->identity;
        $models = ServiceRequest::findAll(['client_id' => $client->id, 'status' => 1]);
        $items = [];
        foreach ($models as $model) {
            $items[] = [
                'id' => $model->id,
                'agent' => $model->agent->business_name,
                'time' => $model->updated_at
            ];
        }
        return [
            'status' => 1,
            'code' => 200,
            'items' => $items
        ];
    }

    /**
     * Lists all requests
     * @return array
     */
    public function actionRequests($group = false)
    {
        /* @var $client Client */
        /* @var $models ServiceRequest[] */
        $client = Yii::app()->user->identity;
        $q = "SELECT r.id,r.agent_id,r.created_at,a.picture agent_image,ifnull(a.business_name,'-')business_name,amount,r.status,p.name,q.name service,p.logo
FROM wakala_service_request r 
LEFT JOIN wakala_agent a ON r.agent_id = a.id 
JOIN wakala_provider_service s ON s.id = r.service_id
JOIN wakala_service q ON s.service_id = q.id
JOIN wakala_service_provider p ON s.provider_id = p.id
WHERE r.client_id = :id AND r.status IN (0,1,3) ORDER BY r.created_at DESC";
        $models = db()->createCommand($q, ["id" => $client->id])->queryAll();
        $items = [];
        foreach ($models as $model) {
            $image = $model['agent_image'] ? $model['agent_image'] : '/drive/images/default/no_image.png';

            $item = [
                'id' => $model["id"],
                'name' => $model['name'] . " - " . $model['service'],
                'agent' => $model["business_name"],
                'agent_id' => $model['agent_id'],
                'agent_image' => Url::to([$image], true),
                'date' => date('d/m/Y', $model['created_at']),
                'amount' => number_format($model['amount'], 2),
                'logo' => Url::to([$model['logo']], true),
                'status' => $model['status']
            ];
            if ($group) {
                $date = $item['date'];
                if (!isset($items[$date])) {
                    $items[$date] = [
                        'name' => $date,
                        'items' => []
                    ];
                }
                $items[$date]['items'][] = $item;
            } else {
                $items[] = $item;
            }
        }
        if ($group) {
            foreach ($items as $k => $item) {
                unset($items[$k]);
                $items[] = $item;
            }
        }
        return [
            'status' => 1,
            'code' => 200,
            'items' => $items
        ];
    }

    public function actionProfile()
    {
        if (\request()->isGet) {
            /* @var $model Client */
            $model = Yii::app()->user->identity;
            $email = $model->email ?: "";
            return [
                'status' => 1,
                'code' => 200,
                'profile' => [
                    'name' => $model->name,
                    'mobile_no' => $model->mobile_no,
                    'gender' => $model->gender,
                    'image' => $model->picture,
                    'email' => $email
                ]
            ];
        } else {
            $model = new Profile();
            if ($model->loadPost()) {
                /* @var $client Client */
                $client = Yii::app()->user->identity;
                if ($model->gender) {
                    $client->gender = $model->gender;
                }
                if ($model->email) {
                    $client->email = $model->email;
                }
                if ($model->old_password && $model->new_password) {
                    if (!$client->validatePassword($model->old_password)) {
                        return [
                            'status' => 0,
                            'code' => 200,
                            'message' => 'Invalid password'
                        ];
                    }
                    $client->setPassword($model->new_password);
                }
                if ($client->save()) {
                    return [
                        'status' => 1,
                        'code' => 200,
                        'message' => 'Profile successfully updated.'
                    ];
                } else {
                    return [
                        'status' => 0,
                        'code' => 200,
                        'errors' => $model->errorList
                    ];
                }
            }
        }
    }

    /**
     * Lists available services
     * @return array
     */
    public function actionServices()
    {
        $providers = ServiceProvider::findAll(['active' => 1]);
        $items = [];
        foreach ($providers as $provider) {
            $models = ProviderService::findAll(['provider_id' => $provider->id, 'active' => 1]);
            if (!empty($models)) {
                $item = [
                    'name' => $provider->name,
                    'logo' => Url::to([$provider->logo], true)
                ];
                $services = [];
                foreach ($models as $model) {
                    $services[] = [
                        'name' => $model->service->name,
                        'id' => $model->id
                    ];
                }
                $item['services'] = $services;
                $items[] = $item;
            }
        }
        return [
            'status' => 1,
            'code' => 200,
            'items' => $items
        ];
    }

    /**
     * Checks system status
     * @return array
     */
    public function actionPulse()
    {
        return [
            'status' => 1,
            'code' => 200,
            'message' => 'OK'
        ];
    }

    /**
     * Update Fcm Token
     * @return array
     */
    public function actionFcmToken()
    {
        $token = $this->post('token');
        if ($token) {
            /* @var $agent Client */
            $agent = Yii::app()->user->identity;
            $agent->fcm_access_token = $token;
            if ($agent->save()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'success'
                ];
            } else {
                return [
                    'status' => 0,
                    'code' => 200,
                    'message' => 'Error',
                    'errors' => $agent->errorList
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 200,
            'message' => 'Invalid data'
        ];
    }

    /**
     * Request Detail
     * @param int $id ServiceRequest id.
     * @return array
     */
    public function actionRequestDetail($id)
    {
        $model = ServiceRequest::findModel($id, false);
        if ($model) {
            $request = [
                'id' => $model->id,
                'amount' => $model->amount,
                'provider' => $model->service->provider->name,
                'service' => $model->service->service->name,
                'time' => $model->created_at,
                'status' => $model->status
            ];
            if ($model->agent_id) {
                $svc = AgentService::findOne(['agent_id' => $model->agent_id, 'service_id' => $model->service_id]);
                $agent = $model->agent;
                $image = $agent->picture ? $agent->picture : '/drive/images/default/no_bg.jpg';
                $request['agent'] = [
                    'id' => $agent->id,
                    'name' => $agent->business_name,
                    'phone' => $agent->user->mobile_no,
                    'latitude' => $agent->latitude,
                    'longitude' => $agent->longitude,
                    'image' => Url::to([$image], true),
                    'rating' => $agent->rating
                ];
                if ($svc) {
                    $request['agent']['till'] = $svc->agent_no;
                }
            }
            return [
                'status' => 1,
                'code' => 200,
                'request' => $request
            ];
        }
        return [
            'status' => 0,
            'code' => 404,
            'message' => 'Not found'
        ];
    }

    /**
     * Update clients last position
     * @return array
     */
    public function actionPosition()
    {
        /* @var $model Client */
        $model = Yii::app()->user->identity;
        if ($model->loadPost()) {

            if ($model->save(false, ['last_latitude', 'last_longitude'])) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'success'
                ];
            } else {
                return [
                    'status' => 0,
                    'code' => 200,
                    'message' => 'Error',
                    'errors' => $model->errorList
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 200,
            'message' => 'Invalid data'
        ];
    }

    /**
     * Request password reset token
     * @return array
     */
    public function actionRequestPassword()
    {
        $model = new Password();
        $model->loadPost();
        if ($model->loadPost() && $model->validate()) {
            $client = Client::findOne(['mobile_no' => $model->phone]);
            if ($client) {
                if ($client->password_reset_token == false) {
                    $client->generatePasswordResetToken();
                    if ($client->save()) {
                        $sms = new ClientSms();
                        $sms->client_id = $client->id;
                        $sms->recipient = $client->mobile_no;
                        $sms->content = "Password reset code is: " . $client->password_reset_token;
                        if ($sms->save()) {
                            return [
                                'status' => 1,
                                'code' => 200,
                                'message' => 'Code successfully created and sent'
                            ];
                        }
                    } else {
                        return [
                            'status' => 0,
                            'code' => 400,
                            'message' => $client->errorList
                        ];
                    }
                } else {
                    return [
                        'status' => 0,
                        'code' => 400,
                        'message' => 'Reset token already generated'
                    ];
                }

            } else {
                return [
                    'status' => 0,
                    'code' => 404,
                    'message' => 'Not found'
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400,
            'message' => $model->errorList
        ];
    }

    /**
     * Resets password using reset token.
     * @return array
     */
    public function actionResetPassword()
    {
        $model = new Password(['scenario' => 'reset']);
        if ($model->loadPost() && $model->validate()) {
            $client = Client::findOne(['mobile_no' => $model->phone]);
            if ($client && $client->password_reset_token == $model->token) {
                $client->setPassword($model->password);
                $client->password_reset_token = null;
                if ($client->save()) {
                    return [
                        'status' => 1,
                        'code' => 200,
                        'message' => 'Reset success'
                    ];
                }
            } else {
                return [
                    'status' => 0,
                    'code' => 403,
                    'message' => 'Forbidden'
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400,
            'errors' => $model->errorList
        ];
    }

    /**
     * Rate agent
     * @return array
     */
    public function actionRate()
    {
        $model = new Rating();
        if ($model->loadPost() && $model->validate()) {
            /* @var $client Client */
            $client = Yii::app()->user->identity;
            $rating = AgentRating::getOrNew($client->id, $model->agent_id);
            $rating->comment = $model->comment;
            $rating->value = $model->value;
            $tran = db()->beginTransaction();
            if ($rating->save()) {
                $agent = $rating->agent;
                if ($agent->updateRatingAvg()) {
                    $tran->commit();
                    return [
                        'status' => 1,
                        'code' => 200,
                        'message' => 'Agent successfully rated.'
                    ];
                } else {
                    $tran->rollBack();
                    return [
                        'status' => 0,
                        'code' => 501,
                        'message' => 'Failed to rate agent.',
                        'errors' => $agent->errorList
                    ];
                }
            } else {
                return [
                    'status' => 0,
                    'code' => 200,
                    'message' => 'Failed to rate agent.',
                    'errors' => $rating->errorList
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 200,
            'message' => 'Failed to rate agent.'
        ];
    }


    public function actionRatings($id)
    {
        $models = AgentRating::findAll(['agent_id' => $id]);
        $items = [];
        foreach ($models as $model) {
            /* @var $model AgentRating */
            $client = $model->client;
            $value = $model->value == '' ? 0 : $model->value;
            $image = $client->picture ? $client->picture : '/drive/images/default/no_image.png';
            $items[] = [
                'id' => $model->id,
                'clientId' => $model->client_id,
                'clientName' => $client->name,
                'clientImage' => Url::to([$image], true),
                'comment' => $model->comment,
                'rating' => $value,
                'time' => format($model->created_at, 'date')
            ];
        }

        return [
            'status' => 1,
            'code' => 200,
            'items' => $items
        ];
    }

    public function actionTos()
    {
        $model = ToS::getInstance();
        return [
            'status' => 1,
            'code' => 200,
            'tos' => [
                'last_update' => format($model->last_update, 'date'),
                'content' => $model->en_content
            ]
        ];
    }

    public function actionAckNotification($id)
    {
        $model = ClientNotification::findOne($id);
        if ($model) {
            $model->pushed = 1;
            if ($model->save()) {
                return [
                    'status' => 1,
                    'code' => 200,
                    'message' => 'Success'
                ];
            }
        }
        return [
            'status' => 0,
            'code' => 400
        ];
    }
}