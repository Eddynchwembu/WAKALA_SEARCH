<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 4/4/2018
 * Time: 11:42 AM
 */


namespace app\models;

use modular\base\Model;

/**
 * Class Password
 *
 * Description of Password
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\models
 */
class Password extends Model
{
    public $password;
    public $phone;
    public $token;

    public function rules()
    {
        return [
            [['phone'], 'required'],
            ['phone', 'phone', 'countryCode' => '255'],
            [['password','token'],'required','on' => 'reset']
        ];
    }
}