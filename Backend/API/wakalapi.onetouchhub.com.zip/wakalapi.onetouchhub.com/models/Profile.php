<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 4/22/2018
 * Time: 2:26 PM
 */


namespace app\models;

use modular\base\Model;

/**
 * Class Profile
 *
 * Description of Profile
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\models
 */
class Profile extends Model
{
    public $email;
    public $name;
    public $gender;
    public $old_password;
    public $new_password;
    public $location;
    public $latitude;
    public $longitude;


    public function rules()
    {
        return [
            [['email', 'name', 'location'], 'string', 'max' => 200],
            [['longitude', 'latitude'], 'number'],
            ['email', 'email'],
            [['old_password', 'new_password'], 'string', 'max' => 16]
        ];
    }
}