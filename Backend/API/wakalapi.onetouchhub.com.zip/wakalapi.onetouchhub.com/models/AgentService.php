<?php

namespace app\models;

use app\models\SystemUser;
use modular\security\TrackedActiveRecord;
use Yii;

/**
 * This is the model class for table "{{%wakala_agent_service}}".
 *
 * @property string $id
 * @property string $agent_id
 * @property string $service_id
 * @property string $agent_no
 * @property int $active
 * @property string $created_at
 * @property int $created_by
 * @property string $updated_at
 * @property int $updated_by
 *
 * @property Agent $agent
 * @property SystemUser $createdBy
 * @property ProviderService $service
 * @property SystemUser $updatedBy
 */
class AgentService extends TrackedActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_agent_service}}';
    }

    public static function getOrNew($agentId, $serviceId)
    {
        $model = static::findOne(['agent_id'=>$agentId,'service_id'=>$serviceId]);
        if($model == null){
            $model = new static();
            $model->agent_id = $agentId;
            $model->service_id = $serviceId;
        }
        return $model;
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['agent_id', 'service_id'], 'required'],
            [['agent_id', 'service_id', 'created_at', 'created_by', 'updated_at', 'updated_by'], 'integer'],
            [['agent_no'], 'string', 'max' => 50],
            ['active', 'boolean'],
            [['agent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Agent::className(), 'targetAttribute' => ['agent_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['service_id'], 'exist', 'skipOnError' => true, 'targetClass' => ProviderService::className(), 'targetAttribute' => ['service_id' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'agent_id' => Yii::t('app', 'Agent'),
            'service_id' => Yii::t('app', 'Service'),
            'agent_no' => Yii::t('app', 'Agent No'),
            'active' => Yii::t('app', 'Active'),
            'created_at' => Yii::t('app', 'Created At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgent()
    {
        return $this->hasOne(Agent::className(), ['id' => 'agent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getService()
    {
        return $this->hasOne(ProviderService::className(), ['id' => 'service_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'updated_by']);
    }
}
