<?php

namespace app\models;

use modular\db\ActiveRecord;
use modular\traits\TimeTracker;
use Yii;

/**
 * This is the model class for table "{{%wakala_request_notification}}".
 *
 * @property string $id
 * @property string $request_id
 * @property string $agent_id
 * @property int $status
 * @property int $pushed [smallint(1)]
 * @property string $created_at
 * @property int $created_by
 * @property string $updated_at
 * @property int $updated_by
 *
 * @property Agent $agent
 * @property SystemUser $createdBy
 * @property ServiceRequest $request
 * @property SystemUser $updatedBy
 */
class RequestNotification extends ActiveRecord
{
    use TimeTracker;

    const STATUS_PENDING = 0;
    const STATUS_ACCEPTED = 1;
    const STATUS_REJECTED = 2;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_request_notification}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['request_id', 'agent_id', 'status', 'created_at', 'created_by', 'updated_at', 'updated_by'], 'integer'],
            [['request_id', 'agent_id'], 'required'],
            [['agent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Agent::className(), 'targetAttribute' => ['agent_id' => 'id']],
            [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => ServiceRequest::className(), 'targetAttribute' => ['request_id' => 'id']]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'request_id' => Yii::t('app', 'Request ID'),
            'agent_id' => Yii::t('app', 'Agent ID'),
            'status' => Yii::t('app', 'Status'),
            'created_at' => Yii::t('app', 'Created At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgent()
    {
        return $this->hasOne(Agent::className(), ['id' => 'agent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(ServiceRequest::className(), ['id' => 'request_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'updated_by']);
    }
}
