<?php

namespace app\models;

use modular\db\ActiveRecord;
use modular\traits\FileContainer;
use modular\traits\ModelFinder;
use modular\traits\TimeTracker;
use Yii;
use yii\web\IdentityInterface;

/**
 * This is the model class for table "{{%wakala_agent}}".
 *
 * @property string $id
 * @property int $user_id
 * @property string $code
 * @property string $fcm_access_token [varchar(100)]
 * @property string $business_name
 * @property string $business_tin
 * @property string $picture
 * @property int $rating
 * @property string $location_name
 * @property string $longitude
 * @property string $latitude
 * @property string $district
 * @property string $region
 * @property string $country
 * @property int $status
 * @property string $created_at
 * @property int $created_by
 * @property string $updated_at
 * @property int $updated_by
 *
 * @property SystemUser $createdBy
 * @property SystemUser $updatedBy
 * @property SystemUser $user
 */
class Agent extends ActiveRecord implements IdentityInterface
{
    use FileContainer, TimeTracker,ModelFinder;

    public function getUploadPath()
    {
        return "/images/agents/";
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_agent}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['code','user_id', 'business_name', 'business_tin', 'location_name', 'longitude', 'latitude', 'status'], 'required'],
            [['user_id', 'status', 'created_at', 'created_by', 'updated_at', 'updated_by'], 'integer'],
            [['longitude', 'rating', 'latitude'], 'number'],
            [['business_name', 'picture', 'location_name'], 'string', 'max' => 200],
            [['business_tin'], 'string', 'max' => 10],
            [['district', 'region', 'country'], 'string', 'max' => 100],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['updated_by' => 'id']],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'user_id' => Yii::t('app', 'User'),
            'business_name' => Yii::t('app', 'Business Name'),
            'business_tin' => Yii::t('app', 'Business TIN'),
            'picture' => Yii::t('app', 'Picture'),
            'rating' => Yii::t('app', 'Rating'),
            'location_name' => Yii::t('app', 'Location Name'),
            'longitude' => Yii::t('app', 'Longitude'),
            'latitude' => Yii::t('app', 'Latitude'),
            'district' => Yii::t('app', 'District'),
            'region' => Yii::t('app', 'Region'),
            'country' => Yii::t('app', 'Country'),
            'status' => Yii::t('app', 'Status'),
            'created_at' => Yii::t('app', 'Created At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'user_id']);
    }

    /**
     * Finds an identity by the given ID.
     * @param string|int $id the ID to be looked for
     * @return IdentityInterface the identity object that matches the given ID.
     * Null should be returned if such an identity cannot be found
     * or the identity is not in an active state (disabled, deleted, etc.)
     */
    public static function findIdentity($id)
    {
        // TODO: Implement findIdentity() method.
    }

    /**
     * Finds an identity by the given token.
     * @param mixed $token the token to be looked for
     * @param mixed $type the type of the token. The value of this parameter depends on the implementation.
     * For example, [[\yii\filters\auth\HttpBearerAuth]] will set this parameter to be `yii\filters\auth\HttpBearerAuth`.
     * @return IdentityInterface the identity object that matches the given token.
     * Null should be returned if such an identity cannot be found
     * or the identity is not in an active state (disabled, deleted, etc.)
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        return static::findBySql("SELECT a.* FROM wakala_agent a JOIN system_user u ON a.user_id = u.id WHERE u.access_token = :token", [":token" => $token])->one();
    }

    /**
     * Returns an ID that can uniquely identify a user identity.
     * @return string|int an ID that uniquely identifies a user identity.
     */
    public function getId()
    {
        return $this->user_id;
    }

    /**
     * Returns a key that can be used to check the validity of a given identity ID.
     *
     * The key should be unique for each individual user, and should be persistent
     * so that it can be used to check the validity of the user identity.
     *
     * The space of such keys should be big enough to defeat potential identity attacks.
     *
     * This is required if [[User::enableAutoLogin]] is enabled.
     * @return string a key that is used to check the validity of a given identity ID.
     * @see validateAuthKey()
     */
    public function getAuthKey()
    {
        // TODO: Implement getAuthKey() method.
    }

    /**
     * Validates the given auth key.
     *
     * This is required if [[User::enableAutoLogin]] is enabled.
     * @param string $authKey the given auth key
     * @return bool whether the given auth key is valid.
     * @see getAuthKey()
     */
    public function validateAuthKey($authKey)
    {
        // TODO: Implement validateAuthKey() method.
    }

    public function updateRatingAvg()
    {
        $q = "SELECT avg(value) FROM wakala_agent_rating WHERE agent_id = :id GROUP BY agent_id";
        $avg = db()->createCommand($q, [':id' => $this->id])->queryScalar();
        $this->rating = ($avg);
        return $this->save();
    }
}
