<?php

namespace app\models;

use modular\db\ActiveRecord;
use modular\traits\TimeTracker;
use Yii;

/**
 * This is the model class for table "{{%wakala_agent_rating}}".
 *
 * @property string $id
 * @property string $agent_id
 * @property string $client_id
 * @property int $value
 * @property string $comment
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Agent $agent
 * @property Client $client
 */
class AgentRating extends ActiveRecord
{
    use TimeTracker;

    public static function getOrNew($clientId, $agentId)
    {
        $model = static::findOne(['client_id' => $clientId, 'agent_id' => $agentId]);
        if ($model == false) {
            $model = new static();
            $model->client_id = $clientId;
            $model->agent_id = $agentId;
        }
        return $model;
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_agent_rating}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['agent_id', 'client_id', 'created_at', 'updated_at'], 'integer'],
            [['value',], 'number'],
            [['agent_id', 'value'], 'required'],
            [['comment'], 'string', 'max' => 500],
            [['agent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Agent::className(), 'targetAttribute' => ['agent_id' => 'id']],
            [['client_id'], 'exist', 'skipOnError' => true, 'targetClass' => Client::className(), 'targetAttribute' => ['client_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'agent_id' => Yii::t('app', 'Agent'),
            'client_id' => Yii::t('app', 'Client'),
            'value' => Yii::t('app', 'Value'),
            'comment' => Yii::t('app', 'Comment'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgent()
    {
        return $this->hasOne(Agent::className(), ['id' => 'agent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }
}
