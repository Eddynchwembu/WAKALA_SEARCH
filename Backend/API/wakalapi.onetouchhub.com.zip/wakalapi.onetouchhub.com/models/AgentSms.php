<?php

namespace app\models;

use modular\db\ActiveRecord;
use Yii;

/**
 * This is the model class for table "{{%wakala_agent_sms}}".
 *
 * @property string $id
 * @property string $agent_id
 * @property string $recipient
 * @property string $content
 * @property int $sent
 * @property string $created_at
 * @property string $sent_at
 *
 * @property Agent $agent
 */
class AgentSms extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_agent_sms}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['agent_id', 'recipient', 'content'], 'required'],
            [['agent_id', 'sent', 'created_at', 'sent_at'], 'integer'],
            [['recipient'], 'string', 'max' => 15],
            [['content'], 'string', 'max' => 150],
            [['agent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Agent::className(), 'targetAttribute' => ['agent_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'agent_id' => Yii::t('app', 'Agent ID'),
            'recipient' => Yii::t('app', 'Recipient'),
            'content' => Yii::t('app', 'Content'),
            'sent' => Yii::t('app', 'Sent'),
            'created_at' => Yii::t('app', 'Created At'),
            'sent_at' => Yii::t('app', 'Sent At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgent()
    {
        return $this->hasOne(Agent::className(), ['id' => 'agent_id']);
    }
}
