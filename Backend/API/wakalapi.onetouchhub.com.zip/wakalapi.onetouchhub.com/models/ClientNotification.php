<?php

namespace app\models;

use modular\db\ActiveRecord;
use modular\traits\TimeTracker;
use Yii;

/**
 * This is the model class for table "{{%wakala_client_notification}}".
 *
 * @property string $id
 * @property string $client_id
 * @property string $request_id
 * @property string $title
 * @property string $message
 * @property int $pushed
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Client $client
 * @property ServiceRequest $request
 */
class ClientNotification extends ActiveRecord
{
    use TimeTracker;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_client_notification}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_id'], 'required'],
            [['client_id', 'request_id', 'pushed', 'created_at', 'updated_at'], 'integer'],
            [['title'], 'string', 'max' => 50],
            [['message'], 'string', 'max' => 200],
            [['client_id'], 'exist', 'skipOnError' => true, 'targetClass' => Client::className(), 'targetAttribute' => ['client_id' => 'id']],
            [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => ServiceRequest::className(), 'targetAttribute' => ['request_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'client_id' => Yii::t('app', 'Client ID'),
            'request_id' => Yii::t('app', 'Request ID'),
            'title' => Yii::t('app', 'Title'),
            'message' => Yii::t('app', 'Message'),
            'pushed' => Yii::t('app', 'Pushed'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(ServiceRequest::className(), ['id' => 'request_id']);
    }
}
