<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 3/20/2018
 * Time: 4:54 PM
 */


namespace app\models;

use modular\base\Model;

/**
 * Class Request
 *
 * Description of Request
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\models
 */
class Request extends Model
{
    public $service;
    public $amount;
    public $latitude;
    public $longitude;
    public $radius;

    public function rules()
    {
        return [
            [['service', 'amount', 'longitude', 'latitude','radius'], 'required']
        ];
    }
}