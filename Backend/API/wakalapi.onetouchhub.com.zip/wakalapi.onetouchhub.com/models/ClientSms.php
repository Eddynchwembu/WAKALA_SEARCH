<?php

namespace app\models;

use modular\db\ActiveRecord;
use Yii;

/**
 * This is the model class for table "{{%wakala_client_sms}}".
 *
 * @property string $id
 * @property string $client_id
 * @property string $recipient
 * @property string $content
 * @property int $sent
 * @property string $created_at
 * @property string $sent_at
 *
 * @property Client $client
 */
class ClientSms extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_client_sms}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_id', 'recipient', 'content'], 'required'],
            [['client_id', 'sent', 'created_at', 'sent_at'], 'integer'],
            [['recipient'], 'string', 'max' => 15],
            [['content'], 'string', 'max' => 150],
            [['client_id'], 'exist', 'skipOnError' => true, 'targetClass' => Client::className(), 'targetAttribute' => ['client_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'client_id' => Yii::t('app', 'Client ID'),
            'recipient' => Yii::t('app', 'Recipient'),
            'content' => Yii::t('app', 'Content'),
            'sent' => Yii::t('app', 'Sent'),
            'created_at' => Yii::t('app', 'Created At'),
            'sent_at' => Yii::t('app', 'Sent At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }

    public function beforeSave($insert)
    {
        if($insert){
            $this->created_at = time();
        }
        return parent::beforeSave($insert);
    }
}
