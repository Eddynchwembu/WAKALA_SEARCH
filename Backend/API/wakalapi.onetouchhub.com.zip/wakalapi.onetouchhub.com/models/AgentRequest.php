<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 4/1/2018
 * Time: 6:17 PM
 */


namespace app\models;

use modular\base\Model;

/**
 * Class AgentRequest
 *
 * Description of AgentRequest
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\models
 */
class AgentRequest extends Model
{
    public $id;
    public $status;

    public function rules()
    {
        return [
            [['id', 'status'], 'required']
        ];
    }
}