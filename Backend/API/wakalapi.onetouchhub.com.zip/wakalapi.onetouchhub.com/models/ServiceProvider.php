<?php

namespace app\models;

use app\models\SystemUser;
use modular\security\TrackedActiveRecord;
use modular\traits\FileContainer;
use Yii;

/**
 * This is the model class for table "{{%wakala_service_provider}}".
 *
 * @property string $id
 * @property string $code
 * @property string $name
 * @property string $logo
 * @property int $active
 * @property string $created_at
 * @property int $created_by
 * @property string $updated_at
 * @property int $updated_by
 *
 * @property AgentService[] $wakalaAgentServices
 * @property SystemUser $createdBy
 * @property SystemUser $updatedBy
 */
class ServiceProvider extends TrackedActiveRecord
{
    use FileContainer;

    /**
     * @return string
     */
    public function getUploadPath()
    {
        return '/images/vendors/';
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_service_provider}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['code', 'name', 'logo'], 'required'],
            [['active', 'created_at', 'created_by', 'updated_at', 'updated_by'], 'integer'],
            [['code'], 'string', 'max' => 20],
            [['name'], 'string', 'max' => 100],
            [['logo'], 'string', 'max' => 200],
            [['code'], 'unique'],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'name' => Yii::t('app', 'Name'),
            'logo' => Yii::t('app', 'Logo'),
            'active' => Yii::t('app', 'Active'),
            'created_at' => Yii::t('app', 'Created At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWakalaAgentServices()
    {
        return $this->hasMany(AgentService::className(), ['provider_code' => 'code']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'updated_by']);
    }
}
