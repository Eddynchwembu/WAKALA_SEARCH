<?php

namespace app\models;

use modular\security\TrackedActiveRecord;
use Yii;

/**
 * This is the model class for table "{{%wakala_provider_service}}".
 *
 * @property string $id
 * @property string $provider_id
 * @property string $service_id
 * @property int $active
 * @property string $created_at
 * @property int $created_by
 * @property string $updated_at
 * @property int $updated_by
 *
 * @property AgentService[] $wakalaAgentServices
 * @property SystemUser $createdBy
 * @property ServiceProvider $provider
 * @property Service $service
 * @property SystemUser $updatedBy
 *
 * @property string $name
 */
class ProviderService extends TrackedActiveRecord
{

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_provider_service}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['provider_id', 'service_id'], 'required'],
            [['provider_id', 'service_id', 'active', 'created_at', 'created_by', 'updated_at', 'updated_by'], 'integer'],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['created_by' => 'id']],
            //[['provider_id'], 'exist', 'skipOnError' => true, 'targetClass' => ServiceProvider::className(), 'targetAttribute' => ['provider_id' => 'id']],
            //[['service_id'], 'exist', 'skipOnError' => true, 'targetClass' => Service::className(), 'targetAttribute' => ['service_id' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => SystemUser::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'provider_id' => Yii::t('app', 'Provider'),
            'service_id' => Yii::t('app', 'Service'),
            'active' => Yii::t('app', 'Active'),
            'created_at' => Yii::t('app', 'Created At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWakalaAgentServices()
    {
        return $this->hasMany(AgentService::className(), ['service_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProvider()
    {
        return $this->hasOne(ServiceProvider::className(), ['id' => 'provider_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getService()
    {
        return $this->hasOne(Service::className(), ['id' => 'service_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(SystemUser::className(), ['id' => 'updated_by']);
    }

    public function getName()
    {
        return $this->provider->name . " : " . $this->service->name;
    }
}
