<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 3/20/2018
 * Time: 1:45 PM
 */


namespace app\models;

use modular\base\Model;

/**
 * Class Client
 *
 * Description of Client
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\forms
 */
class Register extends Model
{
    public $first_name;
    public $last_name;
    public $mobile_no;
    public $gender;
    public $password;

    public $email;
    public $business_name;
    public $business_tin;
    public $location;
    public $latitude;
    public $longitude;

    public function rules()
    {
        return [
            [['last_name', 'first_name', 'mobile_no', 'password'], 'required'],
            //[['gender'], 'required', 'on' => 'client'],
            [['business_name', 'business_tin', 'location', 'latitude', 'longitude', 'email'], 'required', 'on' => 'agent'],
            ['email', 'email'],
            ['mobile_no', 'phone', 'countryCode' => '255'],
            ['mobile_no', 'unique', 'targetClass' => Client::className(), 'targetAttribute' => 'mobile_no', 'on' => 'client', 'message' => '{attribute} "{value}" is already registered.']
        ];
    }


    public function registerClient()
    {
        $this->scenario = 'client';
        if ($this->validate()) {
            $model = new Client();
            $model->first_name = $this->first_name;
            $model->last_name = $this->last_name;
            $model->gender = $this->gender;
            $model->status = 10;
            $model->mobile_no = $this->mobile_no;
            $model->setPassword($this->password);
            $model->generateAuthKey();
            return $model->save();
        } else {
            return false;
        }

    }

    public function registerAgent()
    {
        if ($this->validate()) {
            $tran = db()->beginTransaction();
            $user = new SystemUserAgent();
            $user->first_name = $this->first_name;
            $user->last_name = $this->last_name;
            $user->mobile_no = $this->mobile_no;
            $user->username = $this->mobile_no;
            $user->email = $this->email;
            $user->setPassword($this->password);
            $user->generateAuthKey();
            $user->type = 'agent';
            $user->status = 1;
            if ($user->save()) {
                $model = new Agent();
                $model->code  = sprintf("%05s", $user->id);
                $model->user_id = $user->id;
                $model->business_tin = $this->business_tin;
                $model->business_name = $this->business_name;
                $model->location_name = $this->location;
                $model->latitude = $this->latitude;
                $model->longitude = $this->longitude;
                $model->status = 1;
                $model->created_by = $user->id;
                $model->updated_by = $user->id;
                if ($model->save()) {
                    $tran->commit();
                    return true;
                } else {
                    $tran->rollBack();
                }
            }
            $this->addErrors($user->errors);
            return false;
        }
        return false;
    }

    public function attributeLabels()
    {
        return[
          'business_tin'=>'Business TIN',
            'lat'=>'latitude',
            'lng'=>'Longitude'
        ];
    }
}