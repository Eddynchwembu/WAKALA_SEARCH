<?php

namespace app\models;

use modular\db\ActiveRecord;
use modular\traits\TimeTracker;
use Yii;

/**
 * This is the model class for table "{{%wakala_agent_log}}".
 *
 * @property string $id
 * @property string $service_id
 * @property string $service_date
 * @property string $agent_id
 * @property string $client_no
 * @property string $amount
 * @property string $comment
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Agent $agent
 * @property ProviderService $service
 */
class AgentLog extends ActiveRecord
{
    use TimeTracker;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_agent_log}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['service_id', 'agent_id', 'client_no', 'amount'], 'required'],
            [['service_id', 'agent_id', 'created_at', 'updated_at'], 'integer'],
            ['service_date', 'date'],
            [['amount'], 'number'],
            [['client_no'], 'string', 'max' => 15],
            [['comment'], 'string', 'max' => 500],
            [['agent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Agent::className(), 'targetAttribute' => ['agent_id' => 'id']],
            [['service_id'], 'exist', 'skipOnError' => true, 'targetClass' => ProviderService::className(), 'targetAttribute' => ['service_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'service_id' => Yii::t('app', 'Service ID'),
            'agent_id' => Yii::t('app', 'Agent ID'),
            'client_no' => Yii::t('app', 'Client No'),
            'amount' => Yii::t('app', 'Amount'),
            'comment' => Yii::t('app', 'Comment'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgent()
    {
        return $this->hasOne(Agent::className(), ['id' => 'agent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getService()
    {
        return $this->hasOne(ProviderService::className(), ['id' => 'service_id']);
    }
}
