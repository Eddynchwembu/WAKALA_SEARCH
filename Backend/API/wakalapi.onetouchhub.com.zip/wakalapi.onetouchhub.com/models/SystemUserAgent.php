<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 3/29/2018
 * Time: 7:08 PM
 */


namespace app\models;

/**
 * Class UserAgent
 *
 * Description of UserAgent
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\modules\wakala\models
 */
class SystemUserAgent extends SystemUser
{
    public function rules(){
        return array_merge(parent::rules(),[
            ['mobile_no', 'phone', 'countryCode' => '255'],
        ]);
    }
}