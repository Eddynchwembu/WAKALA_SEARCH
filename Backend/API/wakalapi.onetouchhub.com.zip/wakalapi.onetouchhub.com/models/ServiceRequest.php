<?php

namespace app\models;

use modular\db\ActiveRecord;
use modular\traits\ModelFinder;
use modular\traits\TimeTracker;
use Yii;

/**
 * This is the model class for table "{{%wakala_service_request}}".
 *
 * @property string $id
 * @property string $client_id
 * @property string $service_id
 * @property string $agent_id
 * @property string $amount
 * @property string $comment
 * @property int $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property RequestNotification[] $wakalaRequestNotifications
 * @property Agent $agent
 * @property Client $client
 * @property ProviderService $service
 */
class ServiceRequest extends ActiveRecord
{
    use TimeTracker,ModelFinder;

    const STATUS_PENDING = 0;
    const STATUS_ACTIVE = 1;
    const STATUS_CANCELLED = 2;
    const STATUS_SERVED = 3;
    const STATUS_EXPIRED = 4;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_service_request}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_id', 'service_id'], 'required'],
            [['client_id', 'service_id', 'agent_id', 'status', 'created_at', 'updated_at'], 'integer'],
            [['amount'], 'number'],
            [['comment'], 'string', 'max' => 250],
            [['agent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Agent::className(), 'targetAttribute' => ['agent_id' => 'id']],
            [['client_id'], 'exist', 'skipOnError' => true, 'targetClass' => Client::className(), 'targetAttribute' => ['client_id' => 'id']],
            [['service_id'], 'exist', 'skipOnError' => true, 'targetClass' => ProviderService::className(), 'targetAttribute' => ['service_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'client_id' => Yii::t('app', 'Client ID'),
            'service_id' => Yii::t('app', 'Service ID'),
            'agent_id' => Yii::t('app', 'Agent ID'),
            'amount' => Yii::t('app', 'Amount'),
            'comment' => Yii::t('app', 'Comment'),
            'status' => Yii::t('app', 'Status'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWakalaRequestNotifications()
    {
        return $this->hasMany(RequestNotification::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgent()
    {
        return $this->hasOne(Agent::className(), ['id' => 'agent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getService()
    {
        return $this->hasOne(ProviderService::className(), ['id' => 'service_id']);
    }
}
