<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 3/20/2018
 * Time: 4:17 PM
 */


namespace app\models;

use modular\base\Model;

/**
 * Class Login
 *
 * Description of Login
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\models
 */
class Login extends Model
{
    public $username;
    public $password;

    public function rules()
    {
        return [
            [['username', 'password'], 'required'],
            ['username', 'phone', 'countryCode' => '255'],
        ];
    }
}