<?php

namespace app\models;

use modular\db\ActiveRecord;
use modular\traits\SingletonModel;
use Yii;

/**
 * This is the model class for table "{{%wakala_tos}}".
 *
 * @property string $id
 * @property string $last_update
 * @property string $sw_content
 * @property string $en_content
 * @property string $created_at
 * @property int $created_by
 * @property string $updated_at
 * @property int $updated_by
 *
 * @property SystemUser $createdBy
 * @property SystemUser $updatedBy
 */
class ToS extends ActiveRecord
{
    use SingletonModel;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%wakala_tos}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['created_at', 'created_by', 'updated_at', 'updated_by'], 'integer'],
            ['last_update', 'date'],
            [['sw_content', 'en_content'], 'required'],
            [['sw_content', 'en_content'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'last_update' => Yii::t('app', 'Last Update'),
            'sw_content' => Yii::t('app', 'Swahili Content'),
            'en_content' => Yii::t('app', 'English Content'),
            'created_at' => Yii::t('app', 'Created At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

}
