<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 4/6/2018
 * Time: 9:42 PM
 */


namespace app\models;

use modular\base\Model;

/**
 * Class RequestSearch
 *
 * Description of RequestSearch
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\models
 */
class Search extends Model
{
    public $phone;
    public $date;
    public $service;


    public function rules()
    {
        return [
            ['phone', 'phone', 'countryCode' => '255'],
            [['phone', 'date', 'service'], 'safe']
        ];
    }
}