<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 3/21/2018
 * Time: 11:18 AM
 */


namespace app\models;

use modular\base\Model;

/**
 * Class Rating
 *
 * Description of Rating
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\models
 */
class Rating extends Model
{
    public $agent_id;
    public $value;
    public $comment;


    public function rules()
    {
        return [
            [['value', 'agent_id'], 'required'],
            ['comment', 'string', 'max' => 250]
        ];
    }
}