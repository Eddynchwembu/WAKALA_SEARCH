<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 4/1/2018
 * Time: 11:43 AM
 */


namespace app\commands;

use app\components\Firebase;
use app\components\Sms;
use app\models\AgentSms;
use app\models\RequestNotification;
use yii\console\Controller;
use yii\helpers\Url;

/**
 * Class AgentController
 *
 * Description of AgentController
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\commands
 */
class AgentController extends Controller
{
    public function actionCheckNotifications()
    {
        /* @var $models RequestNotification[] */
        $models = RequestNotification::findAll(['pushed' => 0]);
        $fcm = new Firebase(['authKey' => 'AIzaSyA5jUeAvIV5wbMIz0tjRG2TAQ0pveQ7fxs']);
        foreach ($models as $model) {
            $agent = $model->agent;
            if ($agent->fcm_access_token) {
                $service = $model->request->service;
                $response = $fcm->sendCustomNotification($agent->fcm_access_token, [
                    'for' => 'agent',
                    'id' => $model->id,
                    'client' => $model->request->client->name,
                    'message' => $service->provider->name . " " . $service->service->name . " " . $model->request->amount,
                    'time' => $model->created_at,
                    'account' => $agent->business_name,
                    'image' => Url::to([$service->provider->logo], true)
                ]);
                var_dump($response);
//                if ($response != null && $response['success'] == '1') {
//                    $model->pushed = 1;
//                    $model->save();
//                }
            }

        }
    }

    public function actionSendSms(){
        $models = AgentSms::findAll(['sent'=>0]);
        /* @var $sms Sms */
        $sms = \Yii::$app->get('sms');
        $sms->send("Ilivehere",'255766101680');
        foreach ($models as $model) {
            $sms->send($model->content,$model->recipient);
            $model->sent = 1;
            $model->save();
        }
    }
}