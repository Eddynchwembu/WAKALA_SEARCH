<?php
/*
 * Copyright (c) 2018 ramaj93@yahoo.com
 * All rights reserved.
 * Date: 4/1/2018
 * Time: 11:43 AM
 */


namespace app\commands;

use app\components\Firebase;
use app\components\Sms;
use app\models\ClientNotification;
use app\models\ClientSms;
use app\models\RequestNotification;
use yii\console\Controller;
use yii\helpers\Url;

/**
 * Class AgentController
 *
 * Description of AgentController
 *
 * @author Ramadan Juma (ramaj93@yahoo.com)
 *
 * @package app\commands
 */
class ClientController extends Controller
{
    public function actionCheckNotifications()
    {
        /* @var $models ClientNotification[] */
        $models = ClientNotification::findAll(['pushed' => 0]);
        $fcm = new Firebase(['authKey' => 'AIzaSyA5jUeAvIV5wbMIz0tjRG2TAQ0pveQ7fxs']);
        foreach ($models as $model) {
            $client = $model->client;
            if ($client->fcm_access_token) {
                $message = [
                    'for' => 'client',
                    'id' => $model->id,
                    'message' => $model->message,
                    'time' => $model->created_at,
                    'account' => $model->client->mobile_no
                ];
                if ($model->request_id) {
                    $message['type'] = 0;//request feedback
                    $message['request_id'] = $model->request_id;
                    $message['agent'] = $model->request->agent->business_name;
                    $message['image'] = Url::to([$model->request->service->provider->logo], true);
                } else {
                    $message['type'] = 1; //custom
                    $message['title'] = $model->title;
                }
                $response = $fcm->sendCustomNotification($client->fcm_access_token, $message);

//                if ($response != null && $response['success'] == '1') {
//                    $model->pushed = 1;
//                    $model->save();
//                }
            }

        }
    }

    public function actionSendSms()
    {
        $models = ClientSms::findAll(['sent' => 0]);
        foreach ($models as $model) {
            /* @var $sms Sms */
            $sms = \Yii::$app->get('sms');
            $sms->send($model->content, $model->recipient);
            $model->sent = 1;
            $model->save();
        }
    }


}