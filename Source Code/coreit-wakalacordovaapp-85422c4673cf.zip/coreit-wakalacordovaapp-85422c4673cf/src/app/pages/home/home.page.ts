import {Component, OnInit} from '@angular/core';
import {RestService} from '../../providers/rest.service';
import {ActionSheetController} from '@ionic/angular';
import {Router} from '@angular/router';

@Component({
    selector: 'app-home',
    templateUrl: 'home.page.html',
    styleUrls: ['home.page.scss']
})
export class HomePage implements OnInit {

    items: any = [];

    constructor(private restService: RestService,
                private router: Router,
                private sheet: ActionSheetController) {
    }

    loadItems() {
        return this.restService.getServices().subscribe(resp => {
            if (resp.status === 1) {
                this.items = resp.items;
            } else {

            }
        });
    }

    doRefresh(event) {
        console.log('Begin async operation');
        this.loadItems();
        event.target.complete();
    }

    ngOnInit(): void {
        this.loadItems();
    }

    async presentActionSheet(services) {
        const items = [];
        for (let i = 0; i < services.length; i++) {
            items.push({
                text: services[i].name,
                handler: () => {
                    this.router.navigateByUrl('tabs/home/service/' + services[i].id + '/' + services[i].name);
                }
            });
        }
        items.push({
            text: 'Cancel',
            icon: 'close',
            role: 'cancel'
        });
        const actionSheet = await this.sheet.create({
            header: 'Services',
            buttons: items
        });
        await actionSheet.present();
    }

    onServiceClick(item) {
        this.presentActionSheet(item.services);
    }
}
