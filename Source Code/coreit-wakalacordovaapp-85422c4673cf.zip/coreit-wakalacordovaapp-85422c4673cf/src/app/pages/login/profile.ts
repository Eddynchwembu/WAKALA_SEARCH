export class Profile {
    'id': string;
    'name': string;
    'mobile': string;
    'image': string;
}
