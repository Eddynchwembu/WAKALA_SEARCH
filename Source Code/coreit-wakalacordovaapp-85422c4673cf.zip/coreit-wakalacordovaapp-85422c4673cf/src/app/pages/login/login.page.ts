import {Component, OnInit} from '@angular/core';
import {NgForm} from '@angular/forms';
import {UserData} from '../../providers/user-data';
import {UserOptions} from '../../interfaces/user-options';
import {RestService} from '../../providers/rest.service';
import {LoadingController, ToastController} from '@ionic/angular';
import {Router} from '@angular/router';
import {RegisterOptions} from '../../interfaces/register-options';

@Component({
    selector: 'app-login',
    templateUrl: './login.page.html',
    styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
    login: UserOptions = {username: '', password: '', token: ''};
    register: RegisterOptions = {first_name: null, last_name: null, password: null, mobile_no: null};
    agent = {username: '', password: ''};
    submitted = false;
    tab = 'client';
    showPasswordText = false;
    loading: any;

    constructor(public userData: UserData,
                private restService: RestService,
                private router: Router,
                private toastController: ToastController, private  loader: LoadingController) {
    }

    ngOnInit() {
    }

    async presentLoading() {
        this.loading = await this.loader.create({
            message: 'Please wait. . .'
        });
        return await this.loading.present();
    }

    dismissLoading() {
        if (this.loading != null) {
            this.loading.dismiss();
        }
    }

    async showToast(msg) {
        const toast = await this.toastController.create({
            message: msg,
            duration: 2000
        });
        toast.present();
    }

    onRegister(form: NgForm) {
        if (form.valid) {
            this.presentLoading().then(_ => {
                this.restService.register(this.register).subscribe(data => {
                    this.dismissLoading();
                    if (data.status === 1) {
                        this.userData.login(data).then(_ => {
                            this.showToast('Registration successfully');
                            this.router.navigateByUrl('login');
                        });
                    } else {
                        this.showToast('Registration failed.');
                    }
                });
            });

        }
    }

    onLogin(form: NgForm) {
        this.submitted = true;
        if (form.valid) {
            this.presentLoading().then(_ => {
                this.restService.login(this.login).subscribe(data => {
                    this.dismissLoading();
                    if (data.status === 1) {
                        this.userData.login(data).then(_ => {
                            this.router.navigateByUrl('tabs/home');
                        });
                    } else {
                        this.showToast('Login failed, check username & password.');
                    }
                });
            });

        }
    }

}
