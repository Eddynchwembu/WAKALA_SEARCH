import {Profile} from './profile';

export class Login {
    'status': number;
    'message': string;
    'code': string;
    'access_token': string;
    'fcm_access_token': string;
    'auth_data': string;
    'username': string;
    'profile': Profile;
}
