import {Component, OnInit} from '@angular/core';
import {RestService} from '../../providers/rest.service';
import {ActivatedRoute} from '@angular/router';
import {Geolocation} from '@ionic-native/geolocation/ngx';
import {Map, latLng, tileLayer, Layer, marker, icon} from 'leaflet';
import 'leaflet-routing-machine';
import {LoadingController, ToastController} from '@ionic/angular';

declare var L: any;

@Component({
    selector: 'app-transaction',
    templateUrl: './transaction.page.html',
    styleUrls: ['./transaction.page.scss'],
})
export class TransactionPage implements OnInit {
    model: any = {};
    coords = null;
    map: any;
    active = false;
    marker: any;
    loading: any;
    gotLocation = false;

    constructor(private api: RestService,
                private route: ActivatedRoute,
                private geolocation: Geolocation,
                private toast: ToastController,
                private loader: LoadingController) {
    }

    async presentLoading() {
        this.loading = await this.loader.create({
            message: 'Please wait. . .'
        });
        return await this.loading.present();
    }

    dismissLoading() {
        if (this.loading != null) {
            this.loading.dismiss();
        }
    }

    updateMap() {
        if (this.map == null) {
            this.map = new Map('t-map');
            tileLayer('http://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
                attribution: 'edupala.com © ',
            }).addTo(this.map);
            this.marker.addTo(this.map);
        }
        this.map.setView(this.coords, 13);
    }

    ionViewDidEnter() {
        const coords = localStorage.getItem('currentLocation');
        if (coords != null) {
            this.gotLocation = true;
        }
        this.coords = coords == null ? [0, 0] : JSON.parse(coords);
        this.marker = marker([this.coords[0], this.coords[1]], {
            icon: icon({
                iconUrl: 'assets/icon/client_marker.png',
                iconSize: [48, 48]
            })
        });
        this.updateMap();
        this.active = true;
    }

    async showToast(msg) {
        const toast = await this.toast.create({
            message: msg,
            duration: 2000
        });
        toast.present();
    }

    ngOnInit() {
        const id = this.route.snapshot.paramMap.get('id');
        this.presentLoading().then(_ => {
            this.geolocation.getCurrentPosition({timeout: 10000, enableHighAccuracy: true, maximumAge: 3600})
                .then((resp) => {
                    this.dismissLoading();
                    this.coords = [resp.coords.latitude, resp.coords.longitude];
                    this.gotLocation = true;
                    localStorage.setItem('currentLocation', JSON.stringify(this.coords));
                    if (this.active) {
                        this.updateMap();
                    }
                }).catch((error) => {
                this.dismissLoading();
                this.showToast('Failed to get current location');
            });
            this.api.getTransaction(id).subscribe(data => {
                if (data.status === 1) {
                    const item = data.request;
                    this.model = item;
                    if (item.agent !== null) {
                        if (!this.gotLocation) {
                            this.coords = [item.agent.latitude, item.agent.longitude];
                            this.updateMap();
                        }
                        const ctrl = L.Routing.control({
                            waypoints: [
                                L.latLng(this.coords[0], this.coords[1]),
                                L.latLng(item.agent.latitude, item.agent.longitude)
                            ],
                            show: false,
                            createMarker: () => null,
                            router: new L.Routing.OSRMv1({
                                serviceUrl: this.api.osrmUrl
                            })
                        }).addTo(this.map);
                        ctrl._container.style.display = 'None';
                        marker([item.agent.latitude, item.agent.longitude])
                            .addTo(this.map)
                            .bindPopup('<b>Name</b>' + item.agent.name + '<br><b>Till:</b>' + item.agent.till)
                            .openPopup();
                    }

                }
            });
        });

    }

}
