import {Component, OnInit} from '@angular/core';
import {RestService} from '../../providers/rest.service';
import {Router} from '@angular/router';
import {LoadingController} from '@ionic/angular';

@Component({
    selector: 'app-transactions',
    templateUrl: 'transactions.page.html',
    styleUrls: ['transactions.page.scss']
})
export class TransactionsPage implements OnInit {
    groups = [];
    loading: any;

    constructor(private restService: RestService,
                private router: Router,
                private loader: LoadingController) {

    }

    ngOnInit(): void {
        this.loadItems();
    }

    async presentLoading() {
        this.loading = await this.loader.create({
            message: 'Please wait. . .'
        });
        return await this.loading.present();
    }

    dismissLoading() {
        if (this.loading != null) {
            this.loading.dismiss();
        }
    }

    loadItems() {
        this.presentLoading();
        return this.restService.getTransactions().subscribe(resp => {
            this.dismissLoading();
            if (resp.status === 1) {
                this.groups = resp.items;
            } else {

            }
        });
    }

    removeItems(item) {

    }

    doRefresh(event) {
        console.log('Begin async operation');
        this.loadItems();
        event.target.complete();
    }

    onItemClick(session) {
        this.restService.setTransaction(session);
        this.router.navigateByUrl('tabs/transactions/item/' + session.id);
    }
}
