import {Component, OnInit} from '@angular/core';
import {icon, latLng, Layer, Map, marker, tileLayer} from 'leaflet';
import {ActivatedRoute, Router} from '@angular/router';
import {Geolocation} from '@ionic-native/geolocation/ngx';
import {SearchOptions} from '../../interfaces/search-options';
import {NgForm} from '@angular/forms';
import {RestService} from '../../providers/rest.service';
import {LoadingController, ToastController} from '@ionic/angular';
import {Storage} from '@ionic/storage';

@Component({
    selector: 'app-service',
    templateUrl: './service.page.html',
    styleUrls: ['./service.page.scss'],
})
export class ServicePage implements OnInit {

    map: Map;
    serviceName: string;
    form: SearchOptions = {amount: null, service: null, latitude: null, longitude: null, radius: '1'};
    coords: any = [0, 0];
    viewEntered = false;
    submitted = false;
    marker: any = null;
    loading: any;
    hasAgents = false;

    constructor(private route: ActivatedRoute,
                private geolocation: Geolocation,
                private rest: RestService,
                private router: Router,
                private loader: LoadingController,
                private toaster: ToastController,
                private storage: Storage) {
    }

    updateMap() {
        if (this.map == null) {
            this.map = new Map('mapId');
            tileLayer('http://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
                attribution: 'edupala.com © ',
            }).addTo(this.map);
            this.marker.addTo(this.map);
        }
        this.map.setView(this.coords, 13);
    }

    ionViewDidEnter() {
        this.form.service = this.route.snapshot.paramMap.get('serviceId');
        console.log(this.form);
        this.serviceName = this.route.snapshot.paramMap.get('serviceName');
        const coords = localStorage.getItem('currentLocation');
        this.coords = coords == null ? [0, 0] : JSON.parse(coords);
        this.marker = marker([this.coords[0], this.coords[1]], {
            icon: icon({
                iconUrl: 'assets/icon/client_marker.png',
                iconSize: [48, 48]
            })
        });
        this.updateMap();
        this.viewEntered = true;
    }

    async showToast(msg) {
        const toast = await this.toaster.create({
            message: msg,
            duration: 2000
        });
        toast.present();
    }

    async presentLoading() {
        this.loading = await this.loader.create({
            message: 'Please wait. . .'
        });
        return await this.loading.present();
    }

    dismissLoading() {
        if (this.loading != null) {
            this.loading.dismiss();
        }
    }

    ngOnInit() {
        this.presentLoading().then(_ => {
            this.geolocation.getCurrentPosition({timeout: 10000, enableHighAccuracy: true, maximumAge: 3600})
                .then((resp) => {
                    this.dismissLoading();
                    this.coords = [resp.coords.latitude, resp.coords.longitude];
                    localStorage.setItem('currentLocation', JSON.stringify(this.coords));
                    console.log('got location');
                    if (this.viewEntered) {
                        this.updateMap();
                    }
                }).catch((error) => {
                this.dismissLoading();
                this.showToast('Failed to get current location');
                console.log('Error getting location', error);
            });
            const watch = this.geolocation.watchPosition();
            watch.subscribe((resp) => {
                this.coords = [resp.coords.latitude, resp.coords.longitude];
                this.form.latitude = resp.coords.latitude;
                this.form.longitude = resp.coords.longitude;
                // console.log('got location');
                if (this.marker != null) {
                    this.marker.setLatLng(this.coords);
                }
                localStorage.setItem('currentLocation', JSON.stringify(this.coords));
                if (this.viewEntered) {
                    this.updateMap();
                }
            });
        });

    }

    onSubmit(form: NgForm) {
        if (form.valid) {
            this.presentLoading().then(_ => {
                this.rest.submitRequest(this.form).subscribe(resp => {
                    console.log(JSON.stringify(resp));
                    this.dismissLoading();
                    if (resp.status === 1) {
                        this.router.navigateByUrl('tabs/transactions');
                    } else {
                        this.showToast('Failed to submit the request.');
                    }
                });
            });
        }
    }

    onSearch(form: NgForm) {
        this.submitted = true;
        if (form.valid) {
            this.presentLoading().then(_ => {
                this.storage.get('app.setting').then(setting => {
                    this.form.radius = setting.radius;
                    this.rest.searchAgents(this.form).subscribe(resp => {
                        this.dismissLoading();
                        if (resp.status === 1) {
                            const items = resp.items;
                            this.hasAgents = items.length > 0;
                            if (items.length > 0) {
                                for (let i = 0; i < items.length; i++) {
                                    const item = items[i];
                                    marker([item.latitude, item.longitude]).addTo(this.map)
                                        .bindPopup(item.name + '<br><b>Distance:</b> ' + item.distance + '<br><b>Till:</b>' + item.till)
                                        .openPopup();
                                }
                            } else {
                                this.showToast('No agents were found nearby.');
                            }
                        } else {
                            this.showToast('No agents were found nearby.');
                        }
                    });
                }).catch(err => {
                    this.dismissLoading();
                    this.showToast('No agents were found nearby.');
                    this.router.navigateByUrl('tab/profile');
                });
            });

        }
    }
}

