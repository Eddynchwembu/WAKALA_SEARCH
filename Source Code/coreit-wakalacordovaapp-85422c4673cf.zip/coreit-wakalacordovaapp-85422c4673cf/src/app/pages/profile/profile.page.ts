import {Component, OnInit} from '@angular/core';
import {Storage} from '@ionic/storage';
import {SettingOptions} from '../../interfaces/setting-options';
import {PopoverController} from '@ionic/angular';
import {MenuPage} from './menu-popover';

@Component({
    selector: 'app-profile',
    templateUrl: 'profile.page.html',
    styleUrls: ['profile.page.scss']
})
export class ProfilePage implements OnInit {
    setting: SettingOptions = {radius: '1', mode: 'walking', broadcast: true};

    constructor(private storage: Storage, public popoverCtrl: PopoverController) {
    }

    updateSetting() {
        this.storage.set('app.setting', this.setting);
    }

    async presentPopover(event: Event) {
        const popover = await this.popoverCtrl.create({
            component: MenuPage,
            event
        });
        await popover.present();
    }

    ngOnInit(): void {
        this.storage.get('app.setting').then(setting => {
            if (setting != null) {
                this.setting = setting;
            }
        });
    }
}
