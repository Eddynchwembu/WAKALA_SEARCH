import {Component} from '@angular/core';

import {PopoverController} from '@ionic/angular';
import {UserData} from '../../providers/user-data';
import {Router} from '@angular/router';

@Component({
    template: `
        <ion-list>
            <ion-item button (click)="changePassword()">
                <ion-label>Change Password</ion-label>
            </ion-item>
            <ion-item button (click)="logOut()">
                <ion-label>Logout</ion-label>
            </ion-item>
        </ion-list>
    `
})
export class MenuPage {
    constructor(public popoverCtrl: PopoverController,
                public userData: UserData,
                private router: Router) {
    }

    support() {
        // this.app.getRootNavs()[0].push('/support');
        this.popoverCtrl.dismiss();
    }

    close() {
        this.popoverCtrl.dismiss();
    }

    changePassword() {

    }

    logOut() {
        this.userData.logout().then(_ => {
            this.close();
            this.router.navigateByUrl('login');
        });
    }
}
