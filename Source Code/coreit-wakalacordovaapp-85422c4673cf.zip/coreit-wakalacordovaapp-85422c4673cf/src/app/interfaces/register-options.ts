export interface RegisterOptions {
    first_name: string;
    last_name: string;
    mobile_no: string;
    password: string;
}
