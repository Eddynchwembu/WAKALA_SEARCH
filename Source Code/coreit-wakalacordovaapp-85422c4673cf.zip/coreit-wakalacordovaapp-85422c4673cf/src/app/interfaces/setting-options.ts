export interface SettingOptions {
    radius: string;
    mode: string;
    broadcast: boolean;
}
