export interface SearchOptions {
    amount: string;
    service: string;
    latitude: number;
    longitude: number;
    radius: string;
}
