import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UserOptions} from '../interfaces/user-options';
import {catchError, tap} from 'rxjs/operators';
import {Observable, of} from 'rxjs';
import {Login} from '../pages/login/login';
import {SearchOptions} from '../interfaces/search-options';
import {RegisterOptions} from '../interfaces/register-options';

@Injectable({
    providedIn: 'root'
})
export class RestService {

    baseUrl = 'http://192.168.43.157/nova/wakala-api/';
    osrmUrl = 'http://ttel.co.tz:5000/route/v1';
    transaction: any;

    constructor(private httpClient: HttpClient) {
    }

    public getBaseUrl() {
        return this.baseUrl;
    }

    public setTransaction(transaction) {
        this.transaction = transaction;
    }

    private log(message: string) {
        console.log(message);
    }

    private post<T>(url, data, message): Observable<T> {
        return this.httpClient.post<any>(this.baseUrl + url, data)
            .pipe(tap(_ => this.log(message + ':' + this.baseUrl + url)),
                catchError(this.handleError(message)));
    }

    private get<T>(url, message): Observable<T> {
        return this.httpClient.get<any>(this.baseUrl + url)
            .pipe(tap(_ => this.log(message + ':' + this.baseUrl + url)),
                catchError(this.handleError(message)));
    }

    public login(userOptions: UserOptions): Observable<Login> {
        return this.post<Login>('client/login', userOptions, 'Login');
    }

    public register(userOptions: RegisterOptions) {
        return this.post<any>('client/register', userOptions, 'Register');
    }

    public getServices() {
        return this.get<any>('client/services', 'Services');
    }

    public getTransactions() {
        return this.get<any>('client/requests?group=true', 'Requests');
    }

    public getTransaction(id) {
        return this.get<any>('client/request-detail?id=' + id, 'Requests');
    }

    public searchAgents(options: SearchOptions) {
        return this.post<any>('client/agents', options, 'Agents');
    }

    public submitRequest(options: SearchOptions) {
        return this.post<any>('client/request', options, 'Agents');
    }

    private handleError<T>(operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {

            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead

            // TODO: better job of transforming error for user consumption
            this.log(`${operation} failed: ${error.message}`);

            // Let the app keep running by returning an empty result.
            return of(result as T);
        };
    }

    public logout() {
        return this.post<any>('logout', null, 'Logout');
    }
}
