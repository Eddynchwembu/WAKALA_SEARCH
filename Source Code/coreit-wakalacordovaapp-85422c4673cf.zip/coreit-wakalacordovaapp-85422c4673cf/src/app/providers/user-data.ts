import {Injectable} from '@angular/core';
import {Events} from '@ionic/angular';
import {Storage} from '@ionic/storage';
import {Login} from '../pages/login/login';

@Injectable({
    providedIn: 'root'
})
export class UserData {
    HAS_LOGGED_IN = 'hasLoggedIn';
    HAS_SEEN_TUTORIAL = 'hasSeenTutorial';
    ACCESS_TOKEN = 'accessToken';

    constructor(
        public events: Events,
        public storage: Storage
    ) {
    }

    logout(): Promise<any> {
        return this.storage.remove(this.HAS_LOGGED_IN).then(() => {
            return this.storage.remove('username');
        }).then(() => {
            this.events.publish('user:logout');
        });
    }

    isLoggedIn(): Promise<boolean> {
        return this.storage.get(this.HAS_LOGGED_IN).then((value) => {
            return value === true;
        });
    }

    private setData(data: Login) {
        localStorage.setItem(this.ACCESS_TOKEN, data.access_token);
        localStorage.setItem('fcmToken', data.fcm_access_token);
        localStorage.setItem('username', data.username);
        localStorage.setItem('auth_data', data.auth_data);
        localStorage.setItem('profile_id', data.profile.id);
        localStorage.setItem('profile_name', data.profile.name);
        localStorage.setItem('profile_phone', data.profile.mobile);
        localStorage.setItem('profile_image', data.profile.image);
    }

    login(data: Login): Promise<any> {
        return this.storage.set(this.HAS_LOGGED_IN, true).then(() => {
            this.setData(data);
            return this.events.publish('user:login');
        });
    }
}
