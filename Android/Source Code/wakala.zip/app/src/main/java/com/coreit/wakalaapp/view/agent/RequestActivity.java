package com.coreit.wakalaapp.view.agent;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.AgentRequestModel;
import com.coreit.wakalaapp.model.RequestModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.ImageUtil;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RequestActivity extends AppCompatActivity {

    RequestModel model;
    ImageView image;
    TextView mClient;
    TextView mAmount;
    TextView mService;
    TextView mClientName;
    TextView mTime;
    TextView mReject;
    TextView mAccept;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_request);
        model = getIntent().getExtras().getParcelable("request");
        image = (ImageView) findViewById(R.id.iv_agent_request_image);
        mClient = (TextView) findViewById(R.id.tv_agent_request_client);
        mAmount = (TextView) findViewById(R.id.tv_agent_request_amount);
        mService = (TextView) findViewById(R.id.tv_agent_request_service);
        mClientName = (TextView) findViewById(R.id.tv_agent_request_client_name);
        mTime = (TextView) findViewById(R.id.tv_agent_request_time);
        mAccept = (TextView) findViewById(R.id.tv_agent_request_accept);
        mReject = (TextView) findViewById(R.id.tv_agent_request_reject);

        mAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogUtils.showInfo(RequestActivity.this, getResources().getString(R.string.request_accept_prompt), new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        AgentRequestModel request = new AgentRequestModel();
                        request.id = String.valueOf(model.id);
                        request.status = "1";
                        new SubmitRequest().execute(request);
                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {

                    }
                });
            }
        });

        mReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogUtils.showInfo(RequestActivity.this, getResources().getString(R.string.request_reject_prompt), new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        AgentRequestModel request = new AgentRequestModel();
                        request.id = String.valueOf(model.id);
                        request.status = "0";
                        new SubmitRequest().execute(request);
                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {

                    }
                });
            }
        });
        mClient.setText(model.client);
        mAmount.setText(model.amount);
        mService.setText(model.service);
        mClientName.setText(model.clientName);
        Long ts = Long.valueOf(model.time) * 1000;
        Date df = new Date(ts);
        String time = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(df);
        mTime.setText(time);
        ImageUtil.displayImage(image, model.image, null);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(model.client);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Async Task to make http call
     */
    private class SubmitRequest extends AsyncTask<AgentRequestModel, JSONObject, JSONObject> {

        AgentRequestModel mModel;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(AgentRequestModel... arg0) {
            AgentRequestModel model = arg0[0];
            mModel = model;
            return Api.submitRequest(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                int code = result.optInt("code");
                if (code == 200) {
                    String message;
                    if (mModel.status.equals("1")) {
                        message = RequestActivity.this.getResources().getString(R.string.request_accept_success);
                    } else {
                        message = RequestActivity.this.getResources().getString(R.string.request_reject_success);
                    }
                    DialogUtils.showSuccess(RequestActivity.this, message, new DialogUtils.DialogListener() {
                        @Override
                        public void onOkClick(Context context, Dialog dialog, View view) {
                            dialog.dismiss();
                            finish();
                        }

                        @Override
                        public void onCancelClick(Context context, Dialog dialog, View view) {
                            finish();
                        }
                    });
                } else if (code == 201) {
                    DialogUtils.showError(RequestActivity.this, getResources().getString(R.string.request_already_accepted), new DialogUtils.DialogListener() {
                        @Override
                        public void onOkClick(Context context, Dialog dialog, View view) {
                            dialog.dismiss();
                            finish();
                        }

                        @Override
                        public void onCancelClick(Context context, Dialog dialog, View view) {
                            finish();
                        }
                    });
                }
            } else {
                DialogUtils.showError(RequestActivity.this, getResources().getString(R.string.request_submit_failed));
            }
        }
    }
}
