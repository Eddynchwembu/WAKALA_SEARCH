package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 4/2/2018.
 */

public class PositionModel {
    public double latitude;
    public double longitude;
}
