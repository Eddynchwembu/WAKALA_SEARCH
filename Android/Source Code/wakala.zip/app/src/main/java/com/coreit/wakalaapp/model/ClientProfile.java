package com.coreit.wakalaapp.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Ramadan on 4/1/2018.
 */

public class ClientProfile implements Parcelable {
    public String name;
    public String phone;
    public String gender;
    public String email;
    public String image;
    public String oldPassword;
    public String newPassword;

    public ClientProfile() {

    }

    protected ClientProfile(Parcel in) {
        name = in.readString();
        phone = in.readString();
        gender = in.readString();
        email = in.readString();
        image = in.readString();
    }

    public static final Creator<ClientProfile> CREATOR = new Creator<ClientProfile>() {
        @Override
        public ClientProfile createFromParcel(Parcel in) {
            return new ClientProfile(in);
        }

        @Override
        public ClientProfile[] newArray(int size) {
            return new ClientProfile[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(phone);
        parcel.writeString(gender);
        parcel.writeString(email);
        parcel.writeString(image);
    }
}
