package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 3/26/2018.
 */

public class ClientRegisterModel {
    public String firstName;
    public String lastName;
    public String phone;
    public String password;
    public String confirmPassword;

    public ClientRegisterModel() {

    }

    public ClientRegisterModel(String firstName, String lastName, String phone, String password,String confirmPassword) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }
}
