package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 4/6/2018.
 */

public class SearchModel {
    public String date;
    public String phone;
    public String service;
}
