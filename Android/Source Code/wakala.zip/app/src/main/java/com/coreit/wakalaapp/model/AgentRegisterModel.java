package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 3/26/2018.
 */

public class AgentRegisterModel {
    public String firstName;
    public String lastName;
    public String phone;
    public String business;
    public String tin;
    public String email;
    public String password;
    public String confirmPassword;
    public String longitude;
    public String latitude;

    public AgentRegisterModel() {

    }

    public AgentRegisterModel(String firstName,
                              String lastName,
                              String business,
                              String tin,
                              String phone,
                              String email,
                              String password,
                              String confirmPassword) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.tin = tin;
        this.email = email;
        this.business = business;
    }

    public boolean validate() {
        return firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty() || tin.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || business.isEmpty();
    }
}
