package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 4/4/2018.
 */

public class ResetModel {
    public String phone;
    public String code;
    public String oldPassword;
    public String newPassword;
    public int type;
}
