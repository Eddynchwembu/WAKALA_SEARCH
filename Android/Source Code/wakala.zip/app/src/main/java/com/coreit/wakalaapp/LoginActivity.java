package com.coreit.wakalaapp;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.LoginModel;
import com.coreit.wakalaapp.model.ResetModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.view.client.MainActivity;
import com.coreit.wakalaapp.widgets.LanguageDialog;
import com.coreit.wakalaapp.widgets.ResetPasswordDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class LoginActivity extends AppCompatActivity {

    private TextView mTabClientClientButton;
    private TextView mTabClientAgentButton;
    private TextView mTabClientSubmitButton;
    private TextView mTabClientRegisterButton;
    private TextView mTabClientUsername;
    private TextView mTabClientPassword;
    private EditText mTabClientEditUsername;
    private EditText mTabClientEditPassword;
    private LinearLayout mTabClientLayout;
    private TextView mTabClientCancelButton;
    private TextView mClientForgotPwd;

    private TextView mTabAgentClientButton;
    private TextView mTabAgentAgentButton;
    private TextView mTabAgentSubmitButton;
    private TextView mTabAgentRegisterButton;
    private TextView mTabAgentOKButton;
    private TextView mTabAgentCancelButton;
    private TextView mTabAgentUsername;
    private TextView mTabAgentPassword;
    private EditText mTabAgentEditUsername;
    private EditText mTabAgentEditPassword;
    private LinearLayout mTabAgentLayout;
    private TextView mAgentForgotPwd;

    private TextView mTabClientLanguage;
    private TextView mTabAgentLanguage;
    ResetPasswordDialog requestDialog;
    ResetPasswordDialog resetDialog;
    private View.OnClickListener languageListener;

    private TextView mExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE); //Removing ActionBar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_client_login);
        languageListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final LanguageDialog diag = new LanguageDialog(LoginActivity.this);
                diag.setOnOkListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String lang = diag.getSelectedLanguage();
                        Locale locale = new Locale(lang);
                        Locale.setDefault(locale);
                        Configuration config = new Configuration();
                        config.locale = locale;
                        getBaseContext().getResources().updateConfiguration(config, null);
                        diag.dismiss();
                        Intent i = new Intent(LoginActivity.this, LoginActivity.class);
                        startActivity(i);
                        finish();
                    }
                });
                diag.show();
            }
        };
        showClientTab();
    }


    public void showClientTab() {
        setContentView(R.layout.activity_client_login);
        mTabClientAgentButton = (TextView) findViewById(R.id.tab_client_agent);
        mTabClientClientButton = (TextView) findViewById(R.id.tab_client_client);
        mTabClientRegisterButton = (TextView) findViewById(R.id.client_login_register);
        mTabClientSubmitButton = (TextView) findViewById(R.id.client_login_submit);
        mTabClientUsername = (EditText) findViewById(R.id.client_login_username);
        mTabClientPassword = (EditText) findViewById(R.id.client_login_password);
        mTabClientLanguage = (TextView) findViewById(R.id.tv_client_language);
        mClientForgotPwd = (TextView) findViewById(R.id.tv_client_forgot_password);
        mTabClientLanguage.setOnClickListener(languageListener);
        mExit = findViewById(R.id.client_login_exit);
        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exitApp();
            }
        });
        Typeface sRobotoThin = Typeface.createFromAsset(this.getAssets(),
                "fonts/Roboto-Light.ttf");
//        mTabClientEditUsername.setTypeface(sRobotoThin);
        //      mTabClientEditPassword.setTypeface(sRobotoThin);

        initClientButtons();
    }

    void exitApp() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    public void showAgentTab() {
        setContentView(R.layout.activity_agent_login);
        mTabAgentAgentButton = (TextView) findViewById(R.id.tab_agent_agent);
        mTabAgentClientButton = (TextView) findViewById(R.id.tab_agent_client);
        mTabAgentRegisterButton = (TextView) findViewById(R.id.agent_login_register);
        mTabAgentSubmitButton = (TextView) findViewById(R.id.agent_login_submit);
        mTabAgentUsername = (EditText) findViewById(R.id.agent_login_username);
        mTabAgentPassword = (EditText) findViewById(R.id.agent_login_password);
        mTabAgentLanguage = (TextView) findViewById(R.id.tv_agent_language);
        mAgentForgotPwd = (TextView) findViewById(R.id.tv_agent_forgot_password);
        mTabAgentLanguage.setOnClickListener(languageListener);
        mExit = findViewById(R.id.agent_login_exit);
        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exitApp();
            }
        });
        Typeface sRobotoThin = Typeface.createFromAsset(this.getAssets(),
                "fonts/Roboto-Light.ttf");
        //  mTabAgentEditUsername.setTypeface(sRobotoThin);
        //mTabAgentEditPassword.setTypeface(sRobotoThin);

        initAgentButtons();
    }

    private void initClientButtons() {

        mTabClientAgentButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                showAgentTab();
            }
        });
        mTabClientRegisterButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(i);
                // close this activity
                finish();
            }
        });

        mTabClientSubmitButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String username = mTabClientUsername.getText().toString();
                String password = mTabClientPassword.getText().toString();
                if (username.isEmpty() || password.isEmpty()) {
                    DialogUtils.showError(LoginActivity.this, getResources().getString(R.string.form_general_error));
                } else {
                    LoginModel model = new LoginModel(username, password);
                    Spinner.show(LoginActivity.this);
                    new LoginClient().execute(model);
                }
            }
        });
        mClientForgotPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setRequestToken(1);
            }
        });
    }

    private void initAgentButtons() {

        mTabAgentClientButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                showClientTab();
            }
        });
        mTabAgentRegisterButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(i);
                // close this activity
                finish();
            }
        });

        mTabAgentSubmitButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String username = mTabAgentUsername.getText().toString();
                String password = mTabAgentPassword.getText().toString();
                if (username.isEmpty() || password.isEmpty()) {
                    DialogUtils.showError(LoginActivity.this, getResources().getString(R.string.form_general_error));
                } else {
                    LoginModel model = new LoginModel(username, password);
                    Spinner.show(LoginActivity.this);
                    new LoginAgent().execute(model);
                }
            }
        });

        mAgentForgotPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setRequestToken(2);
            }
        });
    }

    /**
     * Sends request token request
     *
     * @param type User type 1 client 2 agent
     */
    private void setRequestToken(final int type) {
        requestDialog = new ResetPasswordDialog(this);
        requestDialog.setOnOkListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = requestDialog.getPhone();
                if (phone == null || phone.isEmpty()) {
                    DialogUtils.showError(LoginActivity.this, "Please enter your phone number.");
                } else {
                    ResetModel model = new ResetModel();
                    model.type = type;
                    model.phone = phone;
                    Spinner.show(LoginActivity.this);
                    new RequestReset().execute(model);
                }
            }
        });
        requestDialog.setOnHaveCodeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestDialog.dismiss();
                setResetToken(type);
            }
        });
        requestDialog.show();
    }

    /**
     * sends reset password request
     *
     * @param type User type 1 client 2 agent
     */
    public void setResetToken(final int type) {
        resetDialog = new ResetPasswordDialog(LoginActivity.this, 1);
        resetDialog.setOnOkListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (resetDialog.validate()) {
                    String phone = resetDialog.getPhone();
                    String code = resetDialog.getCode();
                    String pwd = resetDialog.getPassword();
                    String conf = resetDialog.getConfirmPassword();
                    ResetModel model = new ResetModel();
                    model.phone = phone;
                    model.code = code;
                    model.newPassword = pwd;
                    model.type = type;
                    Spinner.show(LoginActivity.this);
                    new ResetPassword().execute(model);
                } else {
                    DialogUtils.showError(LoginActivity.this, resetDialog.getErrors());
                }

            }
        });
        resetDialog.show();
    }

    /**
     * Async Task to make http call
     */
    private class LoginClient extends AsyncTask<LoginModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(LoginModel... arg0) {
            LoginModel model = arg0[0];
            JSONObject response = Api.login(model.username, model.password);
            SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
            String fcmToken = pref.getString(App.PREF_FCM_TOKEN, null);

            if (response != null && response.optInt("status") == 1) {
                String agentFcmToken = response.optString("fcm_access_token");
                boolean fcmUpdate = pref.getBoolean(App.PREF_FCM_UPDATE, false) || (agentFcmToken == null || !agentFcmToken.equals(fcmToken));
                String token = response.optString("access_token");
                App.setAccessToken(token);
                if (fcmUpdate) {
                    JSONObject fcm = Api.updateFcmToken(fcmToken);
                    try {
                        response.put("fcm", fcm);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
            return response;
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONObject profile = result.optJSONObject("profile");
                if (profile != null) {
                    String token = result.optString("access_token", null);
                    String name = profile.optString("name");
                    String mobile = profile.optString("mobile");
                    String image = profile.optString("image");
                    App.setUserType("client");
                    App.setAccessToken(token);
                    SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                    SharedPreferences.Editor editor = pref.edit();
                    JSONObject fcm = result.optJSONObject("fcm");
                    if (fcm != null && fcm.optInt("status", 0) == 1) {
                        editor.putBoolean(App.PREF_FCM_UPDATE, false);
                    }
                    editor.putString(App.PREF_TOKEN, token);
                    editor.putString(App.PREF_USER_TYPE, "client");
                    editor.putString(App.PREF_USERNAME, name);
                    editor.putString(App.PREF_MOBILE, mobile);
                    editor.putString(App.PREF_USER_IMAGE, image);
                    editor.apply();
                    Spinner.hide();
                    Intent i = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(i);
                    finish();
                } else {
                    Spinner.hide();
                    DialogUtils.showError(LoginActivity.this, getResources().getString(R.string.login_failed));
                }

            } else {
                Spinner.hide();
                DialogUtils.showError(LoginActivity.this, getResources().getString(R.string.login_failed));
            }
        }

    }

    /**
     * Async Task to make http call
     */
    private class LoginAgent extends AsyncTask<LoginModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(LoginModel... arg0) {
            LoginModel model = arg0[0];
            JSONObject response = com.coreit.wakalaapp.agent.Api.login(model.username, model.password);
            SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);

            if (response != null && response.optInt("status") == 1) {
                String agentFcmToken = response.optString("fcm_access_token");
                String fcmToken = pref.getString(App.PREF_FCM_TOKEN, null);
                boolean fcmUpdate = pref.getBoolean(App.PREF_FCM_UPDATE, false) || (agentFcmToken == null || !agentFcmToken.equals(fcmToken));
                String token = response.optString("access_token");
                App.setAccessToken(token);
                if (fcmUpdate) {
                    JSONObject fcm = com.coreit.wakalaapp.agent.Api.updateFcmToken(fcmToken);
                    try {
                        response.put("fcm", fcm);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
            return response;
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONObject profile = result.optJSONObject("profile");
                if (profile != null) {
                    String token = result.optString("access_token", null);
                    String name = profile.optString("business");
                    String mobile = profile.optString("mobile");
                    String userName = profile.optString("name");
                    String email = profile.optString("email");
                    String lat = profile.optString("latitude");
                    String lon = profile.optString("longitude");
                    String image = profile.optString("image");
                    App.setUserType("agent");
                    SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                    SharedPreferences.Editor editor = pref.edit();
                    JSONObject fcm = result.optJSONObject("fcm");
                    if (fcm != null && fcm.optInt("status", 0) == 1) {
                        editor.putBoolean(App.PREF_FCM_UPDATE, false);
                    }
                    editor.putString(App.PREF_TOKEN, token);
                    editor.putString(App.PREF_USER_TYPE, "agent");
                    editor.putString(App.PREF_USERNAME, userName);
                    editor.putString(App.PREF_EMAIL, email);
                    editor.putString(App.PREF_MOBILE, mobile);
                    editor.putString(App.PREF_BUSINESS_NAME, name);
                    editor.putString(App.PREF_USER_LATITUDE, lat);
                    editor.putString(App.PREF_USER_LONGITUDE, lon);
                    editor.putString(App.PREF_USER_IMAGE, image);
                    editor.apply();
                    Spinner.hide();
                    Intent i = new Intent(LoginActivity.this, com.coreit.wakalaapp.view.agent.MainActivity.class);
                    startActivity(i);
                    finish();
                } else {
                    Spinner.hide();
                    DialogUtils.showError(LoginActivity.this, getResources().getString(R.string.login_failed_agent));
                }
            } else {
                Spinner.hide();
                DialogUtils.showError(LoginActivity.this, getResources().getString(R.string.login_failed));
            }
        }

    }

    /**
     * Async Task to make http call
     */
    private class RequestReset extends AsyncTask<ResetModel, JSONObject, JSONObject> {

        ResetModel model;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(ResetModel... arg0) {
            model = arg0[0];
            if (model.type == 1) {
                return Api.requestPassword(model);
            } else {
                return com.coreit.wakalaapp.agent.Api.requestPassword(model);
            }
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                requestDialog.dismiss();
                Spinner.hide();
                DialogUtils.showInfo(LoginActivity.this, getResources().getString(R.string.pwd_request_success), new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        dialog.dismiss();
                        setResetToken(model.type);
                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {
                    }
                });
            } else {
                Spinner.hide();
                DialogUtils.showError(LoginActivity.this, getResources().getString(R.string.pwd_reset_failed));
            }
        }

    }


    /**
     * Async Task to make http call
     */
    private class ResetPassword extends AsyncTask<ResetModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(ResetModel... arg0) {
            ResetModel model = arg0[0];
            if (model.type == 1) {
                return Api.resetPassword(model);
            } else {
                return com.coreit.wakalaapp.agent.Api.resetPassword(model);
            }
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                Spinner.hide();
                DialogUtils.showInfo(LoginActivity.this, getResources().getString(R.string.pwd_reset_success), new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        dialog.dismiss();
                        resetDialog.dismiss();
                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {
                        resetDialog.dismiss();
                    }
                });
            } else {
                Spinner.hide();
                DialogUtils.showError(LoginActivity.this, getResources().getString(R.string.pwd_reset_failed));
            }
        }

    }

}
