package com.coreit.wakalaapp.agent;

import android.app.IntentService;
import android.app.Notification;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;

import com.coreit.wakalaapp.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class NotificationServiceOld extends IntentService {
    NotificationCompat.Builder mBuilder;
    int nMsg = 0;
    List<String> notifications;
    public static int CHANNEL_ID = 2303;
    NotificationCompat.MessagingStyle style;
    List<NotificationCompat.MessagingStyle.Message> messages;
    String GROUP_KEY_NOTIFICATION = "com.coreit.wakalapp.agent.NOTIFICATION";
    int SUMMARY_ID = 0;
    static int NOTIFICATION_ID = 23;

    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     */
    public NotificationServiceOld() {
        super("notification");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        WakefulBroadcastReceiver.completeWakefulIntent(intent);
        Log.d("Notification", "Handle");

        JSONObject result = Api.getNotifications();
        if (result != null && result.optInt("status", 0) == 1) {
            String account = result.optString("account");
            JSONArray items = result.optJSONArray("items");
            if (items != null && items.length() > 0) {

                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
                NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item != null) {
                        int id = item.optInt("id");
                        String client = item.optString("client");
                        String text = item.optString("message");
                        Notification message =
                                new NotificationCompat.Builder(this)
                                        .setSmallIcon(R.mipmap.ic_launcher)
                                        .setContentTitle(client)
                                        .setContentText(text)
                                        .setGroup(GROUP_KEY_NOTIFICATION)
                                        .build();

                        notificationManager.notify(id, message);
                        style.addLine(client.concat(" ").concat(text));
                    }
                }

                if (items.length() > 0) {
                    style.setSummaryText(account);
                    NotificationCompat.Builder builder =
                            new NotificationCompat.Builder(this)
                                    .setContentTitle("WakalaApp")
                                    //set content comment to support devices running API level < 24
                                    .setContentText("You have 2 getNotifications from 2 clients")
                                    .setSmallIcon(R.mipmap.ic_launcher)
                                    .setStyle(style)
                                    //build summary info into InboxStyle template
//                                    .setStyle(new NotificationCompat.InboxStyle()
//                                            .addLine("Alex Faarborg  Check this out")
//                                            .addLine("Jeff Chang    Launch Party")
//                                            .setBigContentTitle("2 new messages")
//                                            .setSummaryText("Teratech"))
                                    //specify which group this notification belongs to
                                    .setGroup(GROUP_KEY_NOTIFICATION)
                                    //set this notification as the summary for the group
                                    .setGroupSummary(true);
                    //        NotificationManager mNotificationManager =
//                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                    Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                    builder.setSound(uri);
                    notificationManager.notify(SUMMARY_ID, builder.build());
                }
            }
        }
    }
}
