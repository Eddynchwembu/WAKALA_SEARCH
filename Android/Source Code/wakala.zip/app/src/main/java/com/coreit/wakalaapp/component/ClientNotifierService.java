package com.coreit.wakalaapp.component;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.view.client.RequestDetailActivity;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import java.io.IOException;
import java.net.URL;

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class ClientNotifierService extends JobService {
    String GROUP_KEY_NOTIFICATION = "com.coreit.wakalapp.NOTIFICATION";
    private static final String TAG = "WakalaAppClientNotifier";

    @Override
    public boolean onStartJob(JobParameters params) {
        run(params);
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }

    void run(final JobParameters job) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Bundle data = job.getExtras();        // Check if message contains a notification payload.
                //Log.d(TAG, "Message Notification Body: " + message.getNotification().getBody());

                int id = Integer.valueOf(data.getString("id"));
                String type = data.getString("type");
                String time = data.getString("time");
                String text = data.getString("message");
                String account = data.getString("account");
                String channelId = "app.notification";// getString();
                NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
                style.setSummaryText(account);
                String title;
                String image = null;
                PendingIntent pendingIntent;
                if (type.equals("0")) {
                    title = data.getString("agent");
                    image = data.getString("image");
                    String rId = data.getString("request_id");
                    Intent intent = new Intent(ClientNotifierService.this, RequestDetailActivity.class);
                    intent.putExtra("id", rId);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    pendingIntent = PendingIntent.getActivity(ClientNotifierService.this, id, intent, PendingIntent.FLAG_ONE_SHOT);
                } else {
                    title = data.getString("title");
                    pendingIntent = null;
                }


                Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                style.addLine(text);

                NotificationCompat.Builder notificationBuilder =
                        new NotificationCompat.Builder(ClientNotifierService.this, channelId)
                                .setSmallIcon(R.drawable.notification_icon)
                                .setContentTitle(title)
                                .setContentText(text)
                                .setGroup(GROUP_KEY_NOTIFICATION)
                                .setAutoCancel(true);
                if (pendingIntent != null) {
                    notificationBuilder.setContentIntent(pendingIntent);
                }
                if (image != null) {
                    URL url;
                    try {
                        url = new URL(image);
                        Bitmap bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                        notificationBuilder.setLargeIcon(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                NotificationManager notificationManager =
                        (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                // Since android Oreo notification channel is needed.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel(channelId,
                            "New notification",
                            NotificationManager.IMPORTANCE_DEFAULT);
                    notificationManager.createNotificationChannel(channel);
                }

                notificationManager.notify(id, notificationBuilder.build());

                NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(ClientNotifierService.this, channelId)
                                .setContentTitle("WakalaSearch")
                                //set content comment to support devices running API level < 24
                                .setContentText("You have new notification.")
                                .setSmallIcon(R.drawable.notification_icon)
                                .setStyle(style)
                                //specify which group this notification belongs to
                                .setGroup(GROUP_KEY_NOTIFICATION)
                                .setSound(defaultSoundUri)
                                .setAutoCancel(true)
                                //set this notification as the summary for the group
                                .setGroupSummary(true);
                notificationManager.notify(0, builder.build());
                com.coreit.wakalaapp.client.Api.ackNotification(id);
                jobFinished(job, false);
            }
        }).start();
    }
}
