package com.coreit.wakalaapp.component;

import android.support.annotation.Nullable;
import android.util.Log;

import com.coreit.wakalaapp.App;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.BufferedSink;
import okio.Okio;

/**
 * HttpClient Class
 * Created by Ramadan on 5/14/2017.
 */

public class HttpClient {

    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");

    @Nullable
    public static String doPost(String url, String json) throws IOException {
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        if (response.body() != null) {
            return response.body().string();
        } else {
            return null;
        }
    }

    @Nullable
    public static String doPost(String url) throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        Response response = client.newCall(request).execute();
        if (response.body() != null) {
            return response.body().string();
        } else {
            return null;
        }
    }

    public static String doFormPost(String url, Map<String, Object> params) throws IOException {
        FormBody.Builder builder = new FormBody.Builder();
        for (String key : params.keySet()) {
            builder.add(key, String.valueOf(params.get(key)));
        }
        RequestBody formBody = builder.build();

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .post(formBody)
                .build();

        Response response = client.newCall(request).execute();
        String body = response.body().string();
        Log.d("HTTP", "url:".concat(url));
        Log.d("HTTP", "response:".concat(body));
        return body;
    }

    @Nullable
    public static String doGet(String url) throws IOException {
        Log.d("HttpClient.Get:", url);
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        Response response = client.newCall(request).execute();
        Log.d("HTTP", "url:".concat(url));
        if (response.body() != null) {
            String body = response.body().string();
            Log.d("HTTP", "response:".concat(body));
            return body;
        } else {
            return null;
        }
    }

    public static File getDownload(String url, String filename, String path) throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        File download = new File(path, filename);
        Response response = client.newCall(request).execute();
        BufferedSink sink = Okio.buffer(Okio.sink(download));
        sink.writeAll(response.body().source());
        sink.close();
        return download;
    }

    public static File getDownload(String url, String filename) throws IOException {
        return getDownload(url, filename, App.getContext().getCacheDir().getPath());
    }

    public static File postDownload(String url, String filename, String path, Map<String, Object> params) throws IOException {
        FormBody.Builder builder = new FormBody.Builder();
        for (String key : params.keySet()) {
            builder.add(key, String.valueOf(params.get(key)));
        }
        RequestBody formBody = builder.build();

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .post(formBody)
                .build();

        File download = new File(path, filename);
        File parent = download.getParentFile();
        if (!parent.exists()) {
            if (!parent.mkdirs())
                return null;

        }
        Response response = client.newCall(request).execute();
        BufferedSink sink = Okio.buffer(Okio.sink(download));
        sink.writeAll(response.body().source());
        sink.close();
        Log.d("HTTP", "url:".concat(url));
        return download;
    }

    public static String buildUrl(String path) {
        return buildUrl(path, null);
    }

    public static String buildUrl(String path, boolean appendToken) {
        return buildUrl(path, null, appendToken);
    }

    public static String buildUrl(String path, Map<String, String> params) {
        return buildUrl(path, params, true);
    }

    public static String buildUrl(String path, Map<String, String> params, boolean appendToken) {

        String sParams = "";
        if (params != null) {
            sParams = "?";
            for (String key : params.keySet()) {
                sParams += (key + "=" + params.get(key));
                sParams += "&";
            }
        }
        if (appendToken) {
            String at = App.getAccessToken();
            if (at != null) {
                if (sParams.isEmpty()) {
                    sParams += "?access-token=" + at;
                } else {
                    sParams += "access-token=" + at;
                }
            }
        }

        return App.getApiBase() + "/" + path + sParams;
    }

}
