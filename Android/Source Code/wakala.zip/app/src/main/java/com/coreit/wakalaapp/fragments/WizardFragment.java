package com.coreit.wakalaapp.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.R;

public class WizardFragment extends Fragment {

    private static final String ARG_POSITION = "position";

    private int position;
    private ImageView image;

    public static WizardFragment newInstance(int position) {
        WizardFragment f = new WizardFragment();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);
        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt(ARG_POSITION);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_wizard,
                container, false);
        image = (ImageView) rootView
                .findViewById(R.id.fragment_wizard_image);
        TextView ft = rootView.findViewById(R.id.fragment_wizard_title);
        TextView st = rootView.findViewById(R.id.fragment_wizard_text);

        LinearLayout layout = (LinearLayout) rootView
                .findViewById(R.id.fragment_wizard_layout);
        layout.setBackgroundColor(ContextCompat.getColor(getContext(),
                R.color.material_purple_300));
        layout.invalidate();
        if (position == 0) {
            image.setBackgroundResource(R.drawable.wizard_logo);
            ft.setText(getText(R.string.wizard_welcome_title));
            st.setText(getText(R.string.wizard_welcome_content));
        } else if (position == 2) {
            image.setBackgroundResource(R.drawable.client_login);
            ft.setText(getText(R.string.wizard_login_title));
            st.setText(getText(R.string.wizard_login_content));
        } else if (position == 1) {
            image.setBackgroundResource(R.drawable.client_register);
            ft.setText(getText(R.string.wizard_register_title));
            st.setText(getText(R.string.wizard_register_content));
        } else if(position == 3) {
            image.setBackgroundResource(R.drawable.client_home);
            ft.setText(getText(R.string.wizard_home_title));
            st.setText(getText(R.string.wizard_home_content));
        }else if(position == 4){
            image.setBackgroundResource(R.drawable.client_request);
            ft.setText(getText(R.string.wizard_request_title));
            st.setText(getText(R.string.wizard_request_content));
        }else  {
            image.setBackgroundResource(R.drawable.client_track);
            ft.setText(getText(R.string.wizard_track_title));
            st.setText(getText(R.string.wizard_track_content));
        }

        ViewCompat.setElevation(rootView, 50);
        return rootView;
    }

}