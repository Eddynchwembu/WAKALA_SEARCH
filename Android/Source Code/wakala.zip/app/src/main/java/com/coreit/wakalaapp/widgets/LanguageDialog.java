package com.coreit.wakalaapp.widgets;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.R;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class LanguageDialog extends Dialog {

    private TextView mDialogOKButton;
    private TextView mDialogCancelButton;
    RadioGroup langGroup;
    SharedPreferences pref;

    public LanguageDialog(Context context) {
        super(context, R.style.CustomDialogTheme);
        setContentView(R.layout.dialog_language_layout);
        setCancelable(true);

        pref = PreferenceManager.getDefaultSharedPreferences(context);
        mDialogOKButton = (TextView) findViewById(R.id.dialog_ok);
        mDialogCancelButton = (TextView) findViewById(R.id.dialog_cancel);
        langGroup = (RadioGroup) findViewById(R.id.radio_language);
        String lang = pref.getString(App.PREF_LANGUAGE, "en");
        if (lang.equals("en")) {
            RadioButton button = (RadioButton) findViewById(R.id.radio_english);
            button.setChecked(true);
        } else {
            RadioButton button = (RadioButton) findViewById(R.id.radio_swahili);
            button.setChecked(true);
        }
        setOnCancelListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    public String getSelectedLanguage() {
        int id = langGroup.getCheckedRadioButtonId();
        String lang;
        if (id == R.id.radio_english) {
            lang = "en";
        } else {
            lang = "sw";
        }
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(App.PREF_LANGUAGE, lang);
        editor.apply();
        return lang;
    }

    public void setOnOkListener(View.OnClickListener listener) {
        mDialogOKButton.setOnClickListener(listener);
    }

    public void setOnCancelListener(View.OnClickListener listener) {
        mDialogCancelButton.setOnClickListener(listener);
    }
}
