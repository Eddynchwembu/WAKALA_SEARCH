package com.coreit.wakalaapp.view.agent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.AgentProfile;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.GPSTracker;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.widgets.ChangeEmailDialog;
import com.coreit.wakalaapp.widgets.ChangePasswordDialog;

import org.json.JSONObject;

public class ProfileActivity extends AppCompatActivity {

    AgentProfile profile;
    TextView tvPhone;
    TextView tvEmail;
    TextView tvLocation;
    TextView tvServices;
    RelativeLayout rlServices;
    TextView tvSave;

    private String mGender = "";
    private String mEmail = "";
    private String mOldPassword = "";
    private String mNewPassword = "";
    private String mLongitude = "";
    private String mLatitude = "";
    private SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        tvEmail = (TextView) findViewById(R.id.tv_agent_profile_email);
        tvPhone = (TextView) findViewById(R.id.tv_agent_profile_phone);
        tvLocation = (TextView) findViewById(R.id.tv_agent_profile_location);
        tvServices = (TextView) findViewById(R.id.tv_agent_profile_services);
        rlServices = (RelativeLayout) findViewById(R.id.layout_agent_profile_services);
        tvSave = (TextView) findViewById(R.id.tv_agent_profile_save);
        RelativeLayout password = (RelativeLayout) findViewById(R.id.layout_password);
        RelativeLayout email = (RelativeLayout) findViewById(R.id.layout_agent_profile_email);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_agent_profile_location);
        pref = PreferenceManager.getDefaultSharedPreferences(this);
        tvSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mGender.isEmpty() || !mEmail.isEmpty() || !mOldPassword.isEmpty() || !mLatitude.isEmpty() || !mLongitude.isEmpty()) {
                    AgentProfile model = new AgentProfile();
                    model.gender = mGender;
                    model.email = mEmail;
                    model.oldPassword = mOldPassword;
                    model.newPassword = mNewPassword;
                    model.latitude = mLatitude;
                    model.longitude = mLongitude;
                    Spinner.show(ProfileActivity.this);
                    new UpdateProfile().execute(model);
                }
            }
        });
        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ChangePasswordDialog diag = new ChangePasswordDialog(ProfileActivity.this);
                diag.setOnOkListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (diag.validate()) {
                            mOldPassword = diag.getOldPassword();
                            mNewPassword = diag.getPassword();
                            diag.dismiss();
                        } else {
                            DialogUtils.showError(ProfileActivity.this, diag.getErrors());
                        }

                    }
                });
                diag.show();
            }
        });

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ChangeEmailDialog diag = new ChangeEmailDialog(ProfileActivity.this);
                diag.setOnOkListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (diag.validate()) {
                            mEmail = diag.getEmail();
                            diag.dismiss();
                        } else {
                            DialogUtils.showError(ProfileActivity.this, diag.getErrors());
                        }

                    }
                });
                diag.show();
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner.show(ProfileActivity.this);
                GPSTracker tracker = new GPSTracker(ProfileActivity.this);
                if (tracker.canGetLocation()) {
                    mLatitude = String.valueOf(tracker.getLatitude());
                    mLongitude = String.valueOf(tracker.getLongitude());
                    SharedPreferences.Editor editor = pref.edit();
                    editor.putString(App.PREF_USER_LATITUDE, mLatitude);
                    editor.putString(App.PREF_USER_LONGITUDE, mLongitude);
                    editor.apply();
                    DialogUtils.showSuccess(ProfileActivity.this, "Location successfully updated.");
                } else {
                    DialogUtils.showError(ProfileActivity.this, "Failed to update location, Please turn on location service.");
                }
                Spinner.hide();
            }
        });
        profile = getIntent().getExtras().getParcelable("profile");
        if (profile != null) {
            tvEmail.setText(profile.email);
            tvPhone.setText(profile.phone);
            tvLocation.setText(profile.location);
            toolbar.setTitle(profile.business);
        }
        rlServices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ProfileActivity.this, ServicesActivity.class);
                startActivity(i);
            }
        });

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(ProfileActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Async Task to make http call
     */
    private class UpdateProfile extends AsyncTask<AgentProfile, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(AgentProfile... arg0) {
            AgentProfile model = arg0[0];
            return Api.updateProfile(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ProfileActivity.this);
                SharedPreferences.Editor editor = pref.edit();
                if (!mGender.isEmpty()) {
                    editor.putString(App.PREF_USER_GENDER, mGender);
                }
                editor.apply();
                DialogUtils.showSuccess(ProfileActivity.this, "Profile Updated");
            } else {
                DialogUtils.showError(ProfileActivity.this, "Failed to update profile please check your password.");
            }
            Spinner.hide();
        }

    }

    private class UpdateLocation extends AsyncTask<Void, Boolean, Boolean> {


        @Override
        protected Boolean doInBackground(Void... params) {
            GPSTracker tracker = new GPSTracker(ProfileActivity.this);
            if (tracker.canGetLocation()) {
                mLatitude = String.valueOf(tracker.getLatitude());
                mLongitude = String.valueOf(tracker.getLongitude());
                return true;
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean success) {
            super.onPostExecute(success);
            Spinner.hide();
            if (success) {
                DialogUtils.showSuccess(ProfileActivity.this, "Location successfully updated.");
            } else {
                DialogUtils.showError(ProfileActivity.this, "Failed to update location, Please turn on location service.");
            }
        }
    }
}
