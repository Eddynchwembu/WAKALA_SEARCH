package com.coreit.wakalaapp;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.font.MaterialDesignIconsTextView;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.view.ProgressWheel;
import com.coreit.wakalaapp.view.client.MainActivity;
import com.coreit.wakalaapp.view.kbv.KenBurnsView;
import com.coreit.wakalaapp.widgets.LanguageDialog;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.util.Locale;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class SplashScreenActivity extends AppCompatActivity {

    private KenBurnsView mKenBurns;
    private ImageView mLogo;
    ProgressWheel progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE); //Removing ActionBar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_splash_screen);

        progress = (ProgressWheel) findViewById(R.id.progress_bar);

        mKenBurns = (KenBurnsView) findViewById(R.id.ken_burns_images);
        mLogo = (ImageView) findViewById(R.id.logo);

        ImageLoader imageLoader = ImageLoader.getInstance();
        if (!imageLoader.isInited()) {
            imageLoader.init(ImageLoaderConfiguration.createDefault(this));
        }

        setAnimation();
    }

    public void setAnimation() {
        mKenBurns.setImageResource(R.drawable.background_media);
        ObjectAnimator scaleXAnimation = ObjectAnimator.ofFloat(mLogo, "scaleX", 5.0F, 1.0F);
        scaleXAnimation.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleXAnimation.setDuration(1200);
        ObjectAnimator scaleYAnimation = ObjectAnimator.ofFloat(mLogo, "scaleY", 5.0F, 1.0F);
        scaleYAnimation.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleYAnimation.setDuration(1200);
        ObjectAnimator alphaAnimation = ObjectAnimator.ofFloat(mLogo, "alpha", 0.0F, 1.0F);
        alphaAnimation.setInterpolator(new AccelerateDecelerateInterpolator());
        alphaAnimation.setDuration(1200);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(scaleXAnimation).with(scaleYAnimation).with(alphaAnimation);
        animatorSet.setStartDelay(500);
        animatorSet.start();
        animatorSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                progress.setVisibility(View.VISIBLE);
                progress.spin();
                new PrefetchData().execute();
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }

    private void startWizard() {
        Intent intent = new Intent(this,WizardActivity.class);
        startActivity(intent);
    }

    /**
     * Async Task to make http call
     */
    private class PrefetchData extends AsyncTask<Void, Boolean, Boolean> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected Boolean doInBackground(Void... arg0) {
            if (Api.pulse()) {
                return true;
            } else {
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean result) {
            super.onPostExecute(result);
            if (result) {
                SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(SplashScreenActivity.this);
                String token = pref.getString("access-token", null);
                String lang = pref.getString(App.PREF_LANGUAGE, "en");
                Locale locale = new Locale(lang);
                Locale.setDefault(locale);
                Configuration config = new Configuration();
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config, null);
                if (token == null) {
                    if (App.isFirstRun()) {
                        final LanguageDialog dialog = new LanguageDialog(SplashScreenActivity.this);
                        dialog.setOnCancelListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startWizard();
                                finish();
                            }
                        });
                        dialog.setOnOkListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String lang = dialog.getSelectedLanguage();
                                Locale locale = new Locale(lang);
                                Locale.setDefault(locale);
                                Configuration config = new Configuration();
                                config.locale = locale;
                                getBaseContext().getResources().updateConfiguration(config, null);
                                dialog.dismiss();
                                startWizard();
                                finish();
                            }
                        });
                        dialog.show();
                    } else {
                        Intent i = new Intent(SplashScreenActivity.this, LoginActivity.class);
                        startActivity(i);
                        finish();
                    }
                } else {
                    String type = pref.getString(App.PREF_USER_TYPE, null);
                    if (type == null) {
                        SharedPreferences.Editor editor = pref.edit();
                        editor.remove(App.PREF_TOKEN);
                        editor.remove("user-type");
                        editor.apply();
                        Intent i = new Intent(SplashScreenActivity.this, LoginActivity.class);
                        startActivity(i);
                    } else {
                        App.setAccessToken(token);
                        App.setUserType(type);
                        if (type.equals("client")) {
                            Intent i = new Intent(SplashScreenActivity.this, MainActivity.class);
                            startActivity(i);
                        } else {
                            Intent i = new Intent(SplashScreenActivity.this, com.coreit.wakalaapp.view.agent.MainActivity.class);
                            startActivity(i);
                        }
                    }
                    finish();
                }
            } else {
                DialogUtils dialog = new DialogUtils(SplashScreenActivity.this);
                dialog.addOkListener(new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        dialog.dismiss();
                        SplashScreenActivity.this.finish();
                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {
                        dialog.dismiss();
                        SplashScreenActivity.this.finish();
                    }
                });
                dialog.showErrorDialog("Cannot connect to server. Please check your connection and try again.");
            }
        }

    }
}
