package com.coreit.wakalaapp.client;

import android.util.Log;

import com.coreit.wakalaapp.component.HttpClient;
import com.coreit.wakalaapp.model.ClientProfile;
import com.coreit.wakalaapp.model.ClientRegisterModel;
import com.coreit.wakalaapp.model.ClientRequestModel;
import com.coreit.wakalaapp.model.PositionModel;
import com.coreit.wakalaapp.model.RatingModel;
import com.coreit.wakalaapp.model.ResetModel;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Handle API call.
 * Created by Ramadan on 5/14/2017.
 */

public class Api {

    public static String COMMAND_PULSE = "client/pulse";
    public static String COMMAND_LOGIN = "client/login";
    public static String COMMAND_LOGOUT = "client/logout";
    public static String COMMAND_REGISTER = "client/register";
    public static String COMMAND_SERVICES = "client/services";
    public static String COMMAND_AGENTS = "client/agents";
    public static String COMMAND_REQUEST = "client/request";
    public static String COMMAND_REQUEST_DETAIL = "client/request-detail";
    public static String COMMAND_REQUESTS = "client/requests";
    public static String COMMAND_FCM_TOKEN = "client/fcm-token";
    public static String COMMAND_PROFILE = "client/profile";
    public static String COMMAND_POSITION = "client/position";
    public static String COMMAND_RATINGS = "client/ratings";
    public static String COMMAND_REQUEST_PASSWORD = "client/request-password";
    public static String COMMAND_RESET_PASSWORD = "client/reset-password";
    public static String COMMAND_RATE_AGENT = "client/rate";
    public static String COMMAND_CANCEL_REQUEST = "client/cancel-request";
    public static String COMMAND_TOS = "client/tos";
    public static String COMMAND_ACK_NOTIFICATION = "client/ack-notification";


    public static JSONObject register(ClientRegisterModel model) {
        String url = HttpClient.buildUrl(COMMAND_REGISTER, false);
        Map<String, Object> map = new HashMap<>();
        map.put("Register[first_name]", model.firstName);
        map.put("Register[last_name]", model.lastName);
        map.put("Register[mobile_no]", model.phone);
        map.put("Register[password]", model.password);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject login(String username, String password) {
        String url = HttpClient.buildUrl(COMMAND_LOGIN, false);
        Map<String, Object> map = new HashMap<>();
        map.put("Login[username]", username);
        map.put("Login[password]", password);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }


    public static JSONObject searchAgents(ClientRequestModel model) {
        String url = HttpClient.buildUrl(COMMAND_AGENTS);
        Map<String, Object> map = new HashMap<>();
        map.put("Request[service]", model.serviceId);
        map.put("Request[amount]", model.amount);
        map.put("Request[latitude]", model.latitude);
        map.put("Request[longitude]", model.longitude);
        map.put("Request[radius]", model.radius);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }


    public static JSONObject submitRequest(ClientRequestModel model) {
        String url = HttpClient.buildUrl(COMMAND_REQUEST);
        Map<String, Object> map = new HashMap<>();
        map.put("Request[service]", model.serviceId);
        map.put("Request[amount]", model.amount);
        map.put("Request[latitude]", model.latitude);
        map.put("Request[longitude]", model.longitude);
        map.put("Request[radius]", model.radius);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }


    public static JSONObject logout() {
        String url = HttpClient.buildUrl(COMMAND_LOGOUT);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject getServices() {
        String url = HttpClient.buildUrl(COMMAND_SERVICES);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject getRequests(int page) {
        String url = HttpClient.buildUrl(COMMAND_REQUESTS);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject getRatings(int id) {
        Map<String, String> map = new HashMap<>();
        map.put("id", String.valueOf(id));
        String url = HttpClient.buildUrl(COMMAND_RATINGS, map);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static boolean pulse() {
        String url = HttpClient.buildUrl(COMMAND_PULSE, false);
        try {
            HttpClient.doGet(url);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    /**
     * Update firebase token
     *
     * @param token Token
     * @return
     */
    public static JSONObject updateFcmToken(String token) {
        String url = HttpClient.buildUrl(COMMAND_FCM_TOKEN);

        Map<String, Object> map = new HashMap<>();
        map.put("token", token);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    /**
     * Gets Client Profile.
     *
     * @return
     */
    public static JSONObject profile() {
        String url = HttpClient.buildUrl(COMMAND_PROFILE);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * Gets request details
     *
     * @param id Request id
     * @return Response
     */
    public static JSONObject getRequest(int id) {

        Map<String, String> map = new HashMap<>();
        map.put("id", String.valueOf(id));
        String url = HttpClient.buildUrl(COMMAND_REQUEST_DETAIL, map);
        try {
            String response = HttpClient.doGet(url);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    /**
     * Gets request details
     *
     * @param id Request id
     * @return Response
     */
    public static JSONObject cancelRequest(int id) {

        Map<String, String> map = new HashMap<>();
        map.put("id", String.valueOf(id));
        String url = HttpClient.buildUrl(COMMAND_CANCEL_REQUEST, map);
        try {
            String response = HttpClient.doGet(url);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject updatePosition(LatLng model) {
        String url = HttpClient.buildUrl(COMMAND_POSITION);
        Map<String, Object> map = new HashMap<>();
        map.put("Client[last_latitude]", model.latitude);
        map.put("Client[last_longitude]", model.longitude);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject requestPassword(ResetModel model) {
        String url = HttpClient.buildUrl(COMMAND_REQUEST_PASSWORD);
        Map<String, Object> map = new HashMap<>();
        map.put("Password[phone]", model.phone);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject resetPassword(ResetModel model) {
        String url = HttpClient.buildUrl(COMMAND_RESET_PASSWORD);
        Map<String, Object> map = new HashMap<>();
        map.put("Password[phone]", model.phone);
        map.put("Password[token]", model.code);
        map.put("Password[password]", model.newPassword);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }


    public static JSONObject rateAgent(RatingModel model) {
        String url = HttpClient.buildUrl(COMMAND_RATE_AGENT);
        Map<String, Object> map = new HashMap<>();
        map.put("Rating[agent_id]", model.agentId);
        map.put("Rating[value]", model.rating);
        map.put("Rating[comment]", model.comment);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject updateProfile(ClientProfile model) {
        String url = HttpClient.buildUrl(COMMAND_PROFILE);
        Map<String, Object> map = new HashMap<>();
        map.put("Profile[gender]", model.gender);
        map.put("Profile[email]", model.email);
        map.put("Profile[old_password]", model.oldPassword);
        map.put("Profile[new_password]", model.newPassword);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject getToS() {
        String url = HttpClient.buildUrl(COMMAND_TOS, false);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * Gets request details
     *
     * @param id Request id
     * @return Response
     */
    public static JSONObject ackNotification(int id) {

        Map<String, String> map = new HashMap<>();
        map.put("id", String.valueOf(id));
        String url = HttpClient.buildUrl(COMMAND_ACK_NOTIFICATION, map);
        try {
            String response = HttpClient.doGet(url);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }
}
