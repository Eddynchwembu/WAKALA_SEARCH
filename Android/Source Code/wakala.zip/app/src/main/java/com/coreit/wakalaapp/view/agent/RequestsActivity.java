package com.coreit.wakalaapp.view.agent;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.adapter.AgentRequestsAdapter;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.AgentRequestViewModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.Spinner;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.nhaarman.listviewanimations.appearance.StickyListHeadersAdapterDecorator;
import com.nhaarman.listviewanimations.appearance.simple.AlphaInAnimationAdapter;
import com.nhaarman.listviewanimations.util.StickyListHeadersListViewWrapper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import se.emilsjolander.stickylistheaders.StickyListHeadersListView;

public class RequestsActivity extends AppCompatActivity {

    AgentRequestsAdapter adapter;
    private SwipeRefreshLayout swipeContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_requests);
        swipeContainer = (SwipeRefreshLayout) findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new ListRequests().execute();
            }
        });


        StickyListHeadersListView listView = (StickyListHeadersListView) findViewById(R.id.activity_stickylistheaders_listview);
        listView.setFitsSystemWindows(true);

        ArrayList<AgentRequestViewModel> list = new ArrayList<>();
        adapter = new AgentRequestsAdapter(this, list);
        AlphaInAnimationAdapter animationAdapter;
        animationAdapter = new AlphaInAnimationAdapter(adapter);

        StickyListHeadersAdapterDecorator stickyListHeadersAdapterDecorator =
                new StickyListHeadersAdapterDecorator(animationAdapter);
        stickyListHeadersAdapterDecorator
                .setListViewWrapper(new StickyListHeadersListViewWrapper(listView));
        assert animationAdapter.getViewAnimator() != null;
        animationAdapter.getViewAnimator().setInitialDelayMillis(500);
        assert stickyListHeadersAdapterDecorator.getViewAnimator() != null;
        stickyListHeadersAdapterDecorator.getViewAnimator()
                .setInitialDelayMillis(500);
        listView.setAdapter(stickyListHeadersAdapterDecorator);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Spinner.show(this);
        final AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int i) {
                mAdView.setVisibility(View.GONE);
            }
        });
        mAdView.loadAd(adRequest);
        new ListRequests().execute();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * Async Task to make http call
     */
    private class ListRequests extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.getRequests(1);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONArray items = result.optJSONArray("items");
                if (!adapter.isEmpty()) {
                    adapter.clear();
                    adapter.getModelList().clear();
                }
                if (items != null) {
                    for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item != null) {
                            AgentRequestViewModel model = new AgentRequestViewModel();
                            model.setId(item.optInt("id", i));
                            model.setImageURL(item.optString("logo"));
                            model.setService(item.optString("name"));
                            model.setClient(item.optString("client"));
                            model.setAmount(item.optString("amount"));
                            model.setDate(item.optString("date"));
                            adapter.getModelList().add(model);
                            adapter.add(item.optString("name"));
                        }
                    }
                }
                swipeContainer.setRefreshing(false);
                Spinner.hide();
            } else {
                Spinner.hide();
                DialogUtils.showError(RequestsActivity.this, RequestsActivity.this.getResources().getString(R.string.request_fetch_failed));
            }
        }
    }

}
