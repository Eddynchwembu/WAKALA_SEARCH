package com.coreit.wakalaapp.agent;

import com.coreit.wakalaapp.component.HttpClient;
import com.coreit.wakalaapp.model.AgentProfile;
import com.coreit.wakalaapp.model.AgentRegisterModel;
import com.coreit.wakalaapp.model.AgentRequestModel;
import com.coreit.wakalaapp.model.LogModel;
import com.coreit.wakalaapp.model.ResetModel;
import com.coreit.wakalaapp.model.SearchModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Handle API calls for Agents.
 * Created by Ramadan on 5/14/2017.
 */

public class Api {

    public static String COMMAND_LOGIN = "agent/login";
    public static String COMMAND_LOGOUT = "agent/logout";
    public static String COMMAND_REGISTER = "agent/register";
    public static String COMMAND_PROFILE = "agent/profile";
    public static String COMMAND_SERVICES = "agent/services";
    public static String COMMAND_SERVICE = "agent/service";
    public static String COMMAND_PROVIDERS = "agent/providers";
    public static String COMMAND_PROVIDER_SERVICES = "agent/provider-services";
    public static String COMMAND_NOTIFICATIONS = "agent/notifications";
    public static String COMMAND_FCM_TOKEN = "agent/fcm-token";
    public static String COMMAND_REQUEST = "agent/request";
    public static String COMMAND_REQUESTS = "agent/requests";
    public static String COMMAND_CLIENTS = "agent/clients";
    public static String COMMAND_HISTORY = "agent/history";
    public static String COMMAND_LOGBOOK = "agent/logbook";
    public static String COMMAND_REQUEST_PASSWORD = "agent/request-password";
    public static String COMMAND_RESET_PASSWORD = "agent/reset-password";
    public static String COMMAND_SERVE_REQUEST = "agent/serve-request";
    public static String COMMAND_SUBMIT_LOG = "agent/submit-log";
    public static String COMMAND_CANCEL_REQUEST = "agent/cancel-request";
    public static String COMMAND_ACK_NOTIFICATION = "agent/ack-notification";

    public static JSONObject register(AgentRegisterModel model) {
        String url = HttpClient.buildUrl(COMMAND_REGISTER, false);
        Map<String, Object> map = new HashMap<>();
        map.put("Register[first_name]", model.firstName);
        map.put("Register[last_name]", model.lastName);
        map.put("Register[business_name]", model.business);
        map.put("Register[business_tin]", model.tin);
        map.put("Register[email]", model.email);
        map.put("Register[mobile_no]", model.phone);
        map.put("Register[latitude]", model.latitude);
        map.put("Register[longitude]", model.longitude);
        map.put("Register[password]", model.password);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject getServices() {
        String url = HttpClient.buildUrl(COMMAND_SERVICES);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject getProviders() {
        String url = HttpClient.buildUrl(COMMAND_PROVIDERS);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject getProviderServices() {
        String url = HttpClient.buildUrl(COMMAND_PROVIDER_SERVICES);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject getClients() {
        String url = HttpClient.buildUrl(COMMAND_CLIENTS);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject profile() {
        String url = HttpClient.buildUrl(COMMAND_PROFILE);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject getNotifications() {
        String url = HttpClient.buildUrl(COMMAND_NOTIFICATIONS);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject Services(String id) {
        Map<String, String> map = new HashMap<>();
        map.put("id", id);
        String url = HttpClient.buildUrl(COMMAND_SERVICES, map);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject serveRequest(String id) {
        Map<String, String> map = new HashMap<>();
        map.put("id", id);
        String url = HttpClient.buildUrl(COMMAND_SERVE_REQUEST, map);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject saveService(String agentCode, Map<String, Boolean> services) {
        String url = HttpClient.buildUrl(COMMAND_SERVICE);

        Map<String, Object> map = new HashMap<>();
        map.put("agentCode", agentCode);
        for (String id : services.keySet()) {
            map.put("service[".concat(id).concat("]"), services.get(id));
        }
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject login(String username, String password) {
        String url = HttpClient.buildUrl(COMMAND_LOGIN, false);
        Map<String, Object> map = new HashMap<>();
        map.put("Login[username]", username);
        map.put("Login[password]", password);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject logout() {
        String url = HttpClient.buildUrl(COMMAND_LOGOUT);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject updateFcmToken(String token) {
        String url = HttpClient.buildUrl(COMMAND_FCM_TOKEN);

        Map<String, Object> map = new HashMap<>();
        map.put("token", token);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject getRequests(int page) {
        String url = HttpClient.buildUrl(COMMAND_REQUESTS);
        try {
            return new JSONObject(HttpClient.doGet(url));
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject getHistory(SearchModel model) {
        String url = HttpClient.buildUrl(COMMAND_HISTORY);
        Map<String, Object> map = new HashMap<>();
        map.put("Search[phone]", model.phone);
        map.put("Search[service]", model.service);
        map.put("Search[date]", model.date);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject getRequest(int id) {

        Map<String, String> map = new HashMap<>();
        map.put("id", String.valueOf(id));
        String url = HttpClient.buildUrl(COMMAND_REQUEST, map);
        try {
            String response = HttpClient.doGet(url);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject submitRequest(AgentRequestModel model) {
        Map<String, String> get = new HashMap<>();
        get.put("id", model.id);
        String url = HttpClient.buildUrl(COMMAND_REQUEST, get);
        Map<String, Object> map = new HashMap<>();
        map.put("ServiceRequest[id]", model.id);
        map.put("ServiceRequest[status]", model.status);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject submitLog(LogModel model) {
        String url = HttpClient.buildUrl(COMMAND_SUBMIT_LOG);
        Map<String, Object> map = new HashMap<>();
        map.put("AgentLog[service_id]", model.serviceId);
        map.put("AgentLog[amount]", model.amount);
        map.put("AgentLog[client_no]", model.clientNumber);
        map.put("AgentLog[comment]", model.comment);
        map.put("AgentLog[service_date]", model.date);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static File getLogbook(SearchModel model, String path) {
        String url = HttpClient.buildUrl(COMMAND_LOGBOOK);
        Map<String, Object> map = new HashMap<>();
        map.put("Search[phone]", model.phone);
        map.put("Search[service]", model.service);
        map.put("Search[date]", model.date);
        try {
            return HttpClient.postDownload(url, "logbook.pdf", path, map);
        } catch (Exception ex) {
            return null;
        }
    }

    public static JSONObject requestPassword(ResetModel model) {
        String url = HttpClient.buildUrl(COMMAND_REQUEST_PASSWORD);
        Map<String, Object> map = new HashMap<>();
        map.put("Password[phone]", model.phone);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static JSONObject resetPassword(ResetModel model) {
        String url = HttpClient.buildUrl(COMMAND_RESET_PASSWORD);
        Map<String, Object> map = new HashMap<>();
        map.put("Password[phone]", model.phone);
        map.put("Password[token]", model.code);
        map.put("Password[password]", model.newPassword);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }


    public static JSONObject updateProfile(AgentProfile model) {
        String url = HttpClient.buildUrl(COMMAND_PROFILE);
        Map<String, Object> map = new HashMap<>();
        map.put("Profile[gender]", model.gender);
        map.put("Profile[email]", model.email);
        map.put("Profile[old_password]", model.oldPassword);
        map.put("Profile[new_password]", model.newPassword);
        map.put("Profile[latitude]", model.latitude);
        map.put("Profile[longitude]", model.longitude);
        map.put("Profile[location]", model.location);
        try {
            String response = HttpClient.doFormPost(url, map);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    /**
     * Gets request details
     *
     * @param id Request id
     * @return Response
     */
    public static JSONObject cancelRequest(int id) {

        Map<String, String> map = new HashMap<>();
        map.put("id", String.valueOf(id));
        String url = HttpClient.buildUrl(COMMAND_CANCEL_REQUEST, map);
        try {
            String response = HttpClient.doGet(url);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }
    /**
     * Gets request details
     *
     * @param id Request id
     * @return Response
     */
    public static JSONObject ackNotification(int id) {

        Map<String, String> map = new HashMap<>();
        map.put("id", String.valueOf(id));
        String url = HttpClient.buildUrl(COMMAND_ACK_NOTIFICATION, map);
        try {
            String response = HttpClient.doGet(url);
            return new JSONObject(response);
        } catch (IOException | JSONException e) {
            return null;
        }
    }
}
