package com.coreit.wakalaapp.view.agent;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import com.coreit.wakalaapp.LoginActivity;
import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.LogModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.widgets.DatepickerFragment;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class LogActivity extends AppCompatActivity {

    private EditText mDate;
    private DatepickerFragment datePicker;
    private android.widget.Spinner mSpinner;
    private Map<String, Integer> mServices;
    private TextView mSave;
    private LogModel model;
    private EditText mAmount;
    private EditText mNumber;
    private EditText mComment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_log);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mDate = (EditText) findViewById(R.id.et_log_date);
        mSpinner = findViewById(R.id.spinner_services);
        mAmount = findViewById(R.id.et_log_amount);
        mNumber = findViewById(R.id.et_log_number);
        mComment = findViewById(R.id.et_log_comment);
        mSave = findViewById(R.id.tv_log_save);

        mDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (datePicker == null) {
                        datePicker = new DatepickerFragment();
                        datePicker.setInput(mDate);
                    }
                    DialogFragment newFragment = datePicker;
                    newFragment.show(getSupportFragmentManager(), "date picker");
                }
            }
        });
        mSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (model == null) {
                    model = new LogModel();
                }
                model.amount = mAmount.getText().toString();
                model.clientNumber = mNumber.getText().toString();
                model.comment = mComment.getText().toString();
                model.date = mDate.getText().toString();
                String sName = (String) mSpinner.getSelectedItem();
                if (mServices.containsKey(sName)) {
                    model.serviceId = mServices.get(sName);
                }
                if (model.validate()) {
                    Spinner.show(LogActivity.this);
                    new SubmitLog().execute(model);
                } else {
                    DialogUtils.showError(LogActivity.this, "Please fill all required fields.");
                }

            }
        });
        Spinner.show(this);
        new GetServices().execute();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * Async Task to make http call
     */
    private class GetServices extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.getProviderServices();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null && result.optInt("status", 0) == 1) {
                if (mServices == null) {
                    mServices = new LinkedHashMap<>();
                }
                mServices.put("Select Service", 0);
                JSONArray items = result.optJSONArray("items");
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    int id = item.optInt("id");
                    String name = item.optString("name");
                    mServices.put(name, id);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(LogActivity.this, R.layout.spinner_log_item, mServices.keySet().toArray(new String[]{}));
                mSpinner.setAdapter(adapter);
            }
        }
    }

    /**
     * Async Task to make http call
     */
    private class SubmitLog extends AsyncTask<LogModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(LogModel... arg0) {
            LogModel model = arg0[0];
            return Api.submitLog(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null && result.optInt("status", 0) == 1) {
                DialogUtils.showSuccess(LogActivity.this, "Log successfully submitted. Click cancel to finish or Ok to add another.", new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        mAmount.setText("");
                        mNumber.setText("");
                        mComment.setText("");
                        dialog.dismiss();
                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {
                        LogActivity.this.finish();
                    }
                });
            } else {
                DialogUtils.showError(LogActivity.this, "Failed to add log, an error was encountered.");
            }
        }
    }


}
