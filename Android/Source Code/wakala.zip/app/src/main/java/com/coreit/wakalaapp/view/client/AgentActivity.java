package com.coreit.wakalaapp.view.client;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.adapter.AgentRatingAdapter;
import com.coreit.wakalaapp.adapter.ServiceAgentAdapter;
import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.AgentModel;
import com.coreit.wakalaapp.model.ClientRequestViewModel;
import com.coreit.wakalaapp.model.RatingViewModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.ImageUtil;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.view.pzv.PullToZoomListViewEx;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class AgentActivity extends AppCompatActivity {

    private AgentModel model;
    private ImageView ivImage;
    private TextView tvName;
    private TextView tvLocation;
    private RatingBar ratingBar;
    private AgentRatingAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent);
        ivImage = (ImageView) findViewById(R.id.header_parallax_agent_image);
        tvName = (TextView) findViewById(R.id.header_parallax_agent_name);
        ratingBar = (RatingBar) findViewById(R.id.rating_bar);
        tvLocation = (TextView) findViewById(R.id.header_parallax_agent_location);
        model = getIntent().getExtras().getParcelable("agent");
        PullToZoomListViewEx listView = (PullToZoomListViewEx) findViewById(R.id.paralax_shop_list_view);
        listView.setShowDividers(0);
        ArrayList<RatingViewModel> list = new ArrayList<>();
        adapter = new AgentRatingAdapter(this, list);
        listView.setAdapter(adapter);
        getSupportActionBar().hide();
        final AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int i) {
                mAdView.setVisibility(View.GONE);
            }
        });
        mAdView.loadAd(adRequest);
        if (model != null) {
            ImageUtil.displayImage(ivImage, model.image, null);
            tvName.setText(model.name);
            tvLocation.setText(model.phone);
            ratingBar.setRating((float) model.rating);
            Spinner.show(this);
            new ListReviews().execute(model.id);
        }
    }


    /**
     * Async Task to make http call
     */
    private class ListReviews extends AsyncTask<Integer, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Integer... arg0) {
            int id = arg0[0];
            return Api.getRatings(id);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONArray items = result.optJSONArray("items");
                if (items != null) {
                    if (!adapter.isEmpty()) {
                        adapter.clear();
                        adapter.getModelList().clear();
                    }
                    for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item != null) {
                            String image = item.optString("clientImage");
                            String name = item.optString("clientName");
                            String comment = item.optString("comment");
                            float rating = Float.valueOf(item.optString("rating"));
                            String time = item.optString("time");
                            RatingViewModel model = new RatingViewModel();
                            model.clientImage = image;
                            model.clientName = name;
                            model.comment = comment;
                            model.rating = rating;
                            model.time = time;
                            adapter.getModelList().add(model);
                        }
                    }
                    adapter.notifyDataSetChanged();
                    // swipeContainer.setRefreshing(false);
                    Spinner.hide();
                }

            } else {
                Spinner.hide();
                DialogUtils.showError(AgentActivity.this, "Failed to get services.");
            }
        }

    }
}
