package com.coreit.wakalaapp.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Ramadan on 3/28/2018.
 */

public class AgentProfile implements Parcelable{
    public String name;
    public String business;
    public String phone;
    public String email;
    public String location;
    public String longitude;
    public String latitude;
    public String gender;
    public String oldPassword;
    public String newPassword;

    public AgentProfile(){

    }

    protected AgentProfile(Parcel in) {
        name = in.readString();
        business = in.readString();
        phone = in.readString();
        email = in.readString();
        location = in.readString();
        longitude = in.readString();
        latitude = in.readString();
    }

    public static final Creator<AgentProfile> CREATOR = new Creator<AgentProfile>() {
        @Override
        public AgentProfile createFromParcel(Parcel in) {
            return new AgentProfile(in);
        }

        @Override
        public AgentProfile[] newArray(int size) {
            return new AgentProfile[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(business);
        dest.writeString(phone);
        dest.writeString(email);
        dest.writeString(location);
        dest.writeString(longitude);
        dest.writeString(latitude);
    }
}
