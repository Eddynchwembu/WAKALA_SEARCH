package com.coreit.wakalaapp.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Ramadan on 4/2/2018.
 */

public class ServiceRequestModel implements Parcelable {
    public int id;
    public String amount;
    public String serviceName;
    public String providerName;
    public String time;
    public int status;
    public AgentModel agent;

    public ServiceRequestModel(){

    }
    protected ServiceRequestModel(Parcel in) {
        id = in.readInt();
        amount = in.readString();
        serviceName = in.readString();
        providerName = in.readString();
        time = in.readString();
        status = in.readInt();
        agent = in.readParcelable(AgentProfile.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(amount);
        dest.writeString(serviceName);
        dest.writeString(providerName);
        dest.writeString(time);
        dest.writeInt(status);
        dest.writeParcelable(agent, flags);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ServiceRequestModel> CREATOR = new Creator<ServiceRequestModel>() {
        @Override
        public ServiceRequestModel createFromParcel(Parcel in) {
            return new ServiceRequestModel(in);
        }

        @Override
        public ServiceRequestModel[] newArray(int size) {
            return new ServiceRequestModel[size];
        }
    };
}
