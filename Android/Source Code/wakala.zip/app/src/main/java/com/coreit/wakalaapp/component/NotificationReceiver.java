package com.coreit.wakalaapp.component;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.view.agent.MainActivity;
import com.coreit.wakalaapp.view.client.RequestDetailActivity;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.io.IOException;
import java.net.URL;
import java.util.Map;

/**
 * Created by Ramadan on 3/31/2018.
 */

public class NotificationReceiver extends FirebaseMessagingService {

    private static final String TAG = "WakalaAppFcmService";

    String GROUP_KEY_NOTIFICATION = "com.coreit.wakalapp.NOTIFICATION";

    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */
    // [START receive_message]
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // [START_EXCLUDE]
        // There are two types of messages data messages and notification messages. Data messages are handled
        // here in onMessageReceived whether the app is in the foreground or background. Data messages are the type
        // traditionally used with GCM. Notification messages are only received here in onMessageReceived when the app
        // is in the foreground. When the app is in the background an automatically generated notification is displayed.
        // When the user taps on the notification they are returned to the app. Messages containing both notification
        // and data payloads are treated as notification messages. The Firebase console always sends notification
        // messages. For more see: https://firebase.google.com/docs/cloud-messaging/concept-options
        // [END_EXCLUDE]

        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
        }
        handleNotification(remoteMessage);
    }
    // [END receive_message]

    /**
     * Schedule a job using FirebaseJobDispatcher.
     */
    private void scheduleJob() {
        // [START dispatch_job]
        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(this));
        Job myJob = dispatcher.newJobBuilder()
                .setService(AgentNotifierService.class)
                .setTag("agent-notifier")
                .build();
        dispatcher.schedule(myJob);
        // [END dispatch_job]
    }

    /**
     * Handle time allotted to BroadcastReceivers.
     */
    private void handleNow() {
        Log.d(TAG, "Short lived task is done.");
    }

    /**
     * Create and show a simple notification containing the received FCM message.
     *
     * @param message FCM message body received.
     */
    private void handleNotification(RemoteMessage message) {
        Map<String, String> data = message.getData();
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        String _for = data.get("for");
        String type = pref.getString(App.PREF_USER_TYPE, "");
        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(this));
        Job.Builder builder = dispatcher.newJobBuilder();
        Bundle extra = new Bundle();
        for (String o : data.keySet()) {
            extra.putString(o, data.get(o));
        }
        builder.setExtras(extra);
        if (_for.equals("agent")) {
            if (type.equals("agent")) {
                builder.setService(AgentNotifierService.class)
                        .setTag("agent-notifier");
            } else {
                return;
            }
        } else if (_for.equals("client")) {
            if (type.equals("client")) {
                builder.setService(ClientNotifierService.class)
                        .setTag("client-notifier");
            } else {
                return;
            }
        } else {
            return;
        }
        Job job = builder.build();
        dispatcher.mustSchedule(job);
    }

    private void notifyAgent(Map<String, String> data) {
        int id = Integer.valueOf(data.get("id"));
        String client = data.get("client");
        String text = data.get("message");
        String time = data.get("time");
        String account = data.get("account");
        String image = data.get("image");

        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent,
                PendingIntent.FLAG_ONE_SHOT);

        String channelId = "app.notification";// getString();
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
        style.setSummaryText(account);
        style.addLine(client.concat(" ").concat(text));

        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(this, channelId)
                        .setSmallIcon(R.drawable.notification_icon)
                        .setContentTitle(client)
                        .setContentText(text)
                        .setGroup(GROUP_KEY_NOTIFICATION)
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent);
        URL url = null;
        try {
            url = new URL(image);
            Bitmap bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
            notificationBuilder.setLargeIcon(bitmap);
        } catch (IOException e) {
            e.printStackTrace();
        }
        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId,
                    "New notification",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify(id, notificationBuilder.build());

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, channelId)
                        .setContentTitle("WakalaSearch")
                        //set content comment to support devices running API level < 24
                        .setContentText("You have new notification.")
                        .setSmallIcon(R.drawable.notification_icon)
                        .setStyle(style)
                        //specify which group this notification belongs to
                        .setGroup(GROUP_KEY_NOTIFICATION)
                        .setSound(defaultSoundUri)
                        .setAutoCancel(true)
                        //set this notification as the summary for the group
                        .setGroupSummary(true);
        notificationManager.notify(0, builder.build());
        Api.ackNotification(id);
    }

    private void notifyClient(Map<String, String> data) {
        int id = Integer.valueOf(data.get("id"));
        String type = data.get("type");
        String time = data.get("time");
        String text = data.get("message");
        String account = data.get("account");
        String channelId = "app.notification";// getString();
        NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
        style.setSummaryText(account);
        String title;
        String image = null;
        PendingIntent pendingIntent;
        if (type.equals("0")) {
            title = data.get("agent");
            image = data.get("image");
            Intent intent = new Intent(this, RequestDetailActivity.class);
            intent.putExtra("id", id);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            pendingIntent = PendingIntent.getActivity(this, id, intent, PendingIntent.FLAG_ONE_SHOT);
        } else {
            title = data.get("title");
            pendingIntent = null;
        }


        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        style.addLine(text);

        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(this, channelId)
                        .setSmallIcon(R.drawable.notification_icon)
                        .setContentTitle(title)
                        .setContentText(text)
                        .setGroup(GROUP_KEY_NOTIFICATION)
                        .setAutoCancel(true);
        if (pendingIntent != null) {
            notificationBuilder.setContentIntent(pendingIntent);
        }
        if (image != null) {
            URL url;
            try {
                url = new URL(image);
                Bitmap bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                notificationBuilder.setLargeIcon(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId,
                    "New notification",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify(id, notificationBuilder.build());

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, channelId)
                        .setContentTitle("WakalaSearch")
                        //set content comment to support devices running API level < 24
                        .setContentText("You have new notification.")
                        .setSmallIcon(R.drawable.notification_icon)
                        .setStyle(style)
                        //specify which group this notification belongs to
                        .setGroup(GROUP_KEY_NOTIFICATION)
                        .setSound(defaultSoundUri)
                        .setAutoCancel(true)
                        //set this notification as the summary for the group
                        .setGroupSummary(true);
        notificationManager.notify(0, builder.build());
        com.coreit.wakalaapp.client.Api.ackNotification(id);
    }
}
