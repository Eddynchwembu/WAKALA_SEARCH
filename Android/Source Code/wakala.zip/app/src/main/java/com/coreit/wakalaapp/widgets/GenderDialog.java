package com.coreit.wakalaapp.widgets;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.R;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class GenderDialog extends Dialog {

    private TextView mDialogOKButton;
    private TextView mDialogCancelButton;
    RadioGroup langGroup;
    SharedPreferences pref;

    public GenderDialog(Context context) {
        super(context, R.style.CustomDialogTheme);
        setContentView(R.layout.dialog_gender);
        setCancelable(true);

        pref = PreferenceManager.getDefaultSharedPreferences(context);
        mDialogOKButton = (TextView) findViewById(R.id.dialog_ok);
        mDialogCancelButton = (TextView) findViewById(R.id.dialog_cancel);
        langGroup = (RadioGroup) findViewById(R.id.radio_group_gender);
        String lang = pref.getString(App.PREF_USER_GENDER, "Male");
        if (lang.equals("Male")) {
            RadioButton button = (RadioButton) findViewById(R.id.radio_male);
            button.setChecked(true);
        } else {
            RadioButton button = (RadioButton) findViewById(R.id.radio_female);
            button.setChecked(true);
        }
        setOnCancelListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    public String getSelectedGender() {
        int id = langGroup.getCheckedRadioButtonId();
        String lang;
        if (id == R.id.radio_male) {
            lang = "Male";
        } else {
            lang = "Female";
        }
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(App.PREF_LANGUAGE, lang);
        editor.apply();
        return lang;
    }

    public GenderDialog setOnOkListener(View.OnClickListener listener) {
        mDialogOKButton.setOnClickListener(listener);
        return this;
    }

    public GenderDialog setOnCancelListener(View.OnClickListener listener) {
        mDialogCancelButton.setOnClickListener(listener);
        return this;
    }
}
