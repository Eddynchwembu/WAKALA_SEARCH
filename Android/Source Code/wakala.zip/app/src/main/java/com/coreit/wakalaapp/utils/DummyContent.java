package com.coreit.wakalaapp.utils;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.model.ClientRequestViewModel;

import java.util.ArrayList;

/**
 * Created by Ramadan on 3/25/2018.
 */

public class DummyContent {
    public static ArrayList<ClientRequestViewModel> getClientRequestModelList() {
        ArrayList<ClientRequestViewModel> list = new ArrayList<>();

        list.add(new ClientRequestViewModel(0, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213228465aad8b5e3cb5a.jpg", "MPesa", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(1, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213745975aae5585c757e.jpg", "Mpesa", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(2, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213228465aad8b5e3cb5a.jpg", "Abigail Ross", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(3, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213745975aae5585c757e.jpg", "Justin Rutherford", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(4, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213228465aad8b5e3cb5a.jpg", "Nicholas Henderson", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(5, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213745975aae5585c757e.jpg", "Elizabeth Mackenzie", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(6, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213745975aae5585c757e.jpg", "Melanie Ferguson", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(7, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213745975aae5585c757e.jpg", "Fiona Kelly", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(8, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213745975aae5585c757e.jpg", "Nicholas King", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(9, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213745975aae5585c757e.jpg", "Victoria Mitchell", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(10, "http://pengaja.com/uiapptemplate/newphotos/profileimages/10.jpg", "Sophie Lyman", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(11, "http://pengaja.com/uiapptemplate/newphotos/profileimages/11.jpg", "Carl Ince", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(12, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213228465aad8b5e3cb5a.jpg", "Michelle Slater", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(13, "http://pengaja.com/uiapptemplate/newphotos/profileimages/13.jpg", "Ryan Mathis", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(14, "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213228465aad8b5e3cb5a.jpg", "Julia Grant", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(15, "http://pengaja.com/uiapptemplate/newphotos/profileimages/15.jpg", "Hannah Martin", R.string.fontello_heart_empty));

        return list;
    }

    public static ArrayList<ClientRequestViewModel> getClientRequestModelDragAndDropShopList() {
        ArrayList<ClientRequestViewModel> list = new ArrayList<>();

        list.add(new ClientRequestViewModel(0, "http://pengaja.com/uiapptemplate/newphotos/shop/0.jpg", "Black Shirt", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(1, "http://pengaja.com/uiapptemplate/newphotos/shop/1.jpg", "Black Sweater", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(2, "http://pengaja.com/uiapptemplate/newphotos/shop/2.jpg", "Shirt", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(3, "http://pengaja.com/uiapptemplate/newphotos/shop/3.jpg", "White Shirt", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(4, "http://pengaja.com/uiapptemplate/newphotos/shop/4.jpg", "White T shirt", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(5, "http://pengaja.com/uiapptemplate/newphotos/shop/5.jpg", "T shirt", R.string.fontello_heart_empty));
        list.add(new ClientRequestViewModel(6, "http://pengaja.com/uiapptemplate/newphotos/shop/6.jpg", "Hoodies", R.string.fontello_heart_empty));

        return list;
    }
}
