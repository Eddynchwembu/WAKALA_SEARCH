package com.coreit.wakalaapp.agent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class AlarmReceiver extends BroadcastReceiver {

    public static final int REQUEST_CODE = 12345;
    int nCount = 1;
    @Override
    public void onReceive(Context context, Intent intent) {

        Intent i = new Intent(context, NotificationServiceOld.class);
        i.putExtra("count",nCount);
        context.startService(i);
        nCount++;
    }
}
