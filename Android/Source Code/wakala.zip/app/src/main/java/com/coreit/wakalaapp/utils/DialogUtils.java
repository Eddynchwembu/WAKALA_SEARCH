package com.coreit.wakalaapp.utils;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.R;

import java.util.ArrayList;
import java.util.List;


public class DialogUtils {

    private Context context;
    private Dialog mDialog;

    private TextView mDialogText;
    private TextView mDialogOKButton;
    private TextView mDialogCancelButton;
    private TextView mDialogTitle;
    private LinearLayout mDialogBox;

    private String message = "";
    private String title = "Info";
    private List<DialogListener> listeners;
    public boolean dismissOnOk = true;
    public String okLabel = "Ok";
    public String cancelLabel = "Cancel";
    public boolean enableOk = true;
    public boolean enableCancel = true;

    public DialogUtils(Context context) {
        this.context = context;
    }

    public DialogUtils(Context context, String content) {
        this.context = context;
        this.message = content;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    private void initDialog() {
        if (mDialog == null) {
            mDialog = new Dialog(context,
                    R.style.CustomDialogTheme);
        }
        mDialog.setContentView(R.layout.dialog_layout);
        mDialog.setCancelable(true);

        mDialogText = (TextView) mDialog
                .findViewById(R.id.dialog_content);
        mDialogOKButton = (TextView) mDialog
                .findViewById(R.id.dialog_ok);

        mDialogOKButton.setEnabled(enableOk);
        mDialogOKButton.setText(okLabel);
        mDialogCancelButton = (TextView) mDialog
                .findViewById(R.id.dialog_cancel);
        mDialogCancelButton.setEnabled(enableCancel);
        mDialogCancelButton.setText(cancelLabel);
        mDialogTitle = (TextView) mDialog.findViewById(R.id.dialog_title);
        mDialogBox = (LinearLayout) mDialog.findViewById(R.id.dialog_color);
        mDialogOKButton.setText(okLabel);
        mDialogCancelButton.setText(cancelLabel);
    }

    public void showInfoDialog(String message) {
        initDialog();
        this.title = "Info";
        this.message = message;
        mDialogBox.setBackgroundResource(R.color.material_blue_600);
        mDialogTitle.setText(title);
        mDialogText.setText(message);
        initDialogButtons();
        mDialog.show();
    }

    public void showConfirmDialog(String message) {
        this.title = "Info";
        this.message = message;
        okLabel = "Yes";
        cancelLabel = "No";
        initDialog();
        mDialogBox.setBackgroundResource(R.color.material_blue_600);
        mDialogTitle.setText(title);
        mDialogText.setText(message);
        initDialogButtons();
        mDialog.show();
    }

    public void showErrorDialog(String message) {
        initDialog();
        this.title = "Error";
        this.message = message;
        mDialogBox.setBackgroundResource(R.color.material_red_600);
        mDialogTitle.setText(title);
        mDialogText.setText(message);
        initDialogButtons();
        mDialog.show();
    }

    public void showWarningDialog(String message) {
        initDialog();
        this.title = "Warning";
        this.message = message;
        mDialogBox.setBackgroundResource(R.color.material_yellow_600);
        mDialogTitle.setText(title);
        mDialogText.setText(message);
        initDialogButtons();
        mDialog.show();
    }

    public void showSuccessDialog(String message) {
        initDialog();
        this.title = "Success";
        this.message = message;
        mDialogBox.setBackgroundResource(R.color.material_green_600);
        mDialogTitle.setText(title);
        mDialogText.setText(message);
        initDialogButtons();
        mDialog.show();
    }

    public void showDialog() {

        initDialog();

        mDialog.show();

        initDialogButtons();
    }

    private void initDialogButtons() {

        mDialogOKButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                if (listeners != null && !listeners.isEmpty()) {
                    for (DialogListener listener : listeners) {
                        listener.onOkClick(context, mDialog, view);
                    }
                }
                if (dismissOnOk) {
                    dismissDialog();
                }
            }
        });

        mDialogCancelButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.dismiss();
                if (listeners != null && !listeners.isEmpty()) {
                    for (DialogListener listener : listeners) {
                        listener.onCancelClick(context, mDialog, view);
                    }
                }
            }
        });
    }

    public void dismissDialog() {
        mDialog.dismiss();
    }

    public void addOkListener(DialogListener listener) {
        if (listeners == null) {
            listeners = new ArrayList<>();
        }
        listeners.add(listener);
    }

    public interface DialogListener {
        public void onOkClick(Context context, Dialog dialog, View view);

        public void onCancelClick(Context context, Dialog dialog, View view);
    }

    private static void showDialog(int type, Context context, String message, DialogListener listener) {
        DialogUtils dialog = new DialogUtils(context);
        if (listener != null) {
            dialog.addOkListener(listener);
        }
        switch (type) {
            case 0:
                dialog.showSuccessDialog(message);
                break;
            case 1:
                dialog.showWarningDialog(message);
                break;
            case 2:
                dialog.showErrorDialog(message);
                break;
            case 3:
                dialog.showInfoDialog(message);
                break;
            case 4:
                dialog.showConfirmDialog(message);
                break;
        }
    }


    public static void showInfo(Context context, String message, DialogListener listener) {
        showDialog(3, context, message, listener);
    }

    public static void showConfirm(Context context, String message, DialogListener listener) {
        showDialog(4, context, message, listener);
    }

    public static void showSuccess(Context context, String message, DialogListener listener) {
        showDialog(0, context, message, listener);
    }

    public static void showWarning(Context context, String message, DialogListener listener) {
        showDialog(1, context, message, listener);
    }

    public static void showError(Context context, String message, DialogListener listener) {
        showDialog(2, context, message, listener);
    }

    public static void showSuccess(Context context, String message) {
        showSuccess(context, message, null);
    }

    public static void showWarning(Context context, String message) {
        showWarning(context, message, null);
    }

    public static void showError(Context context, String message) {
        showError(context, message, null);
    }

    public static void showInfo(Context context, String message) {
        showInfo(context, message, null);
    }

    public static void showConfirm(Context context, String message) {
        showConfirm(context, message, null);
    }
}
