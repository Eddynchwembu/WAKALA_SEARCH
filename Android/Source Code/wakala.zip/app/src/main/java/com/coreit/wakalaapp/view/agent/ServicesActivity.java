package com.coreit.wakalaapp.view.agent;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.adapter.ServiceAdapter;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.ServiceViewModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.DummyContent;
import com.coreit.wakalaapp.utils.Spinner;
import com.nhaarman.listviewanimations.appearance.AnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.SwingBottomInAnimationAdapter;
import com.nhaarman.listviewanimations.itemmanipulation.DynamicListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ServicesActivity extends AppCompatActivity {

    private DynamicListView mDynamicListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_services);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Spinner.show(this);
        new ListServices().execute();
    }


    /**
     * Async Task to make http call
     */
    private class ListServices extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.getProviders();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONArray items = result.optJSONArray("items");
                if (items != null) {

                    final ArrayList<ServiceViewModel> providers = new ArrayList<>();

                    mDynamicListView = (DynamicListView) findViewById(R.id.list_view);

                    for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item != null) {
                            ServiceViewModel model = new ServiceViewModel();
                            model.setText(item.optString("name"));
                            model.setImageURL(item.optString("logo"));
                            model.setId(Long.valueOf(item.optString("id")));
                            providers.add(model);
                        }
                    }


                    BaseAdapter adapter = new ServiceAdapter(ServicesActivity.this, providers, false);
                    AnimationAdapter animAdapter;
                    animAdapter = new SwingBottomInAnimationAdapter(adapter);
                    animAdapter.setAbsListView(mDynamicListView);
                    mDynamicListView.setAdapter(animAdapter);
                    mDynamicListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            ServiceViewModel item = providers.get(position);
                            item.getId();
                            Intent i = new Intent(ServicesActivity.this, ServiceDetailActivity.class);
                            i.putExtra("providerName", item.getText());
                            i.putExtra("providerId", item.getId());
                            startActivity(i);
                        }
                    });
                }

            } else {
                DialogUtils.showError(ServicesActivity.this, "Failed to get services.");
            }
            Spinner.hide();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
