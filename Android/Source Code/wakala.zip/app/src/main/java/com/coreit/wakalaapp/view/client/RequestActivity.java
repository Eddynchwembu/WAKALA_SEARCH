package com.coreit.wakalaapp.view.client;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.adapter.ServiceAgentAdapter;
import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.AgentViewModel;
import com.coreit.wakalaapp.model.ClientRequestModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.GPSTracker;
import com.coreit.wakalaapp.utils.Spinner;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.nhaarman.listviewanimations.itemmanipulation.DynamicListView;
import com.nhaarman.listviewanimations.itemmanipulation.swipedismiss.OnDismissCallback;
import com.nhaarman.listviewanimations.itemmanipulation.swipedismiss.undo.SimpleSwipeUndoAdapter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class RequestActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private LinearLayout view;
    private DynamicListView mDynamicListView;
    private TextView mSearchTextView;
    private TextView mSubmitTextView;
    private EditText mAmountInput;
    private TextView mProviderTv;
    private TextView mServiceTv;
    private TextView mAgentsTv;
    private String serviceId;
    private double latitude;
    private double longitude;
    private int nAgents;
    private boolean bShowList = false;
    private ServiceAgentAdapter mAdapter;
    private ArrayList<AgentViewModel> mAgentModel;
    private GPSTracker gps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_request);
        view = (LinearLayout) findViewById(R.id.request_view);
        mSearchTextView = (TextView) findViewById(R.id.client_request_search);
        mSubmitTextView = (TextView) findViewById(R.id.client_request_submit);
        mAmountInput = (EditText) findViewById(R.id.client_request_amount);
        mProviderTv = (TextView) findViewById(R.id.client_request_provider);
        mServiceTv = (TextView) findViewById(R.id.client_request_service);
        mAgentsTv = (TextView) findViewById(R.id.client_request_agents);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String provider = extras.getString("providerName");
            String service = extras.getString("serviceName");
            serviceId = extras.getString("serviceId");
            mProviderTv.setText(provider);
            mServiceTv.setText(service);
            setTitle(provider.concat(" - ").concat(service));
        }
        final SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        mSearchTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount = mAmountInput.getText().toString();
                String radius = pref.getString(App.PREF_RADIUS, "1");
                if (amount.isEmpty()) {
                    DialogUtils.showError(RequestActivity.this, "Please enter request amount.");
                } else {
                    ClientRequestModel model = new ClientRequestModel();
                    model.latitude = String.valueOf(latitude);
                    model.longitude = String.valueOf(longitude);
                    model.radius = radius;
                    model.serviceId = serviceId;
                    model.amount = amount;
                    Spinner.show(RequestActivity.this);
                    new SearchAgents().execute(model);
                }
            }
        });

        mSubmitTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nAgents == 0) {
                    DialogUtils.showError(RequestActivity.this, "Please search agents first.");
                } else {
                    String amount = mAmountInput.getText().toString();
                    String radius = pref.getString(App.PREF_RADIUS, "1");
                    if (amount.isEmpty()) {
                        DialogUtils.showError(RequestActivity.this, "Please enter request amount.");
                    } else {
                        ClientRequestModel model = new ClientRequestModel();
                        model.latitude = String.valueOf(latitude);
                        model.longitude = String.valueOf(longitude);
                        model.radius = radius;
                        model.serviceId = serviceId;
                        model.amount = amount;
                        Spinner.show(RequestActivity.this);
                        new SubmitRequest().execute(model);
                    }
                }

            }
        });
        bShowList = pref.getBoolean("show_list", false);

        gps = new GPSTracker(this);
        if (!bShowList) {
            LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            inflater.inflate(R.layout.fragment_map, view);
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);
        } else {
            LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            inflater.inflate(R.layout.fragment_agent_list, view);
            mDynamicListView = (DynamicListView) findViewById(R.id.activity_swip_to_dissmiss_shop_dynamic_listview);

            if (gps.canGetLocation()) {
                latitude = gps.getLatitude();
                longitude = gps.getLongitude();
            } else {
                DialogUtils.showError(this, "Please turn on location service.", new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        dialog.dismiss();
                        finish();
                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {

                    }
                });
            }
        }
        final AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int i) {
                mAdView.setVisibility(View.GONE);
            }
        });
        mAdView.loadAd(adRequest);

    }

    private void setUpAgentAdapter() {
        mAgentModel = new ArrayList<>();
        mAdapter = new ServiceAgentAdapter(
                this, mAgentModel);
        SimpleSwipeUndoAdapter swipeUndoAdapter = new SimpleSwipeUndoAdapter(
                mAdapter, this, new OnDismissCallback() {
            @Override
            public void onDismiss(@NonNull final ViewGroup listView,
                                  @NonNull final int[] reverseSortedPositions) {
                for (int position : reverseSortedPositions) {
                    mAdapter.remove(position);
                }
            }
        });
        swipeUndoAdapter.setAbsListView(mDynamicListView);
        mDynamicListView.setAdapter(swipeUndoAdapter);
        mDynamicListView.enableSimpleSwipeUndo();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (gps.canGetLocation()) {
            latitude = gps.getLatitude(); // returns latitude
            longitude = gps.getLongitude(); // returns longitude

            LatLng location = new LatLng(latitude, longitude);
            mMap.addMarker(new MarkerOptions().position(location).title("Your position").icon(BitmapDescriptorFactory.fromResource(R.drawable.client_marker)));
            mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

                @Override
                public View getInfoWindow(Marker arg0) {
                    return null;
                }

                @Override
                public View getInfoContents(Marker marker) {

                    LinearLayout info = new LinearLayout(RequestActivity.this);
                    info.setOrientation(LinearLayout.VERTICAL);

                    TextView title = new TextView(RequestActivity.this);
                    title.setTextColor(Color.BLACK);
                    title.setGravity(Gravity.CENTER);
                    title.setTypeface(null, Typeface.BOLD);
                    title.setText(marker.getTitle());

                    TextView snippet = new TextView(RequestActivity.this);
                    snippet.setTextColor(Color.GRAY);
                    snippet.setText(marker.getSnippet());

                    info.addView(title);
                    info.addView(snippet);

                    return info;
                }
            });
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(location, 15);
            googleMap.animateCamera(update);
        } else {
            DialogUtils.showError(this, "Please turn on location service.", new DialogUtils.DialogListener() {
                @Override
                public void onOkClick(Context context, Dialog dialog, View view) {
                    dialog.dismiss();
                    finish();
                }

                @Override
                public void onCancelClick(Context context, Dialog dialog, View view) {

                }
            });
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * Async Task to make http call
     */
    private class SearchAgents extends AsyncTask<ClientRequestModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(ClientRequestModel... arg0) {
            ClientRequestModel model = arg0[0];
            return Api.searchAgents(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONArray agents = result.optJSONArray("items");
                if (agents != null && agents.length() > 0) {
                    mAgentsTv.setText(String.valueOf(agents.length()));
                    nAgents = agents.length();
                    if (bShowList) {
                        mAgentModel = new ArrayList<>();
                    }
                    for (int i = 0; i < agents.length(); i++) {
                        JSONObject agent = agents.optJSONObject(i);
                        if (agent != null) {
                            double lat = agent.optDouble("latitude");
                            double lon = agent.optDouble("longitude");
                            String name = agent.optString("name");
                            String distance = agent.optString("distance");
                            String rating = agent.optString("rating");
                            String location = agent.optString("location");
                            String image = agent.optString("image");
                            String till = agent.optString("till");
                            if (!bShowList) {
                                Marker marker = mMap.addMarker(new MarkerOptions()
                                        .position(new LatLng(lat, lon))
                                        .title(name)
                                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.agent_marker))
                                        .snippet("Distance: " + distance + " km" + "\n" + "Till No: " + till + "\n" + "Rating: " + rating));
                            } else {
                                AgentViewModel model = new AgentViewModel();
                                model.name = name;
                                model.distance = distance;
                                model.rating = rating;
                                model.location = location;
                                model.imageUrl = image;
                                mAgentModel.add(model);
                            }

                        }
                    }
                    if (bShowList) {
                        mAdapter = new ServiceAgentAdapter(
                                RequestActivity.this, mAgentModel);
                        SimpleSwipeUndoAdapter swipeUndoAdapter = new SimpleSwipeUndoAdapter(
                                mAdapter, RequestActivity.this, new OnDismissCallback() {
                            @Override
                            public void onDismiss(@NonNull final ViewGroup listView,
                                                  @NonNull final int[] reverseSortedPositions) {
                                for (int position : reverseSortedPositions) {
                                    mAdapter.remove(position);
                                }
                            }
                        });
                        swipeUndoAdapter.setAbsListView(mDynamicListView);
                        mDynamicListView.setAdapter(swipeUndoAdapter);
                        mDynamicListView.enableSimpleSwipeUndo();
                    }
                } else {
                    DialogUtils.showWarning(RequestActivity.this, "No agents found nearby you can increase radius and search again.");
                }

            } else {
                DialogUtils.showError(RequestActivity.this, "Failed to get agents.");
            }
            Spinner.hide();
        }

    }

    /**
     * Async Task to make http call
     */
    private class SubmitRequest extends AsyncTask<ClientRequestModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(ClientRequestModel... arg0) {
            ClientRequestModel model = arg0[0];
            return Api.submitRequest(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null && result.optInt("status", 0) == 1) {
                String message = result.optString("message", "Request successfully sent.");
                DialogUtils.showSuccess(RequestActivity.this, message, new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        dialog.dismiss();
                        finish();
                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {

                    }
                });
            } else {
                DialogUtils.showError(RequestActivity.this, "Failed to get agents.");
            }
        }
    }
}
