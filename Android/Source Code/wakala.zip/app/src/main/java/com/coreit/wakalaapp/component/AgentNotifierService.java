package com.coreit.wakalaapp.component;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.view.agent.MainActivity;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import java.io.IOException;
import java.net.URL;

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class AgentNotifierService extends JobService {
    String GROUP_KEY_NOTIFICATION = "com.coreit.wakalapp.NOTIFICATION";

    @Override
    public boolean onStartJob(JobParameters params) {
        run(params);
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }

    void run(final JobParameters job) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Bundle data = job.getExtras();

                int id = Integer.valueOf(data.getString("id"));
                String client = data.getString("client");
                String text = data.getString("message");
                String time = data.getString("time");
                String account = data.getString("account");
                String image = data.getString("image");

                Intent intent = new Intent(AgentNotifierService.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                PendingIntent pendingIntent = PendingIntent.getActivity(AgentNotifierService.this, 0 /* Request code */, intent,
                        PendingIntent.FLAG_ONE_SHOT);

                String channelId = "app.notification";// getString();
                Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
                style.setSummaryText(account);
                style.addLine(client.concat(" ").concat(text));

                NotificationCompat.Builder notificationBuilder =
                        new NotificationCompat.Builder(AgentNotifierService.this, channelId)
                                .setSmallIcon(R.drawable.notification_icon)
                                .setContentTitle(client)
                                .setContentText(text)
                                .setGroup(GROUP_KEY_NOTIFICATION)
                                .setAutoCancel(true)
                                .setContentIntent(pendingIntent);
                URL url = null;
                try {
                    url = new URL(image);
                    Bitmap bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    notificationBuilder.setLargeIcon(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                NotificationManager notificationManager =
                        (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                // Since android Oreo notification channel is needed.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel(channelId,
                            "New notification",
                            NotificationManager.IMPORTANCE_DEFAULT);
                    notificationManager.createNotificationChannel(channel);
                }

                notificationManager.notify(id, notificationBuilder.build());

                NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(AgentNotifierService.this, channelId)
                                .setContentTitle("WakalaSearch")
                                //set content comment to support devices running API level < 24
                                .setContentText("You have new notification.")
                                .setSmallIcon(R.drawable.notification_icon)
                                .setStyle(style)
                                //specify which group this notification belongs to
                                .setGroup(GROUP_KEY_NOTIFICATION)
                                .setSound(defaultSoundUri)
                                .setAutoCancel(true)
                                //set this notification as the summary for the group
                                .setGroupSummary(true);
                notificationManager.notify(0, builder.build());
                Api.ackNotification(id);
                jobFinished(job, false);
            }
        }).start();
    }
}
