package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 3/26/2018.
 */

public class ClientRequestModel {
    public String serviceId;
    public String radius;
    public String latitude;
    public String longitude;
    public String amount;
}
