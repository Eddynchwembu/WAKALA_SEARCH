package com.coreit.wakalaapp.model;

public class ClientRequestViewModel {

    public long id;
    public String imageURL;
    public String service;
    public String agent;
    public String agentId;
    public String amount;
    public String date;
    public String mAgo;
    public String latitude;
    public String longitude;
    public String provider;
    public int status;

    private int mIconRes;

    public ClientRequestViewModel() {
    }

    public ClientRequestViewModel(long id, String imageURL, String text, int iconRes) {
        this.id = id;
        this.imageURL = imageURL;
        service = text;
        mIconRes = iconRes;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getService() {
        return service;
    }

    public void setService(String text) {
        service = text;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }

    public String getAgent() {
        return agent;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setDate(String date){
        this.date = date;
    }

    public String getDate(){
        return date;
    }

    public void setAgo(String date){
        mAgo = date;
    }

    public String getAgo(){
        return  mAgo;
    }

    public int getIconRes() {
        return mIconRes;
    }

    public void setIconRes(int iconRes) {
        mIconRes = iconRes;
    }

    @Override
    public String toString() {
        return service;
    }
}
