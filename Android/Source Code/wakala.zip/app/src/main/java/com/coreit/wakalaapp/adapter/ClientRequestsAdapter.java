package com.coreit.wakalaapp.adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.AgentModel;
import com.coreit.wakalaapp.model.ClientRequestViewModel;
import com.coreit.wakalaapp.model.RatingModel;
import com.coreit.wakalaapp.model.ServiceRequestModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.ImageUtil;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.view.client.RequestDetailActivity;
import com.coreit.wakalaapp.widgets.RatingDialog;
import com.nhaarman.listviewanimations.ArrayAdapter;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import se.emilsjolander.stickylistheaders.StickyListHeadersAdapter;

public class ClientRequestsAdapter extends ArrayAdapter<String>
        implements StickyListHeadersAdapter, OnClickListener {

    private final Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<ClientRequestViewModel> mModelList;
    private Map<String, Long> headers;

    public ClientRequestsAdapter(final Context context, ArrayList<ClientRequestViewModel> modelList) {
        mContext = context;
        mModelList = modelList;
        mInflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        headers = new HashMap<>();
    }

    @Override
    public long getItemId(final int position) {
        return getItem(position).hashCode();
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        ClientRequestViewModel model = getModelList().get(position);
        if (convertView == null) {
            convertView = mInflater.inflate(
                    R.layout.list_item_sticky_header_client_request, parent, false);
            holder = new ViewHolder();
            holder.layout = convertView.findViewById(R.id.layout_client_request);
            holder.layout.setTag(model.getId());
            holder.image = (ImageView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_image);
            holder.serviceName = (TextView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_album_name);
            holder.agentName = (TextView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_artist_name);
            holder.amount = (TextView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_time);
            holder.actionIcon = (TextView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_icon_cancel);
            holder.layout.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    long id = (long) view.getTag();
                    Spinner.show(mContext);
                    new GetRequest().execute(id);
                }
            });
            holder.actionIcon.setOnClickListener(this);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            holder.layout.setTag(model.getId());
        }
        if (model.status == 3) {
            holder.actionIcon.setText(R.string.material_icon_star);
            holder.actionIcon.setTextColor(mContext.getResources().getColor(R.color.material_light_yellow_400));
        } else {
            holder.actionIcon.setText(R.string.material_icon_close);
            holder.actionIcon.setTextColor(mContext.getResources().getColor(R.color.material_red_500));
        }

        ImageUtil.displayImage(holder.image, model.getImageURL(), null);
        holder.serviceName.setText(model.getService());
        holder.agentName.setText(model.getAgent());
        holder.amount.setText(model.getAmount());
        holder.actionIcon.setTag(position);

        return convertView;
    }

    private static class ViewHolder {
        public ImageView image;
        public/* Roboto */ TextView serviceName;
        public/* Roboto */ TextView agentName;
        public/* Roboto */ TextView amount;
        public/* Material */ TextView actionIcon;
        public LinearLayout layout;
    }

    private static class HeaderViewHolder {
        public/* Roboto */ TextView day;
        public/* Roboto */ TextView date;
    }

    @Override
    public View getHeaderView(final int position, final View convertView,
                              final ViewGroup parent) {
        View view = convertView;
        final HeaderViewHolder holder;
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(
                    R.layout.list_header_client_request, parent, false);
            holder = new HeaderViewHolder();
            holder.day = (TextView) view
                    .findViewById(R.id.list_header_social_day);
            holder.date = (TextView) view
                    .findViewById(R.id.list_header_social_date);
            view.setTag(holder);
        } else {
            holder = (HeaderViewHolder) view.getTag();
        }

        ClientRequestViewModel model = getModelList().get(position);
        holder.day.setText("Request");
        holder.date.setText(model.getDate());
        // holder.name.setService("Header " + getHeaderId(position));

        return view;
    }

    @Override
    public long getHeaderId(final int position) {
        ClientRequestViewModel model = getModelList().get(position);
        if (!headers.containsKey(model.getDate())) {
            headers.put(model.getDate(), (long) position);
        }
        return headers.get(model.getDate());
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        int position = (Integer) v.getTag();
        final ClientRequestViewModel model = mModelList.get(position);
        switch (v.getId()) {
            case R.id.list_item_sticky_header_media_icon_cancel:
                if (model.status == 3) {
                    final RatingDialog diag = new RatingDialog(mContext, model);
                    diag.setOnOkListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            RatingModel rating = new RatingModel();
                            rating.rating = diag.getRating();
                            rating.comment = diag.getComment();
                            rating.agentId = diag.getModel().agentId;
                            Spinner.show(mContext);
                            new PostRating().setDialog(diag).execute(rating);
                        }
                    });
                    diag.show();
                } else {
                    DialogUtils.showConfirm(mContext, mContext.getString(R.string.prompt_cancel_request), new DialogUtils.DialogListener() {
                        @Override
                        public void onOkClick(Context context, Dialog dialog, View view) {
                            dialog.dismiss();
                            Spinner.show(mContext);
                            new CancelRequest().execute(model.id);
                        }

                        @Override
                        public void onCancelClick(Context context, Dialog dialog, View view) {

                        }
                    });
                }
                break;

        }
    }

    public ArrayList<ClientRequestViewModel> getModelList() {
        return mModelList;
    }

    /**
     * Async Task to make http call
     */
    private class GetRequest extends AsyncTask<Long, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Long... arg0) {
            long id = arg0[0];
            return Api.getRequest((int) id);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null) {
                if (result.optInt("status", 0) == 1) {
                    JSONObject request = result.optJSONObject("request");
                    ServiceRequestModel model = new ServiceRequestModel();
                    JSONObject jAgent = request.optJSONObject("agent");
                    model.id = request.optInt("id");
                    model.amount = request.optString("amount");
                    model.providerName = request.optString("provider");
                    model.serviceName = request.optString("service");
                    model.time = request.optString("time");
                    if (jAgent != null) {
                        AgentModel agent = new AgentModel();
                        agent.id = jAgent.optInt("id");
                        agent.latitude = jAgent.optDouble("latitude");
                        agent.longitude = jAgent.optDouble("longitude");
                        agent.name = jAgent.optString("name");
                        agent.phone = jAgent.optString("phone");
                        agent.image = jAgent.optString("image");
                        agent.rating = jAgent.optDouble("rating");
                        agent.tillNo = jAgent.optString("till");
                        model.agent = agent;
                    }
                    Spinner.hide();
                    Intent intent = new Intent(mContext, RequestDetailActivity.class);
                    intent.putExtra("request", model);
                    mContext.startActivity(intent);
                } else if (result.optInt("code") == 201) {
                    Spinner.hide();
                    DialogUtils.showError(mContext, mContext.getString(R.string.request_already_accepted));
                }

            } else {
                Spinner.hide();
                DialogUtils.showError(mContext, "Failed to get request.");
            }
        }

    }

    /**
     * Async Task to make http call
     */
    private class CancelRequest extends AsyncTask<Long, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Long... arg0) {
            long id = arg0[0];
            return Api.cancelRequest((int) id);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null) {
                if (result.optInt("status", 0) == 1) {
                } else if (result.optInt("code") == 201) {
                    DialogUtils.showError(mContext, mContext.getString(R.string.request_already_accepted));
                }

            } else {
                DialogUtils.showError(mContext, "Failed to get request.");
            }
        }

    }

    /**
     * Async Task to make http call
     */
    private class PostRating extends AsyncTask<RatingModel, JSONObject, JSONObject> {

        private RatingDialog mDialog;

        public PostRating setDialog(RatingDialog dialog) {
            this.mDialog = dialog;
            return this;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(RatingModel... arg0) {
            RatingModel model = arg0[0];
            return Api.rateAgent(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null) {
                if (result.optInt("status", 0) == 1) {
                    DialogUtils.showSuccess(mContext, "Rating successfully updated.", new DialogUtils.DialogListener() {
                        @Override
                        public void onOkClick(Context context, Dialog dialog, View view) {
                            dialog.dismiss();
                            mDialog.dismiss();
                        }

                        @Override
                        public void onCancelClick(Context context, Dialog dialog, View view) {
                            dialog.dismiss();
                        }
                    });
                } else {
                    DialogUtils.showError(mContext, "Failed to update ratings.");
                }
            } else {
                DialogUtils.showError(mContext, "Failed to update ratings.");
            }
        }

    }

}