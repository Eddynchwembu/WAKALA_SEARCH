package com.coreit.wakalaapp.component;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.agent.Api;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import org.json.JSONObject;

/**
 * Created by Ramadan on 3/31/2018.
 */

public class FirebaseTokenService extends FirebaseInstanceIdService {

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String token = FirebaseInstanceId.getInstance().getToken();
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        String accessToken = pref.getString(App.PREF_TOKEN, null);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("fcm-token", token);
        if (accessToken != null) {
            String userType = pref.getString(App.PREF_USER_TYPE, null);
            if (userType != null) {
                JSONObject response;
                if (userType.equals("agent")) {
                    response = Api.updateFcmToken(token);
                } else {
                    response = com.coreit.wakalaapp.client.Api.updateFcmToken(token);
                }
                if (response != null && response.optInt("status", 0) == 1) {
                    editor.putBoolean("fcm-token-update", false);
                } else {
                    editor.putBoolean("fcm-token-update", false);
                }
            }

        } else {
            editor.putBoolean("fcm-token-update", true);
        }
        editor.apply();
    }
}
