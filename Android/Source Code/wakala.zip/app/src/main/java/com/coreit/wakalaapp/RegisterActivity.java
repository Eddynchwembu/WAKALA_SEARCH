package com.coreit.wakalaapp;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.AgentRegisterModel;
import com.coreit.wakalaapp.model.ClientRegisterModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.GPSTracker;
import com.coreit.wakalaapp.utils.Spinner;

import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {

    private TextView mTabClientAgentButton;
    private TextView mTabClientClientButton;
    private TextView mTabClientLoginButton;
    private TextView mTabClientSubmitButton;
    private TextView mTabClientFirstName;
    private TextView mTabClientLastName;
    private TextView mTabClientPhone;
    private TextView mTabClientPassword;
    private TextView mTabClientPasswordConfirm;

    private TextView mTabAgentClientButton;
    private TextView mTabAgentAgentButton;
    private TextView mTabAgentLoginButton;
    private TextView mTabAgentSubmitButton;
    private TextView mTabAgentFirstName;
    private TextView mTabAgentLastName;
    private TextView mTabAgentPhone;
    private TextView mTabAgentPassword;
    private TextView mTabAgentTin;
    private TextView mTabAgentBusiness;
    private TextView mTabAgentEmail;
    private TextView mTabAgentPasswordConfirm;

    private TextView mTosView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE); //Removing ActionBar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        showClientTab();
    }

    public void showClientTab() {
        setContentView(R.layout.activity_client_register);
        mTabClientAgentButton = (TextView) findViewById(R.id.client_register_agent);
        mTabClientClientButton = (TextView) findViewById(R.id.client_register_client);
        mTabClientLoginButton = (TextView) findViewById(R.id.client_register_login);
        mTabClientSubmitButton = (TextView) findViewById(R.id.client_register_submit);
        mTabClientFirstName = (EditText) findViewById(R.id.client_register_first_name);
        mTabClientLastName = (EditText) findViewById(R.id.client_register_last_name);
        mTabClientPassword = (EditText) findViewById(R.id.client_register_password);
        mTabClientPhone = (EditText) findViewById(R.id.client_register_mobile);
        mTabClientPasswordConfirm = (EditText) findViewById(R.id.client_register_password_confirm);
        mTosView = findViewById(R.id.client_register_tos);
        mTosView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, ToSActivity.class);
                startActivity(intent);
            }
        });
        Typeface sRobotoThin = Typeface.createFromAsset(this.getAssets(),
                "fonts/Roboto-Light.ttf");

        initClientButtons();
    }

    private void initClientButtons() {
        mTabClientAgentButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                showAgentTab();
            }
        });

        mTabClientLoginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(i);
                // close this activity
                finish();
            }
        });

        mTabClientSubmitButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                ClientRegisterModel model = new ClientRegisterModel(
                        mTabClientFirstName.getText().toString(),
                        mTabClientLastName.getText().toString(),
                        mTabClientPhone.getText().toString(),
                        mTabClientPassword.getText().toString(),
                        mTabClientPasswordConfirm.getText().toString()
                );
                if (model.firstName.isEmpty() ||
                        model.lastName.isEmpty() ||
                        model.phone.isEmpty() ||
                        model.password.isEmpty() ||
                        model.confirmPassword.isEmpty()) {
                    DialogUtils.showError(RegisterActivity.this, getResources().getString(R.string.register_form_general_error));
                } else if (!model.password.equals(model.confirmPassword)) {
                    DialogUtils.showError(RegisterActivity.this, getResources().getString(R.string.register_password_mismatch_error));
                } else {
                    Spinner.show(RegisterActivity.this);
                    new RegisterClient().execute(model);
                }
            }
        });
    }

    public void showAgentTab() {
        setContentView(R.layout.activity_agent_register);
        mTabAgentAgentButton = (TextView) findViewById(R.id.agent_register_agent);
        mTabAgentClientButton = (TextView) findViewById(R.id.agent_register_client);
        mTabAgentLoginButton = (TextView) findViewById(R.id.agent_register_login);
        mTabAgentSubmitButton = (TextView) findViewById(R.id.agent_register_submit);
        mTabAgentFirstName = (EditText) findViewById(R.id.agent_register_first_name);
        mTabAgentLastName = (EditText) findViewById(R.id.agent_register_last_name);
        mTabAgentPassword = (EditText) findViewById(R.id.agent_register_password);
        mTabAgentTin = (EditText) findViewById(R.id.agent_register_business_tin);
        mTabAgentEmail = (EditText) findViewById(R.id.agent_register_email);
        mTabAgentBusiness = (EditText) findViewById(R.id.agent_register_business_name);
        mTabAgentPhone = (EditText) findViewById(R.id.agent_register_mobile_no);
        mTabAgentPasswordConfirm = (EditText) findViewById(R.id.agent_register_password_confirm);
        mTosView = findViewById(R.id.client_register_tos);
        mTosView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, ToSActivity.class);
                startActivity(intent);
            }
        });
        Typeface sRobotoThin = Typeface.createFromAsset(this.getAssets(),
                "fonts/Roboto-Light.ttf");

        initAgentButtons();
    }

    private void initAgentButtons() {

        mTabAgentClientButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                showClientTab();
            }
        });
        mTabAgentLoginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(i);
                // close this activity
                finish();
            }
        });

        mTabAgentSubmitButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                AgentRegisterModel model = new AgentRegisterModel(
                        mTabAgentFirstName.getText().toString(),
                        mTabAgentLastName.getText().toString(),
                        mTabAgentBusiness.getText().toString(),
                        mTabAgentTin.getText().toString(),
                        mTabAgentPhone.getText().toString(),
                        mTabAgentEmail.getText().toString(),
                        mTabAgentPassword.getText().toString(),
                        mTabAgentPasswordConfirm.getText().toString()
                );
                GPSTracker tracker = new GPSTracker(RegisterActivity.this);
                if (tracker.canGetLocation()) {
                    model.longitude = String.valueOf(tracker.getLongitude());
                    model.latitude = String.valueOf(tracker.getLatitude());
                    if (model.validate()) {
                        DialogUtils.showError(RegisterActivity.this, "Please fill all required fields.");
                    } else if (!model.password.equals(model.confirmPassword)) {
                        DialogUtils.showError(RegisterActivity.this, getResources().getString(R.string.register_password_mismatch_error));
                    } else {
                        Spinner.show(RegisterActivity.this);
                        new RegisterAgent().execute(model);
                    }
                } else {
                    DialogUtils.showError(RegisterActivity.this, "Please enable Location services to continue.");
                }

            }
        });
    }


    /**
     * Async Task to make http call
     */
    private class RegisterClient extends AsyncTask<ClientRegisterModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(ClientRegisterModel... arg0) {
            ClientRegisterModel model = arg0[0];
            return Api.register(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                Spinner.hide();
                String message = result.optString("message", getResources().getString(R.string.register_successfully));
                DialogUtils.showSuccess(RegisterActivity.this, message, new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(i);
                        finish();

                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {

                    }
                });
            } else {
                if (result != null) {
                    Spinner.hide();
                    String message = result.optString("message", getResources().getString(R.string.register_failed_error));
                    DialogUtils.showError(RegisterActivity.this, message);
                } else {
                    Spinner.hide();
                    DialogUtils.showError(RegisterActivity.this, getResources().getString(R.string.register_failed_error));
                }
            }
        }
    }


    /**
     * Async Task to make http call
     */
    private class RegisterAgent extends AsyncTask<AgentRegisterModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(AgentRegisterModel... arg0) {
            AgentRegisterModel model = arg0[0];
            return com.coreit.wakalaapp.agent.Api.register(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                Spinner.hide();
                String message = result.optString("message", getResources().getString(R.string.register_agent_successfully));
                DialogUtils.showSuccess(RegisterActivity.this, message, new DialogUtils.DialogListener() {
                    @Override
                    public void onOkClick(Context context, Dialog dialog, View view) {
                        Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(i);
                        finish();

                    }

                    @Override
                    public void onCancelClick(Context context, Dialog dialog, View view) {

                    }
                });
            } else {
                if (result != null) {
                    Spinner.hide();
                    String message = result.optString("message", getResources().getString(R.string.register_failed_error));
                    DialogUtils.showError(RegisterActivity.this, message);
                } else {
                    Spinner.hide();
                    DialogUtils.showError(RegisterActivity.this, getResources().getString(R.string.register_failed_error));
                }
            }
        }
    }
}
