package com.coreit.wakalaapp.widgets;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.coreit.wakalaapp.R;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class ResetPasswordDialog extends Dialog {

    private TextView mDialogOKButton;
    private TextView mDialogCancelButton;
    private TextView mHaveCode;
    private TextView mResendCode;
    private EditText mPhone;
    private EditText mCode;
    private EditText mPassword;
    private EditText mConfirmPassword;
    private int mode = 0;
    private String errors;

    public ResetPasswordDialog(Context context) {
        this(context, 0);
    }

    public ResetPasswordDialog(Context context, int mode) {
        super(context, R.style.CustomDialogTheme);
        this.mode = mode;
        if (mode == 0) {
            setContentView(R.layout.dialog_forgot_pwd_phone);
            mHaveCode = (TextView) findViewById(R.id.tv_have_code);
        } else {
            setContentView(R.layout.dialog_forgot_pwd_code);
            mCode = (EditText) findViewById(R.id.et_forgot_pwd_code);
            mPassword = (EditText) findViewById(R.id.et_forgot_pwd_password);
            mConfirmPassword = (EditText) findViewById(R.id.et_forgot_pwd_confirm);

            mResendCode = (TextView) findViewById(R.id.tv_resend_code);
            mResendCode.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
        setCancelable(true);

        mDialogOKButton = (TextView) findViewById(R.id.dialog_ok);
        mDialogCancelButton = (TextView) findViewById(R.id.dialog_cancel);
        mPhone = (EditText) findViewById(R.id.et_forgot_pwd_phone);

        setOnCancelListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }


    public void setOnOkListener(View.OnClickListener listener) {
        mDialogOKButton.setOnClickListener(listener);
    }

    public void setOnCancelListener(View.OnClickListener listener) {
        mDialogCancelButton.setOnClickListener(listener);
    }

    public void setOnHaveCodeListener(View.OnClickListener listener) {
        if (mHaveCode != null) {
            mHaveCode.setOnClickListener(listener);
        }
    }

    public String getPhone() {
        if (mPhone != null) {
            return mPhone.getText().toString();
        }
        return null;
    }

    public String getCode() {
        if (mCode != null) {
            return mCode.getText().toString();
        }
        return null;
    }

    public String getPassword() {
        if (mPassword != null) {
            return mPassword.getText().toString();
        }
        return null;
    }

    public String getConfirmPassword() {
        if (mConfirmPassword != null) {
            return mConfirmPassword.getText().toString();
        }
        return null;
    }

    public boolean validate() {
        errors = "";
        switch (mode) {
            case 0:
                if (getPhone().isEmpty()) {
                    errors = errors.concat("Phone is required.\n");
                }
                break;
            case 1:
                if (getPhone().isEmpty()) {
                    errors = errors.concat("Phone is required.\n");
                }
                if (getCode().isEmpty()) {
                    errors = errors.concat("Code is required.\n");
                }
                if (getPassword().isEmpty()) {
                    errors = errors.concat("Password is required.\n");
                }
                if (getConfirmPassword().isEmpty()) {
                    errors = errors.concat("Confirm password is required.\n");
                }
                if (!getPassword().equals(getConfirmPassword())) {
                    errors = errors.concat("Passwords must match.\n");
                }
                break;
        }
        return errors.isEmpty();
    }

    public String getErrors() {
        return errors;
    }
}
