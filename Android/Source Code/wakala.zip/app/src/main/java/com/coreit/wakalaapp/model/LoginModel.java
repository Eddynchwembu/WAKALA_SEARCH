package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 3/26/2018.
 */

public class LoginModel {
    public String username;
    public String password;


    public LoginModel() {

    }

    public LoginModel(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
