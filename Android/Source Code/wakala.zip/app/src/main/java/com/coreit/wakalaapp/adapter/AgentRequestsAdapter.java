package com.coreit.wakalaapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.AgentRequestModel;
import com.coreit.wakalaapp.model.AgentRequestViewModel;
import com.coreit.wakalaapp.model.RequestModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.ImageUtil;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.view.agent.RequestActivity;
import com.nhaarman.listviewanimations.ArrayAdapter;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import se.emilsjolander.stickylistheaders.StickyListHeadersAdapter;

public class AgentRequestsAdapter extends ArrayAdapter<String>
        implements StickyListHeadersAdapter, OnClickListener {

    private final Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<AgentRequestViewModel> mModelList;
    private Map<String, Long> headers;

    public AgentRequestsAdapter(final Context context, ArrayList<AgentRequestViewModel> modelList) {
        mContext = context;
        mModelList = modelList;
        mInflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        headers = new HashMap<>();
    }

    @Override
    public long getItemId(final int position) {
        return getItem(position).hashCode();
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.list_item_sticky_header_client_request, parent, false);
            holder = new ViewHolder();
            holder.layout = convertView.findViewById(R.id.layout_client_request);
            holder.layout.setTag(position);
            holder.image = (ImageView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_image);
            holder.serviceName = (TextView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_album_name);
            holder.agentName = (TextView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_artist_name);
            holder.amount = (TextView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_time);
            holder.iconCancel = (TextView) convertView
                    .findViewById(R.id.list_item_sticky_header_media_icon_cancel);
            holder.iconCancel.setVisibility(View.INVISIBLE);
            //holder.iconCancel.setOnClickListener(this);
            holder.layout.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = (int) view.getTag();
                    AgentRequestViewModel model = mModelList.get(position);
                    new GetRequest().execute(model.getId());
                }
            });
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        AgentRequestViewModel model = getModelList().get(position);
        // TODO Change image URL
        ImageUtil.displayImage(holder.image, model.getImageURL(), null);
        holder.serviceName.setText(model.getService());
        holder.agentName.setText(model.getAgent());
        holder.amount.setText(model.getAmount());
        holder.iconCancel.setTag(position);

        return convertView;
    }


    private static class ViewHolder {
        public ImageView image;
        public/* Roboto */ TextView serviceName;
        public/* Roboto */ TextView agentName;
        public TextView amount;
        public TextView iconCancel;
        public LinearLayout layout;
    }

    private static class HeaderViewHolder {
        public/* Roboto */ TextView day;
        public/* Roboto */ TextView date;
    }

    @Override
    public View getHeaderView(final int position, final View convertView,
                              final ViewGroup parent) {
        View view = convertView;
        final HeaderViewHolder holder;
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(
                    R.layout.list_header_client_request, parent, false);
            holder = new HeaderViewHolder();
            holder.day = (TextView) view
                    .findViewById(R.id.list_header_social_day);
            holder.date = (TextView) view
                    .findViewById(R.id.list_header_social_date);
            view.setTag(holder);
        } else {
            holder = (HeaderViewHolder) view.getTag();
        }

        AgentRequestViewModel model = getModelList().get(position);
        holder.day.setText("Request");
        holder.date.setText(model.getDate());
        // holder.name.setService("Header " + getHeaderId(position));

        return view;
    }

    @Override
    public long getHeaderId(final int position) {
        AgentRequestViewModel model = getModelList().get(position);
        if (!headers.containsKey(model.getDate())) {
            headers.put(model.getDate(), (long) position);
        }
        return headers.get(model.getDate());
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        int position = (Integer) v.getTag();
        final AgentRequestViewModel model = mModelList.get(position);
        switch (v.getId()) {
            case R.id.list_item_sticky_header_media_icon_cancel:
                Spinner.show(mContext);
                new CancelRequest().execute(model.getId());
                break;
        }
    }

    public ArrayList<AgentRequestViewModel> getModelList() {
        return mModelList;
    }

    /**
     * Async Task to make http call
     */
    private class GetRequest extends AsyncTask<Long, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Long... arg0) {
            long id = arg0[0];
            return Api.getRequest((int) id);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null) {
                if (result.optInt("status", 0) == 1) {
                    JSONObject request = result.optJSONObject("request");
                    RequestModel model = new RequestModel();
                    model.id = request.optInt("id");
                    model.account = request.optString("account");
                    model.client = request.optString("client");
                    model.amount = request.optString("amount");
                    model.provider = request.optString("provider");
                    model.service = request.optString("service");
                    model.image = request.optString("image");
                    model.clientName = request.optString("name");
                    model.time = request.optString("time");
                    Intent intent = new Intent(mContext, RequestActivity.class);
                    intent.putExtra("request", model);
                    mContext.startActivity(intent);
                } else if (result.optInt("code") == 201) {
                    DialogUtils.showError(mContext, "Sorry this request is already accepted.");
                }

            } else {
                DialogUtils.showError(mContext, "Failed to get request.");
            }
        }

    }

    /**
     * Async Task to make http call
     */
    private class CancelRequest extends AsyncTask<Long, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Long... arg0) {
            long id = arg0[0];
            return Api.cancelRequest((int) id);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null) {
                if (result.optInt("status", 0) == 1) {
                } else if (result.optInt("code") == 201) {
                    DialogUtils.showError(mContext, mContext.getString(R.string.request_already_accepted));
                }

            } else {
                DialogUtils.showError(mContext, "Failed to get request.");
            }
        }

    }

}