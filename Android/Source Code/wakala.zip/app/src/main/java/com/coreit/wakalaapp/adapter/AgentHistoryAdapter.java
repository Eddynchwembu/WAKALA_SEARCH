package com.coreit.wakalaapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.AgentRequestViewModel;
import com.coreit.wakalaapp.model.RequestModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.view.agent.RequestActivity;
import com.nhaarman.listviewanimations.ArrayAdapter;

import org.json.JSONObject;

import java.util.ArrayList;

import se.emilsjolander.stickylistheaders.StickyListHeadersAdapter;

public class AgentHistoryAdapter extends ArrayAdapter<String>
        implements StickyListHeadersAdapter, OnClickListener {

    private final Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<AgentRequestViewModel> mModelList;

    public AgentHistoryAdapter(final Context context, ArrayList<AgentRequestViewModel> modelList) {
        mContext = context;
        mModelList = modelList;
        mInflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public long getItemId(final int position) {
        return getItem(position).hashCode();
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.list_item_agent_history, parent, false);
            holder = new ViewHolder();
            holder.layout = convertView.findViewById(R.id.list_history_item_layout);
            holder.serviceName = (TextView) convertView
                    .findViewById(R.id.list_history_item_service);
            holder.agentName = (TextView) convertView
                    .findViewById(R.id.list_history_item_client);
            holder.amount = (TextView) convertView
                    .findViewById(R.id.list_history_item_amount);
            holder.dateTime = (TextView) convertView
                    .findViewById(R.id.list_history_item_time);
//            holder.layout.setOnClickListener(new OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    int position = (int) view.getTag();
//                    AgentRequestViewModel model = mModelList.get(position);
//                    new GetRequest().execute(model.getId());
//                }
//            });
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        AgentRequestViewModel model = getModelList().get(position);
        holder.serviceName.setText(model.getService());
        holder.agentName.setText(model.getAgent());
        holder.amount.setText(model.getAmount());
        holder.dateTime.setText(model.getDate());
        holder.layout.setTag(position);
        return convertView;
    }


    private static class ViewHolder {
        public ImageView image;
        public TextView serviceName;
        public TextView agentName;
        public TextView amount;
        public TextView dateTime;
        public LinearLayout layout;
    }

    private static class HeaderViewHolder {
        public/* Roboto */ TextView day;
        public/* Roboto */ TextView date;
    }

    @Override
    public View getHeaderView(final int position, final View convertView,
                              final ViewGroup parent) {
        View view = convertView;
        final HeaderViewHolder holder;
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(
                    R.layout.list_header_agent_history, parent, false);
            holder = new HeaderViewHolder();
            holder.day = (TextView) view
                    .findViewById(R.id.list_header_name);
            holder.date = (TextView) view
                    .findViewById(R.id.list_header_service);
            view.setTag(holder);
        }
        return view;
    }

    @Override
    public long getHeaderId(final int position) {
        return 0;
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        int position = (Integer) v.getTag();
        switch (v.getId()) {
            case R.id.list_item_sticky_header_media_icon_cancel:
                Toast.makeText(mContext, "Play song: " + position,
                        Toast.LENGTH_SHORT).show();
                break;
        }
    }

    public ArrayList<AgentRequestViewModel> getModelList() {
        return mModelList;
    }

    /**
     * Async Task to make http call
     */
    private class GetRequest extends AsyncTask<Long, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Long... arg0) {
            long id = arg0[0];
            return Api.getRequest((int) id);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null ) {
                if(result.optInt("status", 0) == 1){
                    JSONObject request = result.optJSONObject("request");
                    RequestModel model = new RequestModel();
                    model.id = request.optInt("id");
                    model.account = request.optString("account");
                    model.client = request.optString("client");
                    model.amount = request.optString("amount");
                    model.provider = request.optString("provider");
                    model.service =request.optString("service");
                    model.image = request.optString("image");
                    model.clientName = request.optString("name");
                    model.time = request.optString("time");
                    Intent intent = new Intent(mContext, RequestActivity.class);
                    intent.putExtra("request", model);
                    mContext.startActivity(intent);
                }else if(result.optInt("code") == 201){
                    DialogUtils.showError(mContext, "Sorry this request is already accepted.");
                }

            } else {
                DialogUtils.showError(mContext, "Failed to get request.");
            }
        }

    }

}