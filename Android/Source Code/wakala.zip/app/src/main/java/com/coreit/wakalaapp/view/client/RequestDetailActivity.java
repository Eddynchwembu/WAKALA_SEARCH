package com.coreit.wakalaapp.view.client;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.AgentModel;
import com.coreit.wakalaapp.model.ServiceRequestModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.GMapV2Direction;
import com.coreit.wakalaapp.utils.GMapV2DirectionAsync;
import com.coreit.wakalaapp.utils.GPSTracker;
import com.coreit.wakalaapp.utils.Spinner;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONObject;
import org.w3c.dom.Document;

import java.util.ArrayList;

public class RequestDetailActivity extends AppCompatActivity implements OnMapReadyCallback, LocationListener {

    TextView tvAgent;
    TextView tvDistance;
    TextView tvProvider;
    TextView tvService;
    TextView tvFollow;
    TextView tvPause;
    ServiceRequestModel model;
    GoogleMap mMap;
    private GPSTracker gps;
    private Polyline path;
    Marker marker;
    Marker agentMarker;
    LatLng agentPosition;
    SharedPreferences pref;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_request_detail);
        tvAgent = (TextView) findViewById(R.id.tv_client_request_detail_agent);
        tvDistance = (TextView) findViewById(R.id.tv_client_request_detail_distance);
        tvProvider = (TextView) findViewById(R.id.tv_client_request_detail_provider);
        tvService = (TextView) findViewById(R.id.tv_client_request_detail_service);
        tvFollow = (TextView) findViewById(R.id.tv_client_request_detail_follow);
        tvPause = (TextView) findViewById(R.id.tv_client_request_detail_close);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        model = getIntent().getExtras().getParcelable("request");
        pref = PreferenceManager.getDefaultSharedPreferences(RequestDetailActivity.this);


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null) {
            if (locationManager.getAllProviders().contains(LocationManager.NETWORK_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
            if (locationManager.getAllProviders().contains(LocationManager.GPS_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, this);
        }


        if (model != null) {
            setViews();
        } else {
            long id = Long.valueOf(getIntent().getStringExtra("id"));
            Spinner.show(this);
            new GetRequest().execute(id);
        }


        final AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int i) {
                mAdView.setVisibility(View.GONE);
            }
        });
        mAdView.loadAd(adRequest);
    }

    void setViews() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (model.agent != null) {
                    tvAgent.setText(model.agent.name);
                }
                tvProvider.setText(model.providerName);
                tvService.setText(model.serviceName);
                tvAgent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(RequestDetailActivity.this, AgentActivity.class);
                        intent.putExtra("agent", model.agent);
                        startActivity(intent);
                    }
                });

                tvFollow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (model.agent == null) {
                            DialogUtils.showError(RequestDetailActivity.this, getString(R.string.request_not_accepted));
                        } else {
                            if (gps == null) {
                                gps = new GPSTracker(RequestDetailActivity.this);
                            }
                            if (gps.canGetLocation()) {
                                double latitude = gps.getLatitude(); // returns latitude
                                double longitude = gps.getLongitude(); // returns longitude
                                float[] results = new float[1];
                                Location.distanceBetween(latitude, longitude,
                                        model.agent.latitude, model.agent.longitude, results);
                                float distance = results[0];
                                String unit;
                                if (distance > 1000) {
                                    distance = distance / 1000;
                                    unit = "km";
                                } else {
                                    unit = "m";
                                }
                                tvDistance.setText(String.format("%.2f ", distance).concat(unit));
                                LatLng location = new LatLng(latitude, longitude);
                                agentPosition = new LatLng(model.agent.latitude, model.agent.longitude);
                                if (marker == null) {
                                    marker = mMap.addMarker(new MarkerOptions().position(location).title(getString(R.string.your_position)).icon(BitmapDescriptorFactory.fromResource(R.drawable.client_marker)));
                                } else {
                                    marker.setPosition(location);
                                }
                                if (agentMarker == null) {
                                    agentMarker = mMap.addMarker(new MarkerOptions().position(agentPosition).title(model.agent.name)
                                            .snippet("Distance: " + distance + " km" + "\n" + "Till No: " + model.agent.tillNo + "\n" + "Rating: " + model.agent.rating)
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.agent_marker)));
                                } else {
                                    agentMarker.setPosition(agentPosition);
                                }
                                CameraUpdate update = CameraUpdateFactory.newLatLngZoom(location, 15);
                                Spinner.show(RequestDetailActivity.this);
                                mMap.animateCamera(update);

                                String mode = pref.getString(App.PREF_TRAVEL_MODE, "walking");
                                route(location, agentPosition, mode);
                            } else {
                                DialogUtils.showError(RequestDetailActivity.this, "Please turn on location service.", new DialogUtils.DialogListener() {
                                    @Override
                                    public void onOkClick(Context context, Dialog dialog, View view) {
                                        dialog.dismiss();
                                        finish();
                                    }

                                    @Override
                                    public void onCancelClick(Context context, Dialog dialog, View view) {

                                    }
                                });
                            }
                        }
                    }
                });

                tvPause.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DialogUtils.showConfirm(RequestDetailActivity.this, getString(R.string.pause_request_prompt), new DialogUtils.DialogListener() {
                            @Override
                            public void onOkClick(Context context, Dialog dialog, View view) {
                                if (locationManager != null) {
                                    locationManager.removeUpdates(RequestDetailActivity.this);
                                }
                                DialogUtils.showSuccess(RequestDetailActivity.this, getString(R.string.request_paused));
                            }

                            @Override
                            public void onCancelClick(Context context, Dialog dialog, View view) {

                            }
                        });
                    }
                });
            }
        });

    }

    protected void route(final LatLng sourcePosition, LatLng destPosition, String mode) {
        final Handler handler = new Handler() {
            public void handleMessage(Message msg) {
                try {
                    Document doc = (Document) msg.obj;
                    GMapV2Direction md = new GMapV2Direction();
                    ArrayList<LatLng> directionPoint = md.getDirection(doc);
                    PolylineOptions rectLine = new PolylineOptions().width(15).color(getResources().getColor(R.color.colorPrimary));

                    for (int i = 0; i < directionPoint.size(); i++) {
                        rectLine.add(directionPoint.get(i));
                    }
                    if (path != null) {
                        path.remove();
                    }
                    float[] results = new float[1];
                    path = mMap.addPolyline(rectLine);
                    Location.distanceBetween(sourcePosition.latitude, sourcePosition.longitude,
                            model.agent.latitude, model.agent.longitude, results);
                    float distance = results[0];
                    String unit;
                    if (distance > 1000) {
                        distance = distance / 1000;
                        unit = "km";
                    } else {
                        unit = "m";
                    }
                    tvDistance.setText(String.format("%.2f ", distance).concat(unit));
                    String eta = md.getDurationText(doc);
                    marker.setSnippet("ETA:".concat(eta));
                    Spinner.hide();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        };

        new GMapV2DirectionAsync(handler, sourcePosition, destPosition, mode).execute();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

            @Override
            public View getInfoWindow(Marker arg0) {
                return null;
            }

            @Override
            public View getInfoContents(Marker marker) {

                LinearLayout info = new LinearLayout(RequestDetailActivity.this);
                info.setOrientation(LinearLayout.VERTICAL);

                TextView title = new TextView(RequestDetailActivity.this);
                title.setTextColor(Color.BLACK);
                title.setGravity(Gravity.CENTER);
                title.setTypeface(null, Typeface.BOLD);
                title.setText(marker.getTitle());

                TextView snippet = new TextView(RequestDetailActivity.this);
                snippet.setTextColor(Color.GRAY);
                snippet.setText(marker.getSnippet());

                info.addView(title);
                info.addView(snippet);

                return info;
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d("Wakala", "new location");
        if (marker != null) {
            if (location.hasAccuracy() && location.getAccuracy() <= 30) {
                LatLng lang = new LatLng(location.getLatitude(), location.getLongitude());
                marker.setPosition(lang);
                String mode = pref.getString(App.PREF_TRAVEL_MODE, "walking");
                route(lang, agentPosition, mode);
                new UpdatePosition().execute(lang);
            }
        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {
        Log.d("Wakala", "new location");

    }

    @Override
    public void onProviderEnabled(String s) {
        Log.d("Wakala", "new location");

    }

    @Override
    public void onProviderDisabled(String s) {
        Log.d("Wakala", "new location");

    }

    /**
     * Async Task to make http call
     */
    private class UpdatePosition extends AsyncTask<LatLng, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(LatLng... arg0) {
            LatLng model = arg0[0];
            return Api.updatePosition(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
        }

    }

    /**
     * Async Task to make http call
     */
    private class GetRequest extends AsyncTask<Long, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Long... arg0) {
            long id = arg0[0];
            return Api.getRequest((int) id);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null) {
                if (result.optInt("status", 0) == 1) {
                    JSONObject request = result.optJSONObject("request");
                    ServiceRequestModel model = new ServiceRequestModel();
                    JSONObject jAgent = request.optJSONObject("agent");
                    model.id = request.optInt("id");
                    model.amount = request.optString("amount");
                    model.providerName = request.optString("provider");
                    model.serviceName = request.optString("service");
                    model.time = request.optString("time");
                    if (jAgent != null) {
                        AgentModel agent = new AgentModel();
                        agent.id = jAgent.optInt("id");
                        agent.latitude = jAgent.optDouble("latitude");
                        agent.longitude = jAgent.optDouble("longitude");
                        agent.name = jAgent.optString("name");
                        agent.phone = jAgent.optString("phone");
                        agent.image = jAgent.optString("image");
                        agent.rating = jAgent.optDouble("rating");
                        agent.tillNo = jAgent.optString("till");
                        model.agent = agent;
                    }
                    RequestDetailActivity.this.model = model;
                    setViews();
                    Spinner.hide();
                } else if (result.optInt("code") == 201) {
                    Spinner.hide();
                    DialogUtils.showError(RequestDetailActivity.this, getString(R.string.request_already_accepted));
                }

            } else {
                Spinner.hide();
                DialogUtils.showError(RequestDetailActivity.this, "Failed to get request.");
            }
        }

    }


}
