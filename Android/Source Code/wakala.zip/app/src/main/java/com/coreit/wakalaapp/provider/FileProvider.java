package com.coreit.wakalaapp.provider;

/**
 * Created by Ramadan on 4/6/2018.
 */

public class FileProvider extends android.support.v4.content.FileProvider {
}
