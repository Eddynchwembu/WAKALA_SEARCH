package com.coreit.wakalaapp;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

/**
 * Created by Ramadan on 3/21/2018.
 */

public class App extends Application {

    public static String PREF_USERNAME = "user-name";
    public static String PREF_BUSINESS_NAME = "user-business";
    public static String PREF_USER_LATITUDE = "user-latitude";
    public static String PREF_USER_LONGITUDE = "user-longitude";
    public static String PREF_USER_IMAGE = "user-image";
    public static String PREF_USER_GENDER = "user-gender";
    public static String PREF_EMAIL = "user-email";
    public static String PREF_MOBILE = "user-mobile";
    public static String PREF_TOKEN = "access-token";
    public static String PREF_USER_TYPE = "user-type";
    public static String PREF_RADIUS = "search_radius";
    public static String PREF_LANGUAGE = "app_language";
    public static String PREF_FCM_UPDATE = "fcm-token-update";
    public static String PREF_FCM_TOKEN = "fcm-token";
    public static String PREF_TRAVEL_MODE = "app_travel_mode";
    public static String PREF_SERVICE_STATUS = "app_service_status";
    public static String PREF_FIRST_RUN = "app-first_run";

    @SuppressLint("StaticFieldLeak")
    private static Context context;
    private static String accessToken;
    private static String userType;
    private static String[] hosts = {
            "http://wakalapi.onetouchhub.com",};
    private static String apiBase = hosts[0];

    public static void setAccessToken(String accessToken) {
        App.accessToken = accessToken;
    }

    public static void setUserType(String userType) {
        App.userType = userType;
    }

    public static String getAccessToken() {
        return accessToken;
    }

    public static String getApiBase() {
        return apiBase;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        if(isGooglePlayServicesAvailable()){
            MobileAds.initialize(this, "ca-app-pub-3940256099942544~3347511713");
        }
    }

    public static boolean isGooglePlayServicesAvailable() {
        GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = googleApiAvailability.isGooglePlayServicesAvailable(context);
        return resultCode == ConnectionResult.SUCCESS;
    }

    /**
     * Sets application context
     *
     * @param context Application Context
     */
    public static void setContext(Context context) {
        App.context = context;
    }

    /**
     * Gets Application context
     *
     * @return Application context if it is already set
     */
    public static Context getContext() {
        return context;
    }

    public static boolean isFirstRun() {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getContext());
        if (pref.getBoolean(PREF_FIRST_RUN, true)) {
            pref.edit().putBoolean(PREF_FIRST_RUN, false).apply();
            return true;
        }
        return false;
    }
}
