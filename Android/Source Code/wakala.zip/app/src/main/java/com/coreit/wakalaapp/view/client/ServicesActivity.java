package com.coreit.wakalaapp.view.client;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.utils.ImageUtil;
import com.coreit.wakalaapp.view.AnimatedExpandableListView;

import java.util.ArrayList;
import java.util.List;

public class ServicesActivity extends AppCompatActivity {

    private AnimatedExpandableListView listView;
    private ExampleAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<GroupItem> items = new ArrayList<GroupItem>();
        items = fillData(items);
        adapter = new ExampleAdapter(this);
        adapter.setData(items);

        listView = (AnimatedExpandableListView) findViewById(R.id.list_view);
        listView.setDividerHeight(0);
        listView.setAdapter(adapter);

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        Resources r = getResources();
        int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                50, r.getDisplayMetrics());
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
            listView.setIndicatorBounds(width - px, width);
        } else {
            listView.setIndicatorBoundsRelative(width - px, width);
        }

    }

    private static class GroupItem {
        String title;
        String imageUrl;
        List<ChildItem> items = new ArrayList<ChildItem>();
    }

    private static class ChildItem {
        String title;
    }

    private static class ChildHolder {
        TextView title;
        LinearLayout layout;
        //	TextView icon;
    }

    private static class GroupHolder {
        TextView title;
        ImageView image;
    }

    private List<GroupItem> fillData(List<GroupItem> items) {
        GroupItem item = new GroupItem();
        item.title = "Mpesa";
        item.imageUrl = "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213228465aad8b5e3cb5a.jpg";
        ChildItem child;
        child = new ChildItem();
        child.title = "Withdraw";
        item.items.add(child);

        child = new ChildItem();
        child.title = "Deposit";
        item.items.add(child);

        items.add(item);

        item = new GroupItem();
        item.title = "TigoPesa";
        item.imageUrl = "http://192.168.43.69/nova/wakala-api/drive/images/vendors/15213745975aae5585c757e.jpg";
        child = new ChildItem();
        child.title = "Withdraw";
        item.items.add(child);

        child = new ChildItem();
        child.title = "Deposit";
        item.items.add(child);

        items.add(item);

        return items;
    }

    private class ExampleAdapter extends AnimatedExpandableListView.AnimatedExpandableListAdapter
            implements View.OnClickListener {
        private LayoutInflater inflater;

        private List<GroupItem> items;

        public ExampleAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        public void setData(List<GroupItem> items) {
            this.items = items;
        }

        @Override
        public ChildItem getChild(int groupPosition, int childPosition) {
            return items.get(groupPosition).items.get(childPosition);
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public View getRealChildView(int groupPosition, int childPosition,
                                     boolean isLastChild, View convertView, ViewGroup parent) {
            ChildHolder holder;
            ChildItem item = getChild(groupPosition, childPosition);
            if (convertView == null) {
                holder = new ChildHolder();
                convertView = inflater
                        .inflate(R.layout.list_item_expandable_service_child,
                                parent, false);
                holder.title = (TextView) convertView
                        .findViewById(R.id.list_item_expandable_shop_child_title);
                holder.layout = (LinearLayout) convertView
                        .findViewById(R.id.list_item_expandable_shop_child_layout);
                holder.layout.setOnClickListener(this);
                convertView.setTag(holder);
            } else {
                holder = (ChildHolder) convertView.getTag();
            }
            //		holder.icon.setTag(childPosition);
            holder.layout.setTag(childPosition);
            holder.title.setText(item.title.toUpperCase());

            return convertView;
        }

        @Override
        public int getRealChildrenCount(int groupPosition) {
            return items.get(groupPosition).items.size();
        }

        @Override
        public GroupItem getGroup(int groupPosition) {
            return items.get(groupPosition);
        }

        @Override
        public int getGroupCount() {
            return items.size();
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded,
                                 View convertView, ViewGroup parent) {
            GroupHolder holder;
            GroupItem item = getGroup(groupPosition);
            if (convertView == null) {
                holder = new GroupHolder();
                convertView = inflater.inflate(
                        R.layout.list_item_expandable_provider, parent, false);
                holder.title = (TextView) convertView
                        .findViewById(R.id.list_item_provider_title);
                holder.image = (ImageView) convertView
                        .findViewById(R.id.list_item_provider_image);
                convertView.setTag(holder);
            } else {
                holder = (GroupHolder) convertView.getTag();
            }
            ImageUtil.displayImage(holder.image, item.imageUrl, null);
            holder.title.setText(item.title);

            return convertView;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public boolean isChildSelectable(int arg0, int arg1) {
            return true;
        }

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub

            int position = (Integer) v.getTag();
            switch (v.getId()) {
                case R.id.list_item_expandable_shop_child_layout:
                    Intent intent = new Intent(ServicesActivity.this, RequestActivity.class);
                    startActivity(intent);
                    break;
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
