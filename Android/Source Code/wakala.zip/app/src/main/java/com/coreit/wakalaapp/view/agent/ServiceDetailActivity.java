package com.coreit.wakalaapp.view.agent;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.Spinner;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ServiceDetailActivity extends AppCompatActivity {

    LinearLayout mLayout;
    TextView tvProviderName;
    TextView tvSaveButton;
    EditText etAgentNo;
    Map<String, Boolean> mServices;
    String mServiceId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_service_detail);
        mLayout = (LinearLayout) findViewById(R.id.layout_service_list_item);
        tvProviderName = (TextView) findViewById(R.id.service_detail_title);
        etAgentNo = (EditText) findViewById(R.id.agent_service_id);
        tvSaveButton = (TextView) findViewById(R.id.agent_profile_save);
        tvSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = etAgentNo.getText().toString();
                if (code.isEmpty()) {
                    DialogUtils.showError(ServiceDetailActivity.this, ServiceDetailActivity.this.getResources().getString(R.string.enter_agent_number));
                } else {
                    Spinner.show(ServiceDetailActivity.this);
                    new SaveService().execute(code);
                }
            }
        });
        Bundle b = getIntent().getExtras();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        String provider = b.getString("providerName");
        getSupportActionBar().setTitle(provider);
        tvProviderName.setText(provider);
        mServiceId = String.valueOf(b.getLong("providerId"));

        Spinner.show(this);
        new GetService().execute(mServiceId);
    }

    /**
     * Async Task to make http call
     */
    private class GetService extends AsyncTask<String, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(String... arg0) {
            String id = arg0[0];
            return Api.Services(id);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                String code = result.optString("agent_no");
                etAgentNo.setText(code);
                JSONArray items = result.optJSONArray("items");
                mServices = new HashMap<>();
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item != null) {
                        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.fragment_service_item, mLayout, false);
                        layout.setId(i);
                        CheckBox cb = (CheckBox) layout.findViewById(R.id.fragment_service_checkbox);
                        String id = item.optString("id");
                        cb.setTag(id);
                        cb.setText(item.optString("name"));
                        boolean checked = item.optString("provide").equals("1");
                        cb.setChecked(checked);
                        mServices.put(id, checked);
                        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                String id = (String) buttonView.getTag();
                                mServices.put(id, isChecked);
                            }
                        });
                        mLayout.addView(layout);
                    }
                }
            } else {
                DialogUtils.showError(ServiceDetailActivity.this, ServiceDetailActivity.this.getResources().getString(R.string.service_fetch_failed));
            }
            Spinner.hide();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * Async Task to make http call
     */
    private class SaveService extends AsyncTask<String, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(String... arg0) {
            String id = arg0[0];
            return Api.saveService(id, mServices);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null && result.optInt("status", 0) == 1) {
                DialogUtils.showSuccess(ServiceDetailActivity.this, ServiceDetailActivity.this.getResources().getString(R.string.service_update_success));
            } else {
                DialogUtils.showError(ServiceDetailActivity.this, ServiceDetailActivity.this.getResources().getString(R.string.service_update_failed));
            }
        }

    }
}
