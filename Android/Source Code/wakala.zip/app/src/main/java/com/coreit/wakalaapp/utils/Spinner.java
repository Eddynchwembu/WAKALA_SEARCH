package com.coreit.wakalaapp.utils;

import android.app.Dialog;
import android.content.Context;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.view.ProgressWheel;

/**
 * Created by Ramadan on 4/2/2018.
 */

public class Spinner {

    private static Dialog dialog;

    private static Dialog getDialog(Context context) {
        if (dialog == null) {
            dialog = new Dialog(context,R.style.CustomDialogTheme);
            dialog.setContentView(R.layout.dialog_spinner_layout);
            ProgressWheel progress = dialog.findViewById(R.id.spinner);
            progress.spin();
            dialog.setCancelable(false);
        }
        return dialog;
    }

    private static Dialog getDialog() {
        return getDialog(null);
    }

    public static void show(Context context) {
        getDialog(context).show();
    }

    public static void hide() {
        if (dialog != null)
            getDialog().dismiss();
        dialog = null;
    }
}
