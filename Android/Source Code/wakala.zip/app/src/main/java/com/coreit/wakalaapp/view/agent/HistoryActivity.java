package com.coreit.wakalaapp.view.agent;

import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.adapter.AgentHistoryAdapter;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.AgentRequestViewModel;
import com.coreit.wakalaapp.model.SearchModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.widgets.DatepickerFragment;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.nhaarman.listviewanimations.appearance.StickyListHeadersAdapterDecorator;
import com.nhaarman.listviewanimations.appearance.simple.AlphaInAnimationAdapter;
import com.nhaarman.listviewanimations.util.StickyListHeadersListViewWrapper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import se.emilsjolander.stickylistheaders.StickyListHeadersListView;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class HistoryActivity extends AppCompatActivity {

    SwipeRefreshLayout swipeContainer;
    AgentHistoryAdapter adapter;
    private TextView mFilters;
    private TextView mArrow;
    private TextView mSearchButton;
    private TextView mSearchNumber;
    private TextView mClearNumber;
    private LinearLayout mFiltersLayout;
    private EditText mSearchDate;
    private DatepickerFragment datePicker;
    private android.widget.Spinner mSpinner;
    private Map<String, Integer> mServices;
    private SearchModel searchModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_history);
        StickyListHeadersListView listView = (StickyListHeadersListView) findViewById(R.id.history_listview);
        listView.setFitsSystemWindows(true);
        swipeContainer = (SwipeRefreshLayout) findViewById(R.id.swipeContainer);
        mFilters = (TextView) findViewById(R.id.activity_search_bar_shop_filters);
        mArrow = (TextView) findViewById(R.id.activity_search_bar_shop_arrow);
        mSearchButton = (TextView) findViewById(R.id.tv_search_button);
        mFiltersLayout = (LinearLayout) findViewById(R.id.activity_search_bar_shop_filters_layout);
        mSearchDate = (EditText) findViewById(R.id.et_search_date);
        mSearchNumber = (EditText) findViewById(R.id.et_search_number);
        mClearNumber = (TextView) findViewById(R.id.tv_search_clear);
        mSpinner = (android.widget.Spinner) findViewById(R.id.spinner_services);

        mSearchDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (datePicker == null) {
                    datePicker = new DatepickerFragment();
                    datePicker.setInput(mSearchDate);
                }
                DialogFragment newFragment = datePicker;
                newFragment.show(getSupportFragmentManager(), "date picker");

            }
        });

        mClearNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSearchNumber.setText("");
            }
        });

        mFilters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mFiltersLayout.getVisibility() == View.VISIBLE) {
                    mFiltersLayout.setVisibility(View.GONE);
                } else {
                    mFiltersLayout.setVisibility(View.VISIBLE);
                }
                if (mArrow.getText() == getString(R.string.material_icon_chevron_up)) {
                    mArrow.setText(getString(R.string.material_icon_chevron_down));
                } else {
                    mArrow.setText(getString(R.string.material_icon_chevron_up));
                }
            }
        });
        mSearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SearchModel model = getSearchModel();
                Spinner.show(HistoryActivity.this);
                new ListRequests().execute(model);
            }
        });
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new ListRequests().execute(getSearchModel());
            }
        });
        ArrayList<AgentRequestViewModel> list = new ArrayList<>();
        adapter = new AgentHistoryAdapter(this, list);
        AlphaInAnimationAdapter animationAdapter;
        animationAdapter = new AlphaInAnimationAdapter(adapter);

        StickyListHeadersAdapterDecorator stickyListHeadersAdapterDecorator =
                new StickyListHeadersAdapterDecorator(animationAdapter);
        stickyListHeadersAdapterDecorator
                .setListViewWrapper(new StickyListHeadersListViewWrapper(listView));
        assert animationAdapter.getViewAnimator() != null;
        animationAdapter.getViewAnimator().setInitialDelayMillis(500);
        assert stickyListHeadersAdapterDecorator.getViewAnimator() != null;
        stickyListHeadersAdapterDecorator.getViewAnimator()
                .setInitialDelayMillis(500);
        listView.setAdapter(stickyListHeadersAdapterDecorator);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Spinner.show(this);
        final AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int i) {
                mAdView.setVisibility(View.GONE);
            }
        });
        mAdView.loadAd(adRequest);
        new GetServices().execute();
    }

    public SearchModel getSearchModel() {
        if (searchModel == null) {
            searchModel = new SearchModel();
        }
        searchModel.date = mSearchDate.getText().toString();
        searchModel.phone = mSearchNumber.getText().toString();
        String sName = (String) mSpinner.getSelectedItem();
        if (mServices.containsKey(sName)) {
            searchModel.service = String.valueOf(mServices.get(sName));
        }
        return searchModel;
    }

    /**
     * Async Task to make http call
     */
    private class ListRequests extends AsyncTask<SearchModel, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(SearchModel... arg0) {
            SearchModel model = arg0[0];
            return Api.getHistory(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONArray items = result.optJSONArray("items");
                if (!adapter.isEmpty()) {
                    adapter.clear();
                    adapter.getModelList().clear();
                }
                if (items != null) {
                    for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item != null) {
                            AgentRequestViewModel model = new AgentRequestViewModel();
                            model.setId(item.optInt("id", i));
                            model.setImageURL(item.optString("logo"));
                            model.setService(item.optString("name"));
                            model.setClient(item.optString("client"));
                            model.setAmount(item.optString("amount"));
                            model.setDate(item.optString("date"));
                            adapter.getModelList().add(model);
                            adapter.add(item.optString("name"));
                        }
                    }
                }
                swipeContainer.setRefreshing(false);
            } else {
                DialogUtils.showError(HistoryActivity.this, "Failed to get services.");
            }
            Spinner.hide();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.agent_history, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        } else if (item.getItemId() == R.id.action_save_pdf) {
            Spinner.show(HistoryActivity.this);
            SearchModel model = new SearchModel();
            model.date = mSearchDate.getText().toString();
            model.phone = mSearchNumber.getText().toString();
            String sName = (String) mSpinner.getSelectedItem();
            if (mServices.containsKey(sName)) {
                model.service = String.valueOf(mServices.get(sName));
            }
            new DownloadPdf().execute(model);
        } else if (item.getItemId() == R.id.action_add) {
            Intent intent = new Intent(this, LogActivity.class);
            startActivity(intent);
        } else if (item.getItemId() == R.id.action_share) {
            Intent intentShareFile = new Intent(Intent.ACTION_SEND);
            String path = GetPath();
            File fileWithinMyDir = new File(path,"logbook.pdf");

            if (fileWithinMyDir.exists()) {
                intentShareFile.setType("application/pdf");
                intentShareFile.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://" + fileWithinMyDir.getAbsolutePath()));

                intentShareFile.putExtra(Intent.EXTRA_SUBJECT, "Sharing File...");
                intentShareFile.putExtra(Intent.EXTRA_TEXT, "Sharing File...");

                startActivity(Intent.createChooser(intentShareFile, "Share File"));
            }else{
                DialogUtils.showError(this,"Please download Logbook first");
            }
        }
        return super.onOptionsItemSelected(item);
    }


    public String GetPath() {
        String path;
        if (Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
            path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath();
        } else {
            path = getCacheDir().getPath().concat("/Downloads/");
        }
        return path;
    }

    /**
     * Async Task to make http call
     */
    private class DownloadPdf extends AsyncTask<SearchModel, File, File> {
        private static final int PERMISSION_REQUEST_CODE = 200;

        private boolean checkPermission() {

            return ContextCompat.checkSelfPermission(HistoryActivity.this, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(HistoryActivity.this, READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    ;
        }

        private boolean requestPermissionAndContinue() {
            if (ContextCompat.checkSelfPermission(HistoryActivity.this, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(HistoryActivity.this, READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(HistoryActivity.this, WRITE_EXTERNAL_STORAGE)
                        && ActivityCompat.shouldShowRequestPermissionRationale(HistoryActivity.this, READ_EXTERNAL_STORAGE)) {
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(HistoryActivity.this);
                    alertBuilder.setCancelable(true);
                    alertBuilder.setTitle(getString(R.string.permission_necessary));
                    alertBuilder.setMessage(R.string.storage_permission_is_encessary_to_wrote_event);
                    alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(HistoryActivity.this, new String[]{WRITE_EXTERNAL_STORAGE
                                    , READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
                        }
                    });
                    AlertDialog alert = alertBuilder.create();
                    alert.show();
                    Log.e("", "permission denied, show dialog");
                } else {
                    ActivityCompat.requestPermissions(HistoryActivity.this, new String[]{WRITE_EXTERNAL_STORAGE,
                            READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
                }
                return false;
            } else {
                return true;
            }
        }


        @Override
        protected File doInBackground(SearchModel... arg0) {
            SearchModel model = arg0[0];
            String path;
            if (Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
                path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath();
            } else {
                path = getCacheDir().getPath().concat("/Downloads/");
            }
            if (!checkPermission()) {
                return Api.getLogbook(model, path);
            } else {
                if (checkPermission()) {
                    if (requestPermissionAndContinue()) {
                        return Api.getLogbook(model, path);
                    }
                } else {
                    return Api.getLogbook(model, path);
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(File file) {
            super.onPostExecute(file);
            Spinner.hide();
            if (file != null && file.exists()) {
                MimeTypeMap mimeMap = MimeTypeMap.getSingleton();
                Uri uri;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    uri = FileProvider.getUriForFile(HistoryActivity.this, HistoryActivity.this.getApplicationContext().getPackageName() + ".provider", file);
                } else {
                    uri = Uri.fromFile(file);
                }
                //
                ContentResolver cr = HistoryActivity.this.getContentResolver();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                String mime = mimeMap.getMimeTypeFromExtension(cr.getType(uri));
                intent.setDataAndType(uri, mime);
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                List<ResolveInfo> resInfoList = HistoryActivity.this.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
                for (ResolveInfo resolveInfo : resInfoList) {
                    String packageName = resolveInfo.activityInfo.packageName;
                    HistoryActivity.this.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
                try {
                    HistoryActivity.this.startActivity(intent);
                } catch (ActivityNotFoundException ex) {
                    DialogUtils.showError(HistoryActivity.this, "Cannot open logbook");
                }
            } else {
                DialogUtils.showError(HistoryActivity.this, "Failed to download logbook");
            }
        }
    }

    /**
     * Async Task to make http call
     */
    private class GetServices extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.getProviders();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null && result.optInt("status", 0) == 1) {
                if (mServices == null) {
                    mServices = new LinkedHashMap<>();
                }
                mServices.put("All", 0);
                JSONArray items = result.optJSONArray("items");
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    int id = item.optInt("id");
                    String name = item.optString("name");
                    mServices.put(name, id);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(HistoryActivity.this, R.layout.spinner_item, mServices.keySet().toArray(new String[]{}));
                mSpinner.setAdapter(adapter);
            }
        }
    }


}
