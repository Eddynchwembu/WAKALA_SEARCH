package com.coreit.wakalaapp.widgets;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.model.ClientRequestViewModel;
import com.coreit.wakalaapp.utils.ImageUtil;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class RatingDialog extends Dialog {

    private TextView mDialogOKButton;
    private TextView mDialogCancelButton;
    private ImageView mImage;
    private TextView mAgentName;
    private RatingBar mRatingBar;
    private EditText mComment;
    private String errors;
    private ClientRequestViewModel mModel;

    public RatingDialog(Context context, ClientRequestViewModel model) {
        super(context, R.style.CustomDialogTheme);
        setContentView(R.layout.dialog_rating);
        setCancelable(true);
        mModel = model;
        mDialogOKButton = (TextView) findViewById(R.id.dialog_ok);
        mDialogCancelButton = (TextView) findViewById(R.id.dialog_cancel);
        mImage = (ImageView) findViewById(R.id.tv_review_agent_image);
        mAgentName = (TextView) findViewById(R.id.tv_review_agent_name);
        mRatingBar = (RatingBar) findViewById(R.id.rating_bar);
        mComment = (EditText) findViewById(R.id.et_rating_comment);
        mAgentName.setText(model.agent);
        ImageUtil.displayRoundImage(mImage, model.getImageURL(), null);
        setOnCancelListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }


    public void setOnOkListener(View.OnClickListener listener) {
        mDialogOKButton.setOnClickListener(listener);
    }

    public void setOnCancelListener(View.OnClickListener listener) {
        mDialogCancelButton.setOnClickListener(listener);
    }

    public float getRating() {
        return mRatingBar.getRating();
    }

    public String getComment() {
        return mComment.getText().toString();
    }

    public ClientRequestViewModel getModel() {
        return mModel;
    }

    public String getErrors() {
        return errors;
    }
}
