package com.coreit.wakalaapp.model;

public class AgentRequestViewModel {

    private long mId;
    private String mImageURL;
    private String mService;
    private String mClient;
    private String mAmount;
    private String mDate;
    private String mAgo;

    private int mIconRes;

    public AgentRequestViewModel() {
    }

    public AgentRequestViewModel(long id, String imageURL, String text, int iconRes) {
        mId = id;
        mImageURL = imageURL;
        mService = text;
        mIconRes = iconRes;
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public String getImageURL() {
        return mImageURL;
    }

    public void setImageURL(String imageURL) {
        mImageURL = imageURL;
    }

    public String getService() {
        return mService;
    }

    public void setService(String text) {
        mService = text;
    }

    public void setClient(String client) {
        mClient = client;
    }

    public String getAgent() {
        return mClient;
    }

    public String getAmount() {
        return mAmount;
    }

    public void setAmount(String amount) {
        mAmount = amount;
    }

    public void setDate(String date){
        mDate = date;
    }

    public String getDate(){
        return  mDate;
    }

    public void setAgo(String date){
        mAgo = date;
    }

    public String getAgo(){
        return  mAgo;
    }
    public int getIconRes() {
        return mIconRes;
    }

    public void setIconRes(int iconRes) {
        mIconRes = iconRes;
    }

    @Override
    public String toString() {
        return mService;
    }
}
