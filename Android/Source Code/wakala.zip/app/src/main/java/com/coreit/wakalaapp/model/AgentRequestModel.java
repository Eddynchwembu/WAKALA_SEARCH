package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 4/1/2018.
 */

public class AgentRequestModel {
    public String id;
    public String status;
}
