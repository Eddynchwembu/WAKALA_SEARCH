package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 4/16/2018.
 */

public class RatingViewModel {
    public long id;
    public long clientId;
    public String clientImage;
    public String clientName;
    public String comment;
    public float rating;
    public String time;
}
