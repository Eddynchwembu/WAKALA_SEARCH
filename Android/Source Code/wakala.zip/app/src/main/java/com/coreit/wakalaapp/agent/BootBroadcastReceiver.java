package com.coreit.wakalaapp.agent;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class BootBroadcastReceiver extends WakefulBroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent startServiceIntent = new Intent(context, NotificationServiceOld.class);
        startWakefulService(context, startServiceIntent);
    }
}
