package com.coreit.wakalaapp.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Ramadan on 4/2/2018.
 */

public class AgentModel implements Parcelable{
    public int id;
    public double latitude;
    public double longitude;
    public String name;
    public String phone;
    public String image;
    public String tillNo;
    public double rating;

    public AgentModel(){

    }

    protected AgentModel(Parcel in) {
        id = in.readInt();
        latitude = in.readDouble();
        longitude = in.readDouble();
        name = in.readString();
        phone = in.readString();
        image = in.readString();
        tillNo = in.readString();
        rating = in.readDouble();
    }

    public static final Creator<AgentModel> CREATOR = new Creator<AgentModel>() {
        @Override
        public AgentModel createFromParcel(Parcel in) {
            return new AgentModel(in);
        }

        @Override
        public AgentModel[] newArray(int size) {
            return new AgentModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeDouble(latitude);
        parcel.writeDouble(longitude);
        parcel.writeString(name);
        parcel.writeString(phone);
        parcel.writeString(image);
        parcel.writeString(tillNo);
        parcel.writeDouble(rating);
    }
}
