package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 3/26/2018.
 */

public class AgentViewModel {

    public long id;
    public String name;
    public String location;
    public String latitude;
    public String longitude;
    public String distance;
    public String rating;
    public String imageUrl;
}
