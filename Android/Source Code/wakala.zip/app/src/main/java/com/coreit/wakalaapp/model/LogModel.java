package com.coreit.wakalaapp.model;

public class LogModel {

    public String clientNumber;
    public String amount;
    public int serviceId = 0;
    public String comment;
    public String date;

    public boolean validate() {
        if (clientNumber == null || clientNumber.isEmpty()) {
            return false;
        }
        if (amount == null || amount.isEmpty()) {
            return false;
        }
        if (date == null || date.isEmpty()) {
            return false;
        }

        if (serviceId == 0) {
            return false;
        }
        return true;
    }
}
