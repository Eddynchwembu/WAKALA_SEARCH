package com.coreit.wakalaapp.view.client;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.ClientProfile;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.view.agent.SettingsActivity;
import com.coreit.wakalaapp.widgets.ChangePasswordDialog;
import com.coreit.wakalaapp.widgets.GenderDialog;

import org.json.JSONObject;

public class ProfileActivity extends AppCompatActivity {
    ClientProfile profile;
    TextView tvPhone;
    TextView tvEmail;
    TextView tvLocation;
    TextView tvName;
    TextView tvGender;

    private String mGender = "";
    private String mOldPassword = "";
    private String mNewPassword = "";
    private String mEmail = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        tvEmail = (TextView) findViewById(R.id.tv_client_profile_email);
        tvPhone = (TextView) findViewById(R.id.tv_client_profile_phone);
        tvName = (TextView) findViewById(R.id.tv_client_profile_name);
        tvGender = (TextView) findViewById(R.id.tv_client_profile_gender);
        RelativeLayout gender = (RelativeLayout) findViewById(R.id.layout_gender);
        RelativeLayout password = (RelativeLayout) findViewById(R.id.layout_password);
        TextView save = (TextView) findViewById(R.id.client_profile_save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mGender.isEmpty() || !mEmail.isEmpty() || !mOldPassword.isEmpty()) {
                    ClientProfile model = new ClientProfile();
                    model.gender = mGender;
                    model.email = mEmail;
                    model.oldPassword = mOldPassword;
                    model.newPassword = mNewPassword;
                    Spinner.show(ProfileActivity.this);
                    new UpdateProfile().execute(model);
                }
            }
        });

        gender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final GenderDialog diag = new GenderDialog(ProfileActivity.this);
                diag.setOnOkListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tvGender.setText(diag.getSelectedGender());
                        mGender = diag.getSelectedGender();
                        diag.dismiss();
                    }
                });
                diag.show();
            }
        });

        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ChangePasswordDialog diag = new ChangePasswordDialog(ProfileActivity.this);
                diag.setOnOkListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (diag.validate()) {
                            mOldPassword = diag.getOldPassword();
                            mNewPassword = diag.getPassword();
                            diag.dismiss();
                        } else {
                            DialogUtils.showError(ProfileActivity.this, diag.getErrors());
                        }

                    }
                });
                diag.show();
            }
        });

        profile = getIntent().getExtras().getParcelable("profile");
        if (profile != null) {
            tvEmail.setText(profile.email);
            tvPhone.setText(profile.phone);
            tvName.setText(profile.name);
            tvGender.setText(profile.gender);
            //tvLocation.setText(profile.location);
            toolbar.setTitle(profile.phone);
        }
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Async Task to make http call
     */
    private class UpdateProfile extends AsyncTask<ClientProfile, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(ClientProfile... arg0) {
            ClientProfile model = arg0[0];
            return Api.updateProfile(model);
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ProfileActivity.this);
                SharedPreferences.Editor editor = pref.edit();
                if (!mGender.isEmpty()) {
                    editor.putString(App.PREF_USER_GENDER, mGender);
                }
                editor.apply();
                DialogUtils.showSuccess(ProfileActivity.this, "Profile Updated");
            } else {
                DialogUtils.showError(ProfileActivity.this, "Failed to update profile please check your password.");
            }
            Spinner.hide();
        }

    }
}
