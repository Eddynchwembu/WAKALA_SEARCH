package com.coreit.wakalaapp.view.agent;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.LoginActivity;
import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.adapter.DrawerAdapter;
import com.coreit.wakalaapp.agent.Api;
import com.coreit.wakalaapp.model.AgentProfile;
import com.coreit.wakalaapp.model.DrawerItem;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.GPSTracker;
import com.coreit.wakalaapp.utils.ImageUtil;
import com.coreit.wakalaapp.utils.Spinner;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private ListView mDrawerList;
    private List<DrawerItem> mDrawerItems;
    private DrawerLayout mDrawerLayout;
    private TextView mStartTrack;
    private TextView mStopTrack;
    private GoogleMap mMap;
    private GPSTracker gps;
    private double latitude;
    private double longitude;
    private CountDownTimer countDownTimer;
    private SparseArray<Marker> markers;
    private SharedPreferences pref;
    private boolean started = false;
    private TextView mClients;
    private TextView mBusiness;
    private TextView mAgentName;

    private DrawerItem requestDrawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ImageLoader imageLoader = ImageLoader.getInstance();
        if (!imageLoader.isInited()) {
            imageLoader.init(ImageLoaderConfiguration.createDefault(this));
        }
        pref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_agent_layout);
        mStartTrack = (TextView) findViewById(R.id.tv_main_track);
        mStopTrack = (TextView) findViewById(R.id.tv_main_stop);
        mClients = (TextView) findViewById(R.id.tv_main_client_number);
        mBusiness = (TextView) findViewById(R.id.tv_main_business);
        mAgentName = (TextView) findViewById(R.id.tv_main_agent_name);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.setDrawerListener(toggle);
        toggle.syncState();

        mDrawerList = (ListView) findViewById(R.id.list_view);
        mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
                GravityCompat.START);
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());
        mBusiness.setText(pref.getString(App.PREF_BUSINESS_NAME, ""));
        mAgentName.setText(pref.getString(App.PREF_USERNAME, ""));
        prepareNavigationDrawerItems();
        setNavigationAdapter();
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        gps = new GPSTracker(this);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        countDownTimer = new CountDownTimer(Long.MAX_VALUE, 10000) {

            // This is called after every 10 sec interval.
            public void onTick(long millisUntilFinished) {
                //cancel();
                new GetClients().execute();
            }

            public void onFinish() {
                start();
            }
        };

        mStartTrack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!started) {
                    countDownTimer.start();
                    DialogUtils.showSuccess(MainActivity.this, "Tracking started.");
                    started = true;
                }
            }
        });
        mStopTrack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (started) {
                    countDownTimer.cancel();
                    DialogUtils.showSuccess(MainActivity.this, "Tracking stopped.");
                    started = false;
                }
            }
        });
        final AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int i) {
                mAdView.setVisibility(View.GONE);
            }
        });
        mAdView.loadAd(adRequest);
    }

    private void prepareNavigationDrawerItems() {
        mDrawerItems = new ArrayList<>();
        requestDrawer = new DrawerItem(R.string.icon_message_alert, R.string.drawer_title_requests, 27, "0");
        mDrawerItems.add(requestDrawer);
        mDrawerItems.add(new DrawerItem(R.string.icon_search, R.string.drawer_title_logbook, 27));
        mDrawerItems.add(new DrawerItem(R.string.icon_account_location, R.string.profile, 28));
        mDrawerItems.add(new DrawerItem(R.string.icon_cog, R.string.settings, 29));
        mDrawerItems.add(new DrawerItem(R.string.icon_logout, R.string.logout, 30));
        mDrawerItems.add(new DrawerItem(R.string.material_icon_go, R.string.exit, 30));
    }

    private void setNavigationAdapter() {
        BaseAdapter adapter = new DrawerAdapter(this, mDrawerItems);
        View headerView = null;
        String image = pref.getString(App.PREF_USER_IMAGE, "");
        headerView = prepareHeaderView(R.layout.header_agent_nav_drawer, image,
                "dev@csform.com");
        mDrawerList.addHeaderView(headerView);
        mDrawerList.setAdapter(adapter);
    }

    private View prepareHeaderView(int layoutRes, String url, String email) {
        View headerView = getLayoutInflater().inflate(layoutRes, mDrawerList,
                false);
        ImageView iv = (ImageView) headerView.findViewById(R.id.image);
        TextView tvMobile = (TextView) headerView.findViewById(R.id.drawer_agent_mobile);
        TextView tvName = (TextView) headerView.findViewById(R.id.drawer_agent_name);
        TextView tvBusiness = (TextView) headerView.findViewById(R.id.drawer_agent_business);
        String name = pref.getString(App.PREF_USERNAME, "");
        String mobile = pref.getString(App.PREF_MOBILE, "");
        String business = pref.getString(App.PREF_BUSINESS_NAME, "");
        ImageUtil.displayRoundImage(iv, url, null);
        tvMobile.setText(mobile);
        tvName.setText(name);
        tvBusiness.setText(business);

        return headerView;
    }

    private class DrawerItemClickListener implements
            ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {
            selectItem(position/* , mDrawerItems.get(position - 1).getTag() */);
        }
    }

    private void selectItem(int position/* , int drawerTag */) {
        // minus 1 because we have header that has 0 position
        if (position < 1) { // because we have header, we skip clicking on it
            return;
        }
        switch (position) {
            case 1://requests
                Intent requests = new Intent(MainActivity.this, RequestsActivity.class);
                startActivity(requests);
                break;
            case 2:
                Intent history = new Intent(MainActivity.this, HistoryActivity.class);
                startActivity(history);
                break;
            case 3://profile
                Spinner.show(MainActivity.this);
                new GetProfile().execute();
                break;
            case 4:
                Intent setting = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(setting);
                break;
            case 5:
                Spinner.show(MainActivity.this);
                new LogoutAgent().execute();
                break;
            case 6:
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;
        }
        mDrawerList.setItemChecked(position, true);
        mDrawerLayout.closeDrawer(mDrawerList);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_agent_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.agent_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Async Task to make http call
     */
    private class LogoutAgent extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.logout();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null) {
                SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                SharedPreferences.Editor editor = pref.edit();
                if (result.optInt("status", 0) == 1 || result.optInt("status") == 401) {
                    editor.remove(App.PREF_TOKEN);
                    editor.remove(App.PREF_USER_TYPE);
                    editor.apply();
                    Spinner.hide();
                    Intent i = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(i);
                    finish();
                }
            } else {
                Spinner.hide();
                DialogUtils.showError(MainActivity.this, "Logout failed.");
            }
        }

    }

    /**
     * Async Task to make http call
     */
    private class GetProfile extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.profile();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {

                JSONObject profile = result.optJSONObject("profile");
                if (profile != null) {
                    AgentProfile model = new AgentProfile();
                    model.business = profile.optString("business");
                    model.phone = profile.optString("phone");
                    model.name = profile.optString("name");
                    model.email = profile.optString("email");
                    model.location = profile.optString("location");
                    model.latitude = profile.optString("latitude");
                    model.longitude = profile.optString("longitude");
                    Spinner.hide();
                    Intent i = new Intent(MainActivity.this, ProfileActivity.class);
                    i.putExtra("profile", model);
                    startActivity(i);
                } else {
                    DialogUtils.showError(MainActivity.this, "Login failed.");
                }
            } else {
                DialogUtils.showError(MainActivity.this, "Logout failed.");
                Spinner.hide();
            }
        }
    }

    /**
     * Async Task to make http call
     */
    private class GetClients extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.getClients();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                if (markers == null) {
                    markers = new SparseArray<>();
                }
                JSONArray items = result.optJSONArray("items");
                String requestCount = result.optString("requests");
                String count = String.valueOf(items.length());
                mClients.setText(count);
                requestDrawer.mCounter.setText(requestCount);
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    int id = item.optInt("id");
                    double latitude = item.optDouble("latitude");
                    double longitude = item.optDouble("longitude");
                    LatLng latLng = new LatLng(latitude, longitude);
                    String name = item.optString("name");
                    String phone = item.optString("phone");
                    Marker marker = markers.get(id);
                    if (markers.get(id) == null) {
                        marker = mMap.addMarker(new MarkerOptions().position(latLng).title(name)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.client_marker)));
                        markers.put(id, marker);
                        marker.setTag(id);
                    } else {
                        marker.setPosition(latLng);
                    }
                }
            }
            //countDownTimer.start();
        }
    }


    private void updateLocation() {
        if (mMap != null) {
            latitude = Double.valueOf(pref.getString(App.PREF_USER_LATITUDE, "0"));
            longitude = Double.valueOf(pref.getString(App.PREF_USER_LONGITUDE, "0"));
            LatLng location = new LatLng(latitude, longitude);
            mMap.addMarker(new MarkerOptions().position(location).title(getString(R.string.your_position))
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.agent_marker)));
            mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(final Marker marker) {
                    Object tag = marker.getTag();
                    if (tag != null) {
                        final int id = (int) tag;
                        DialogUtils.showConfirm(MainActivity.this, getString(R.string.client_serve_prompt, marker.getTitle()), new DialogUtils.DialogListener() {
                            @Override
                            public void onOkClick(Context context, Dialog dialog, View view) {
                                Spinner.show(MainActivity.this);
                                new ServeRequest().execute(id);
                            }

                            @Override
                            public void onCancelClick(Context context, Dialog dialog, View view) {

                            }
                        });
                    }

                }
            });
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(location, 15);
            mMap.animateCamera(update);
        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        updateLocation();
    }

    /**
     * Async Task to make http call
     */
    private class ServeRequest extends AsyncTask<Integer, JSONObject, JSONObject> {

        int mId;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Integer... arg0) {
            mId = arg0[0];
            return Api.serveRequest(String.valueOf(mId));
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null && result.optInt("status", 0) == 1) {
                Marker marker = markers.get(mId);
                marker.remove();//show toast
                Toast.makeText(MainActivity.this, getResources().getString(R.string.client_serve_success), Toast.LENGTH_LONG).show();
            } else {
                DialogUtils.showError(MainActivity.this, getResources().getString(R.string.client_serve_failed));
            }
            countDownTimer.start();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (countDownTimer != null) {
            countDownTimer.start();
            started = true;
        }
        updateLocation();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (countDownTimer != null) {
            countDownTimer.cancel();
            started = false;
        }
    }
}
