package com.coreit.wakalaapp.view.client;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.TypedValue;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.coreit.wakalaapp.App;
import com.coreit.wakalaapp.LoginActivity;
import com.coreit.wakalaapp.R;
import com.coreit.wakalaapp.adapter.DrawerAdapter;
import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.ClientProfile;
import com.coreit.wakalaapp.model.DrawerItem;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.ImageUtil;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.view.AnimatedExpandableListView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView mDrawerList;
    private List<DrawerItem> mDrawerItems;
    private DrawerLayout mDrawerLayout;
    private SwipeRefreshLayout swipeContainer;

    private AnimatedExpandableListView listView;
    private ProviderAdapter adapter;
    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_client_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.setDrawerListener(toggle);
        toggle.syncState();
        pref = PreferenceManager.getDefaultSharedPreferences(this);
        swipeContainer = (SwipeRefreshLayout) findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new ListServices().execute();
            }
        });
        mDrawerList = (ListView) findViewById(R.id.list_view);
        mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow, GravityCompat.START);
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

        prepareNavigationDrawerItems();
        setNavigationAdapter();
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);

        final AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int i) {
                mAdView.setVisibility(View.GONE);
            }
        });
        mAdView.loadAd(adRequest);
        Spinner.show(this);

        new ListServices().execute();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void prepareNavigationDrawerItems() {
        mDrawerItems = new ArrayList<>();
        mDrawerItems.add(new DrawerItem(R.string.icon_message_alert, R.string.drawer_title_requests, 27));
        mDrawerItems.add(new DrawerItem(R.string.icon_account_location, R.string.profile, 28));
        mDrawerItems.add(new DrawerItem(R.string.icon_cog, R.string.settings, 29));
        mDrawerItems.add(new DrawerItem(R.string.icon_logout, R.string.logout, 30));
        mDrawerItems.add(new DrawerItem(R.string.material_icon_go, R.string.exit, 30));
    }

    private void setNavigationAdapter() {
        BaseAdapter adapter = new DrawerAdapter(this, mDrawerItems);
        View headerView = null;
        String image = pref.getString(App.PREF_USER_IMAGE, "");
        headerView = prepareHeaderView(R.layout.header_client_nav_drawer, image, "dev@csform.com");
        mDrawerList.addHeaderView(headerView);// Add header before adapter (for
        // pre-KitKat)
        mDrawerList.setAdapter(adapter);
    }

    private View prepareHeaderView(int layoutRes, String url, String email) {
        View headerView = getLayoutInflater().inflate(layoutRes, mDrawerList,
                false);
        ImageView iv = (ImageView) headerView.findViewById(R.id.image);
        TextView tvMobile = (TextView) headerView.findViewById(R.id.client_mobile);
        TextView tvName = (TextView) headerView.findViewById(R.id.client_name);

        String name = pref.getString(App.PREF_USERNAME, "");
        String mobile = pref.getString(App.PREF_MOBILE, "");
        ImageUtil.displayRoundImage(iv, url, null);
        tvMobile.setText(mobile);
        tvName.setText(name);

        return headerView;
    }

    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {
            selectItem(position/* , mDrawerItems.get(position - 1).getTag() */);
        }
    }

    private void selectItem(int position/* , int drawerTag */) {
        // minus 1 because we have header that has 0 position
        if (position < 1) { // because we have header, we skip clicking on it
            return;
        }
        switch (position) {
            case 1://requests
                Intent requests = new Intent(MainActivity.this, RequestsActivity.class);
                startActivity(requests);
                break;
            case 2://profile
                Spinner.show(this);
                new GetProfile().execute();
                break;
            case 3:
                Intent setting = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(setting);
                break;
            case 4:
                Spinner.show(this);
                new LogoutClient().execute();
                break;
            case 5:
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;
        }
        mDrawerList.setItemChecked(position, true);
        mDrawerLayout.closeDrawer(mDrawerList);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_client_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.client_main, menu);
        return true;
    }

    private static class GroupItem {
        String title;
        String imageUrl;
        List<ChildItem> items = new ArrayList<ChildItem>();
    }

    private static class ChildItem {
        String title;
        String id;
        int groupPosition;
    }

    private static class ChildHolder {
        TextView title;
        LinearLayout layout;
        //	TextView icon;
    }

    private static class GroupHolder {
        TextView title;
        ImageView image;
    }

    private class ProviderAdapter extends AnimatedExpandableListView.AnimatedExpandableListAdapter
            implements View.OnClickListener {
        private LayoutInflater inflater;

        private List<GroupItem> items;

        public ProviderAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        public void setData(List<GroupItem> items) {
            this.items = items;
        }

        @Override
        public ChildItem getChild(int groupPosition, int childPosition) {
            return items.get(groupPosition).items.get(childPosition);
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public View getRealChildView(int groupPosition, int childPosition,
                                     boolean isLastChild, View convertView, ViewGroup parent) {
            ChildHolder holder;
            ChildItem item = getChild(groupPosition, childPosition);
            if (convertView == null) {
                holder = new ChildHolder();
                convertView = inflater
                        .inflate(R.layout.list_item_expandable_service_child,
                                parent, false);
                holder.title = (TextView) convertView
                        .findViewById(R.id.list_item_expandable_shop_child_title);
                holder.layout = (LinearLayout) convertView
                        .findViewById(R.id.list_item_expandable_shop_child_layout);
                holder.layout.setOnClickListener(this);
                convertView.setTag(holder);
            } else {
                holder = (ChildHolder) convertView.getTag();
            }
            item.groupPosition = groupPosition;
            holder.layout.setTag(item);
            holder.title.setText(item.title.toUpperCase());

            return convertView;
        }

        @Override
        public int getRealChildrenCount(int groupPosition) {
            return items.get(groupPosition).items.size();
        }

        @Override
        public GroupItem getGroup(int groupPosition) {
            return items.get(groupPosition);
        }

        @Override
        public int getGroupCount() {
            return items.size();
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded,
                                 View convertView, ViewGroup parent) {
            GroupHolder holder;
            GroupItem item = getGroup(groupPosition);
            if (convertView == null) {
                holder = new GroupHolder();
                convertView = inflater.inflate(
                        R.layout.list_item_expandable_provider, parent, false);
                holder.title = (TextView) convertView
                        .findViewById(R.id.list_item_provider_title);
                holder.image = (ImageView) convertView
                        .findViewById(R.id.list_item_provider_image);
                convertView.setTag(holder);
            } else {
                holder = (GroupHolder) convertView.getTag();
            }
            ImageUtil.displayImage(holder.image, item.imageUrl, null);
            holder.title.setText(item.title);

            return convertView;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public boolean isChildSelectable(int arg0, int arg1) {
            return true;
        }

        @Override
        public void onClick(View v) {
            ChildItem item = (ChildItem) v.getTag();
            GroupItem parent = items.get(item.groupPosition);
            switch (v.getId()) {
                case R.id.list_item_expandable_shop_child_layout:
                    Intent intent = new Intent(MainActivity.this, RequestActivity.class);
                    intent.putExtra("serviceId", item.id);
                    intent.putExtra("serviceName", item.title);
                    intent.putExtra("providerName", parent.title);
                    intent.putExtra("providerImage", parent.imageUrl);
                    startActivity(intent);
                    break;
            }
        }
    }

    /**
     * Async Task to make http call
     */
    private class LogoutClient extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.logout();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            Spinner.hide();
            if (result != null) {
                SharedPreferences.Editor editor = pref.edit();
                if (result.optInt("status", 0) == 1 || result.optInt("status") == 401) {
                    editor.remove(App.PREF_TOKEN);
                    editor.remove(App.PREF_USER_TYPE);
                    editor.apply();
                    Intent i = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(i);
                    finish();
                }
            } else {
                DialogUtils.showError(MainActivity.this, "Logout failed.");
            }
        }

    }

    /**
     * Async Task to make http call
     */
    private class ListServices extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.getServices();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONArray items = result.optJSONArray("items");
                if (items != null) {

                    List<GroupItem> providers = new ArrayList<GroupItem>();
                    if (listView == null) {
                        listView = (AnimatedExpandableListView) findViewById(R.id.list_service_view);

                        Display display = getWindowManager().getDefaultDisplay();
                        Point size = new Point();
                        display.getSize(size);
                        int width = size.x;
                        Resources r = getResources();
                        int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                                50, r.getDisplayMetrics());
                        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
                            listView.setIndicatorBounds(width - px, width);
                        } else {
                            listView.setIndicatorBoundsRelative(width - px, width);
                        }
                        listView.setDividerHeight(0);
                    }

                    for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item != null) {

                            GroupItem service = new GroupItem();
                            service.title = item.optString("name");
                            service.imageUrl = item.optString("logo");

                            JSONArray services = item.optJSONArray("services");
                            if (services != null) {
                                for (int j = 0; j < services.length(); j++) {
                                    JSONObject svcItem = services.optJSONObject(j);

                                    ChildItem child;
                                    child = new ChildItem();
                                    child.title = svcItem.optString("name");
                                    child.id = svcItem.optString("id");
                                    service.items.add(child);
                                }
                            }
                            providers.add(service);
                        }
                    }

                    if (adapter == null) {
                        adapter = new ProviderAdapter(MainActivity.this);
                    }
                    adapter.setData(providers);
                    listView.setAdapter(adapter);
                    swipeContainer.setRefreshing(false);
                    Spinner.hide();
                }

            } else {
                Spinner.hide();
                DialogUtils.showError(MainActivity.this, "Failed to get services.");
            }
        }

    }

    /**
     * Async Task to make http call
     */
    private class GetProfile extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.profile();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {

                JSONObject profile = result.optJSONObject("profile");
                if (profile != null) {
                    ClientProfile model = new ClientProfile();
                    model.name = profile.optString("name");
                    model.phone = profile.optString("mobile_no");
                    model.email = profile.optString("email");
                    model.image = profile.optString("image");
                    model.gender = profile.optString("gender");
                    Intent i = new Intent(MainActivity.this, ProfileActivity.class);
                    i.putExtra("profile", model);
                    startActivity(i);
                } else {
                    DialogUtils.showError(MainActivity.this, "Failed to get profile.");
                }
            } else {
                DialogUtils.showError(MainActivity.this, "Failed to get profile.");
            }
            Spinner.hide();
        }

    }

}
