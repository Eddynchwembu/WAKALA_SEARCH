package com.coreit.wakalaapp.model;

/**
 * Created by Ramadan on 4/7/2018.
 */

public class RatingModel {
    public float rating;
    public String comment;
    public String agent;
    public String agentId;
}
