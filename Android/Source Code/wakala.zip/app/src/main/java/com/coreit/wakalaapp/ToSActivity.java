package com.coreit.wakalaapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.widget.TextView;

import com.coreit.wakalaapp.client.Api;
import com.coreit.wakalaapp.model.LoginModel;
import com.coreit.wakalaapp.utils.DialogUtils;
import com.coreit.wakalaapp.utils.Spinner;
import com.coreit.wakalaapp.view.client.MainActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class ToSActivity extends AppCompatActivity {

    TextView tvLastUpdate;
    TextView tvContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tos);
        tvContent = findViewById(R.id.tv_tos);
        tvLastUpdate = findViewById(R.id.tv_tos_last_update);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Spinner.show(this);
        new FetchToS().execute();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Async Task to make http call
     */
    private class FetchToS extends AsyncTask<Void, JSONObject, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // before making http calls

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            return Api.getToS();
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null && result.optInt("status", 0) == 1) {
                JSONObject profile = result.optJSONObject("tos");
                if (profile != null) {
                    String lastUpdate = profile.optString("last_update");
                    Resources res = getResources();
                    String text = String.format(res.getString(R.string.last_updated), lastUpdate);
                    String content = profile.optString("content");
                    tvLastUpdate.setText(text);
                    tvContent.setText(Html.fromHtml(content));
                }
            }
            Spinner.hide();
        }

    }

}
