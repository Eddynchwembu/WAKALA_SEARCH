package com.coreit.wakalaapp.widgets;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.coreit.wakalaapp.R;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class ChangeEmailDialog extends Dialog {

    private TextView mDialogOKButton;
    private TextView mDialogCancelButton;
    private EditText mEmail;
    private String errors;

    public ChangeEmailDialog(Context context) {
        super(context, R.style.CustomDialogTheme);
        setContentView(R.layout.dialog_change_email);
        setCancelable(true);

        mDialogOKButton = (TextView) findViewById(R.id.dialog_ok);
        mDialogCancelButton = (TextView) findViewById(R.id.dialog_cancel);
        mEmail = (EditText) findViewById(R.id.et_email);

        setOnCancelListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }


    public void setOnOkListener(View.OnClickListener listener) {
        mDialogOKButton.setOnClickListener(listener);
    }

    public void setOnCancelListener(View.OnClickListener listener) {
        mDialogCancelButton.setOnClickListener(listener);
    }


    public String getEmail() {
        if (mEmail != null) {
            return mEmail.getText().toString();
        }
        return null;
    }

    public boolean validate() {
        errors = "";
        if (getEmail().isEmpty()) {
            errors = errors.concat(getContext().getString(R.string.error_email_required));
        }
        return errors.isEmpty();
    }

    public String getErrors() {
        return errors;
    }
}
