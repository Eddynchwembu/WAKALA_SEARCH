package com.coreit.wakalaapp.widgets;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.coreit.wakalaapp.R;

/**
 * Created by Ramadan on 3/30/2018.
 */

public class ChangePasswordDialog extends Dialog {

    private TextView mDialogOKButton;
    private TextView mDialogCancelButton;
    private EditText mOldPassword;
    private EditText mPassword;
    private EditText mConfirmPassword;
    private String errors;

    public ChangePasswordDialog(Context context) {
        super(context, R.style.CustomDialogTheme);
        setContentView(R.layout.dialog_change_pwd);
        setCancelable(true);

        mDialogOKButton = (TextView) findViewById(R.id.dialog_ok);
        mDialogCancelButton = (TextView) findViewById(R.id.dialog_cancel);
        mOldPassword = (EditText) findViewById(R.id.et_change_pwd_old);
        mPassword = (EditText) findViewById(R.id.et_change_pwd_new);
        mConfirmPassword = (EditText) findViewById(R.id.et_change_pwd_confirm);

        setOnCancelListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }


    public void setOnOkListener(View.OnClickListener listener) {
        mDialogOKButton.setOnClickListener(listener);
    }

    public void setOnCancelListener(View.OnClickListener listener) {
        mDialogCancelButton.setOnClickListener(listener);
    }


    public String getOldPassword() {
        if (mOldPassword != null) {
            return mOldPassword.getText().toString();
        }
        return null;
    }

    public String getPassword() {
        if (mPassword != null) {
            return mPassword.getText().toString();
        }
        return null;
    }

    public String getConfirmPassword() {
        if (mConfirmPassword != null) {
            return mConfirmPassword.getText().toString();
        }
        return null;
    }

    public boolean validate() {
        errors = "";
        if (getOldPassword().isEmpty()) {
            errors = errors.concat(getContext().getString(R.string.error_old_password_required));
        }
        if (getPassword().isEmpty()) {
            errors = errors.concat(getContext().getString(R.string.error_password_required));
        }
        if (getConfirmPassword().isEmpty()) {
            errors = errors.concat("Confirm password is required.\n");
        }
        if (!getPassword().equals(getConfirmPassword())) {
            errors = errors.concat("Passwords must match.\n");
        }
        return errors.isEmpty();
    }

    public String getErrors() {
        return errors;
    }
}
