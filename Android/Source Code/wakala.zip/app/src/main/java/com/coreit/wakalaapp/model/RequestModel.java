package com.coreit.wakalaapp.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Ramadan on 4/1/2018.
 */

public class RequestModel implements Parcelable {
    public int id;
    public String provider;
    public String client;
    public String service;
    public String amount;
    public String account;
    public String time;
    public String image;
    public String clientName;

    public RequestModel() {

    }

    protected RequestModel(Parcel in) {
        id = in.readInt();
        provider = in.readString();
        client = in.readString();
        service = in.readString();
        amount = in.readString();
        account = in.readString();
        time = in.readString();
        image = in.readString();
        clientName = in.readString();
    }

    public static final Creator<RequestModel> CREATOR = new Creator<RequestModel>() {
        @Override
        public RequestModel createFromParcel(Parcel in) {
            return new RequestModel(in);
        }

        @Override
        public RequestModel[] newArray(int size) {
            return new RequestModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(provider);
        parcel.writeString(client);
        parcel.writeString(service);
        parcel.writeString(amount);
        parcel.writeString(account);
        parcel.writeString(time);
        parcel.writeString(image);
        parcel.writeString(clientName);
    }
}
